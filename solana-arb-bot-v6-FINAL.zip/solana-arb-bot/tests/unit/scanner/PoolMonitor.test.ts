// tests/unit/scanner/PoolMonitor.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { PoolMonitor } from '../../../src/market/PoolMonitor';
import { PoolState } from '../../../src/core/types';

const makePool = (
  address: string,
  dex: PoolState['dex'],
  tokenA: string,
  tokenB: string,
  price = 100,
  lastUpdatedMs = Date.now()
): PoolState => ({
  address,
  dex,
  tokenA,
  tokenB,
  reserveA: 1_000_000n,
  reserveB: 10_000n,
  price,
  liquidity: 100_000,
  lastUpdatedMs,
  fee: 0.003,
});

const SOL  = 'SOL_MINT';
const USDC = 'USDC_MINT';
const RAY  = 'RAY_MINT';

describe('PoolMonitor', () => {
  let monitor: PoolMonitor;

  beforeEach(() => {
    monitor = new PoolMonitor();
  });

  describe('updatePool()', () => {
    it('stores pool and retrieves it', () => {
      const pool = makePool('pool-1', 'raydium', SOL, USDC);
      monitor.updatePool(pool);
      expect(monitor.getPool('pool-1')).toEqual(pool);
    });

    it('emits pool_updated event on significant change', () => {
      const listener = vi.fn();
      monitor.on('pool_updated', listener);

      const pool1 = makePool('pool-1', 'raydium', SOL, USDC, 100);
      monitor.updatePool(pool1);
      expect(listener).toHaveBeenCalledTimes(1);

      // Significant price change
      const pool2 = makePool('pool-1', 'raydium', SOL, USDC, 102);
      monitor.updatePool(pool2);
      expect(listener).toHaveBeenCalledTimes(2);
    });

    it('does not emit event for insignificant price change', () => {
      const listener = vi.fn();

      const pool1 = makePool('pool-1', 'raydium', SOL, USDC, 100);
      monitor.updatePool(pool1);
      listener.mockReset();

      monitor.on('pool_updated', listener);

      // Tiny change (< 0.01%)
      const pool2 = { ...pool1, price: 100.0000001 };
      monitor.updatePool(pool2);
      expect(listener).toHaveBeenCalledTimes(0);
    });

    it('updates pair index for both directions', () => {
      monitor.updatePool(makePool('pool-1', 'raydium', SOL, USDC));

      const forward = monitor.getPoolsForPair(SOL, USDC);
      const reverse = monitor.getPoolsForPair(USDC, SOL);

      expect(forward).toHaveLength(1);
      expect(reverse).toHaveLength(1);
    });
  });

  describe('getPoolsForPair()', () => {
    it('returns all pools for a pair across DEXes', () => {
      monitor.updatePool(makePool('pool-ray', 'raydium', SOL, USDC));
      monitor.updatePool(makePool('pool-orca', 'orca', SOL, USDC));
      monitor.updatePool(makePool('pool-other', 'raydium', RAY, USDC));

      const pools = monitor.getPoolsForPair(SOL, USDC);
      expect(pools).toHaveLength(2);
      expect(pools.map(p => p.address)).toContain('pool-ray');
      expect(pools.map(p => p.address)).toContain('pool-orca');
    });

    it('returns empty array for unknown pair', () => {
      expect(monitor.getPoolsForPair('UNKNOWN', 'ALSO_UNKNOWN')).toHaveLength(0);
    });
  });

  describe('getFreshPools()', () => {
    it('returns only pools within maxAge', () => {
      const fresh = makePool('fresh', 'raydium', SOL, USDC, 100, Date.now());
      const stale = makePool('stale', 'orca', SOL, USDC, 100, Date.now() - 10_000);

      monitor.updatePool(fresh);
      monitor.updatePool(stale);

      const result = monitor.getFreshPools(5_000); // 5s threshold
      expect(result.map(p => p.address)).toContain('fresh');
      expect(result.map(p => p.address)).not.toContain('stale');
    });
  });

  describe('isStale()', () => {
    it('returns true for old pool', () => {
      const pool = makePool('pool-1', 'raydium', SOL, USDC, 100, Date.now() - 10_000);
      monitor.updatePool(pool);
      expect(monitor.isStale('pool-1', 5_000)).toBe(true);
    });

    it('returns false for fresh pool', () => {
      monitor.updatePool(makePool('pool-1', 'raydium', SOL, USDC));
      expect(monitor.isStale('pool-1', 5_000)).toBe(false);
    });

    it('returns true for non-existent pool', () => {
      expect(monitor.isStale('nonexistent', 5_000)).toBe(true);
    });
  });

  describe('getPoolCount()', () => {
    it('returns correct count', () => {
      expect(monitor.getPoolCount()).toBe(0);
      monitor.updatePool(makePool('a', 'raydium', SOL, USDC));
      monitor.updatePool(makePool('b', 'orca', SOL, USDC));
      expect(monitor.getPoolCount()).toBe(2);
    });

    it('overwrites same address, does not increment count', () => {
      monitor.updatePool(makePool('a', 'raydium', SOL, USDC, 100));
      monitor.updatePool(makePool('a', 'raydium', SOL, USDC, 101));
      expect(monitor.getPoolCount()).toBe(1);
    });
  });
});
