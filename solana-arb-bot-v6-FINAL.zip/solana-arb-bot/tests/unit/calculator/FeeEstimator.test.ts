// tests/unit/calculator/FeeEstimator.test.ts — NEW
// Tests for integer-math fee calculation and synchronous cache.

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { FeeEstimator } from '../../../src/calculator/FeeEstimator';

const USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const SOL  = 'So11111111111111111111111111111111111111112';

const mockPriceTracker = {
  getPriceUSD: vi.fn().mockImplementation((mint: string) =>
    mint === SOL ? 150 : 1.0),
};

const mockConnection = {
  getRecentPrioritizationFees: vi.fn().mockResolvedValue([
    { slot: 1, prioritizationFee: 5_000 },
    { slot: 2, prioritizationFee: 10_000 },
    { slot: 3, prioritizationFee: 50_000 },
    { slot: 4, prioritizationFee: 100_000 },
  ]),
};

describe('FeeEstimator v2', () => {
  let estimator: FeeEstimator;

  beforeEach(() => {
    estimator = new FeeEstimator(
      mockConnection as never,
      mockPriceTracker as never,
      1.0009, // 0.09% fee
    );
  });

  describe('calcFlashLoanFee (integer math)', () => {
    it('calculates 0.09% of 1,000,000 = 900 (ceil)', () => {
      // 1,000,000 * 0.0009 = 900.0 → 900
      expect(estimator.calcFlashLoanFee(1_000_000n)).toBe(900n);
    });

    it('rounds up (ceiling not floor)', () => {
      // 1,000,001 * 0.0009 = 900.0009 → ceil → 901
      expect(estimator.calcFlashLoanFee(1_000_001n)).toBeGreaterThanOrEqual(900n);
    });

    it('handles SOL loan sizes without precision loss', () => {
      // 333 SOL at 9 decimals = 333_000_000_000 lamports
      const sol333 = 333_000_000_000n;
      const fee = estimator.calcFlashLoanFee(sol333);
      // Expected: 333e9 * 0.0009 = 299_700_000
      expect(fee).toBeGreaterThan(299_000_000n);
      expect(fee).toBeLessThan(300_000_000n);
    });
  });

  describe('getCachedFeeBreakdown (synchronous)', () => {
    it('returns FeeBreakdown without async', () => {
      const result = estimator.getCachedFeeBreakdown(USDC, 1_000_000n, 6);
      expect(result).not.toBeInstanceOf(Promise);
      expect(result.flashLoanFeeLamports).toBeGreaterThan(0n);
      expect(result.totalUSD).toBeGreaterThan(0);
    });

    it('totalUSD = flashLoanFeeUSD + txFeeUSD', () => {
      const r = estimator.getCachedFeeBreakdown(USDC, 1_000_000n, 6);
      expect(r.totalUSD).toBeCloseTo(r.flashLoanFeeUSD + r.txFeeUSD, 6);
    });

    it('larger loan → proportionally larger flash loan fee', () => {
      const small = estimator.getCachedFeeBreakdown(USDC, 1_000_000n, 6);
      const large = estimator.getCachedFeeBreakdown(USDC, 10_000_000n, 6);
      expect(large.flashLoanFeeUSD).toBeGreaterThan(small.flashLoanFeeUSD);
    });
  });

  describe('getPriorityFeeMicroLamports', () => {
    it('returns default when cache is empty', () => {
      const fee = estimator.getPriorityFeeMicroLamports();
      expect(fee).toBeGreaterThan(0);
    });

    it('returns higher fee in aggressive mode', () => {
      const normal     = estimator.getPriorityFeeMicroLamports(false);
      const aggressive = estimator.getPriorityFeeMicroLamports(true);
      expect(aggressive).toBeGreaterThanOrEqual(normal);
    });
  });
});
