import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

// better-sqlite3 requires native build. Skip if not available in test env.
let BotDatabase: typeof import('../../../src/database/Database').BotDatabase | null = null;
try {
  BotDatabase = require('../../../src/database/Database').BotDatabase;
} catch { /* native module unavailable */ }

const USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const SOL  = 'So11111111111111111111111111111111111111112';

function makeTrade(overrides = {}) {
  return {
    id: `t-${Math.random().toString(36).slice(2)}`, timestamp: Date.now(),
    status: 'success', route: { id: 'r1', hops: [], tokenIn: USDC, tokenOut: USDC, estimatedAmountIn: 1_000_000n, estimatedAmountOut: 1_005_000n, loanAmountUSD: 1000 },
    loanAmount: 1_000_000n, loanToken: USDC, loanFeeUSD: 0.9,
    grossProfitUSD: 5.0, netProfitUSD: 4.1, txFeeUSD: 0.005, priorityFeeUSD: 0.001,
    slippagePct: 0.1, txSignature: 'sig123', durationMs: 250, ...overrides,
  };
}

describe('BotDatabase', () => {
  let db: InstanceType<NonNullable<typeof BotDatabase>>;
  let tmpDir: string;

  beforeEach(() => {
    if (!BotDatabase) return;
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'arb-test-'));
    db = new BotDatabase(path.join(tmpDir, 'test.db'));
  });

  afterEach(() => {
    if (!BotDatabase || !db) return;
    db.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('inserts and retrieves a trade', () => {
    if (!BotDatabase) return;
    const trade = makeTrade();
    db.insertTrade(trade as never);
    const recent = db.getRecentTrades(10);
    expect(recent).toHaveLength(1);
    expect(recent[0]!.id).toBe(trade.id);
  });

  it('retrieves in descending timestamp order', () => {
    if (!BotDatabase) return;
    const t1 = makeTrade({ id: 't1', timestamp: 1000 });
    const t2 = makeTrade({ id: 't2', timestamp: 2000 });
    const t3 = makeTrade({ id: 't3', timestamp: 3000 });
    db.insertTrade(t1 as never); db.insertTrade(t2 as never); db.insertTrade(t3 as never);
    const r = db.getRecentTrades(10);
    expect(r[0]!.id).toBe('t3');
    expect(r[2]!.id).toBe('t1');
  });

  it('respects limit parameter', () => {
    if (!BotDatabase) return;
    for (let i = 0; i < 5; i++) db.insertTrade(makeTrade() as never);
    expect(db.getRecentTrades(3)).toHaveLength(3);
  });

  it('BigInt loanAmount roundtrips correctly', () => {
    if (!BotDatabase) return;
    const trade = makeTrade({ loanAmount: 999_999_999_999n });
    db.insertTrade(trade as never);
    expect(db.getRecentTrades(1)[0]!.loanAmount).toBe(999_999_999_999n);
  });

  it('creates daily_pnl row on first trade', () => {
    if (!BotDatabase) return;
    db.insertTrade(makeTrade({ netProfitUSD: 10 }) as never);
    const today = db.getTodayPnL();
    expect(today).not.toBeNull();
    expect(today!.tradesTotal).toBe(1);
    expect(today!.netProfitUSD).toBeCloseTo(10, 2);
  });

  it('accumulates multiple trades in daily_pnl', () => {
    if (!BotDatabase) return;
    db.insertTrade(makeTrade({ netProfitUSD: 5 }) as never);
    db.insertTrade(makeTrade({ netProfitUSD: 3 }) as never);
    db.insertTrade(makeTrade({ netProfitUSD: -1 }) as never);
    const today = db.getTodayPnL();
    expect(today!.tradesTotal).toBe(3);
    expect(today!.netProfitUSD).toBeCloseTo(7, 2);
  });

  it('counts consecutive losses', () => {
    if (!BotDatabase) return;
    db.insertTrade(makeTrade({ status: 'success', netProfitUSD: 5 }) as never);
    db.insertTrade(makeTrade({ status: 'failed',  netProfitUSD: -1 }) as never);
    db.insertTrade(makeTrade({ status: 'failed',  netProfitUSD: -1 }) as never);
    expect(db.getConsecutiveLosses()).toBe(2);
  });

  it('prunes old snapshots', () => {
    if (!BotDatabase) return;
    const oldPool = { address: 'p', dex: 'raydium' as const, poolType: 'amm_v4' as const,
      tokenA: SOL, tokenB: USDC, reserveA: 1000n, reserveB: 1000n, price: 1,
      liquidity: 100, lastUpdatedMs: Date.now() - 48*3_600_000, fee: 0.003 };
    db.insertPoolSnapshot(oldPool);
    expect(db.pruneOldSnapshots(24)).toBe(1);
  });
});
