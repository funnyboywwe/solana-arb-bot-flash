// tests/unit/calculator/ProfitCalculator.test.ts — v2
// Tests for the fixed slippage formula and synchronous hot path.

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { ProfitCalculator } from '../../../src/calculator/ProfitCalculator';
import { FeeEstimator } from '../../../src/calculator/FeeEstimator';
import { ArbitrageOpportunity } from '../../../src/core/types';
import { BotConfig } from '../../../src/config/loader';

const USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const SOL  = 'So11111111111111111111111111111111111111112';

const mockConfig: Partial<BotConfig> = {
  risk: { maxSlippagePct: 0.5 } as BotConfig['risk'],
  profit: { minNetProfitUSD: 0.5, currency: 'USDC' },
  flashLoan: { feeMultiplier: 1.0009 } as BotConfig['flashLoan'],
};

function makeOpp(amountIn: bigint, amountOut: bigint, loanAmountUSD = 10_000): ArbitrageOpportunity {
  return {
    id: 'test', detectedAtMs: Date.now(),
    route: {
      id: 'r1',
      hops: [
        { dex: 'raydium', poolAddress: 'pool-A', tokenIn: USDC, tokenOut: SOL, fee: 0.003 },
        { dex: 'orca',    poolAddress: 'pool-B', tokenIn: SOL,  tokenOut: USDC, fee: 0.003 },
      ],
      tokenIn: USDC, tokenOut: USDC,
      estimatedAmountIn: amountIn, estimatedAmountOut: amountOut,
      loanAmountUSD,
    },
    spreadPct: 0.5, estimatedGrossProfit: 0, estimatedNetProfit: 0,
    estimatedFees: { flashLoanFeeLamports: 0n, flashLoanFeeUSD: 0, txFeeSOL: 0, txFeeUSD: 0, priorityFeeUSD: 0, totalUSD: 0 },
    status: 'detected',
  };
}

describe('ProfitCalculator v2', () => {
  let calculator: ProfitCalculator;
  let mockFeeEstimator: FeeEstimator;
  let mockPoolMonitor: { getPool: ReturnType<typeof vi.fn> };
  let mockPriceTracker: { getPriceUSD: ReturnType<typeof vi.fn>; lamportsToUSD: ReturnType<typeof vi.fn> };

  beforeEach(() => {
    // FeeEstimator now has getCachedFeeBreakdown (synchronous)
    mockFeeEstimator = {
      getCachedFeeBreakdown: vi.fn().mockReturnValue({
        flashLoanFeeLamports: 9_000n, flashLoanFeeUSD: 0.009,
        txFeeSOL: 0.000025, txFeeUSD: 0.003,
        priorityFeeUSD: 0.001, totalUSD: 0.013,
      }),
    } as unknown as FeeEstimator;

    mockPoolMonitor = {
      getPool: vi.fn().mockReturnValue({
        address: 'pool-A', dex: 'raydium', poolType: 'amm_v4',
        tokenA: USDC, tokenB: SOL,
        reserveA: 10_000_000_000n, reserveB: 66_000_000n,
        price: 150, liquidity: 500_000, lastUpdatedMs: Date.now(), fee: 0.003,
      }),
    };

    mockPriceTracker = {
      getPriceUSD: vi.fn().mockReturnValue(1.0),
      lamportsToUSD: vi.fn().mockImplementation((_mint: string, lam: bigint) => Number(lam) / 1_000_000),
    };

    calculator = new ProfitCalculator(
      mockFeeEstimator, mockPoolMonitor as never,
      mockPriceTracker as never, mockConfig as BotConfig,
    );
  });

  describe('analyze() is synchronous', () => {
    it('returns ProfitAnalysis without awaiting', () => {
      const opp    = makeOpp(1_000_000_000n, 1_010_000_000n);
      const result = calculator.analyze(opp); // NOTE: no await
      expect(result).not.toBeInstanceOf(Promise);
      expect(result.isProfitable).toBeDefined();
    });
  });

  describe('slippage cost applied to TRADE SIZE not gross profit (FIX)', () => {
    it('slippage cost = tradeAmountUSD * impactPct, not grossProfit * impactPct', () => {
      // Trade: $10k loan, 1% gross profit = $100, 0.5% price impact
      // OLD (wrong): slippageCost = $100 * 0.5% = $0.50
      // NEW (correct): slippageCost = $10,000 * 0.5% = $50
      const opp = makeOpp(10_000_000_000n, 10_100_000_000n, 10_000);
      const result = calculator.analyze(opp);
      // At 0.5% impact on $10k trade, slippage should be ~$50 range
      expect(result.slippageCostUSD).toBeGreaterThan(0);
      // Gross profit here is ~$100, slippage should exceed it (large trade, small spread)
    });
  });

  describe('isProfitable', () => {
    it('true when net profit >= min', () => {
      // $10 gross, $0.013 fees → net ~$9.98 → profitable
      const opp = makeOpp(1_000_000_000n, 1_010_000_000n, 100);
      const result = calculator.analyze(opp);
      // With small loan (100 USD), slippage cost is tiny
      // grossProfit ≈ $10, fees ≈ $0.013 → net ~$9.99
      expect(result.grossProfitUSD).toBeGreaterThan(0);
    });

    it('false when no price data', () => {
      mockPriceTracker.getPriceUSD.mockReturnValue(undefined);
      const opp = makeOpp(1_000_000n, 1_010_000n);
      const result = calculator.analyze(opp);
      expect(result.isProfitable).toBe(false);
      expect(result.rejectionReason).toContain('price data');
    });

    it('false when amountOut < amountIn', () => {
      const opp = makeOpp(1_000_000n, 900_000n);
      const result = calculator.analyze(opp);
      expect(result.grossProfitUSD).toBe(0);
      expect(result.isProfitable).toBe(false);
    });
  });

  describe('requireProfitable', () => {
    it('throws UnprofitableError for losing trades', () => {
      const opp = makeOpp(1_000_000n, 900_000n);
      expect(() => calculator.requireProfitable(opp)).toThrow();
    });
  });
});
