import { describe, it, expect } from 'vitest';
import { RepaymentEngine } from '../../../src/executor/RepaymentEngine';
import { RepaymentError } from '../../../src/core/errors';

const USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';

describe('RepaymentEngine', () => {
  const engine = new RepaymentEngine(1.0009); // 0.09% fee

  describe('buildRepaymentPlan()', () => {
    it('calculates correct fee: 0.09% of 1_000_000 = 900', () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      expect(plan.feeLamports).toBe(900n);
    });

    it('totalRepay = principal + fee', () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      expect(plan.totalRepayLamports).toBe(plan.principalLamports + plan.feeLamports);
    });

    it('rounds fee up (ceiling math)', () => {
      const plan = engine.buildRepaymentPlan(1_000_001n, USDC);
      expect(plan.feeLamports).toBeGreaterThanOrEqual(900n);
    });

    it('stores tokenMint', () => {
      expect(engine.buildRepaymentPlan(500_000n, USDC).tokenMint).toBe(USDC);
    });
  });

  describe('verifyFundsAvailable()', () => {
    it('resolves when balance >= repay amount', async () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      await expect(engine.verifyFundsAvailable(2_000_000n, plan)).resolves.toBeUndefined();
    });

    it('throws RepaymentError when balance < repay amount', async () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      await expect(engine.verifyFundsAvailable(500_000n, plan)).rejects.toThrow(RepaymentError);
    });

    it('resolves when balance exactly equals repay amount', async () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      await expect(engine.verifyFundsAvailable(plan.totalRepayLamports, plan)).resolves.toBeUndefined();
    });
  });

  describe('verifyRepaymentResult()', () => {
    it('verified=true when balance delta matches expected profit', () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      // before=0, after=5000, gross=5900, fee=900
      // expectedAfter = 0 + 5900 - 900 = 5000; actual=5000; delta=0 → verified
      const { verified, actualProfitLamports } = engine.verifyRepaymentResult(0n, 5_000n, plan, 5_900n);
      expect(verified).toBe(true);
      expect(actualProfitLamports).toBe(5_000n);
    });

    it('verified=true within 1% tolerance (delta within tolerance band)', () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      // tolerance = totalRepay / 100 = ~10009 lamports
      // delta of 5000 is within 10009 → verified=true
      const { verified } = engine.verifyRepaymentResult(0n, 0n, plan, 5_900n);
      expect(verified).toBe(true); // 5000 delta < 10009 tolerance
    });

    it('verified=false when discrepancy far exceeds 1% tolerance', () => {
      // Use tiny loan so tolerance is tiny, but create large discrepancy
      // principal=1000, fee=1, totalRepay=1001, tolerance=10 lamports
      const smallEngine = new RepaymentEngine(1.001); // 0.1% fee
      const plan = smallEngine.buildRepaymentPlan(1000n, USDC);
      // expected profit=500, but got nothing (after=before=0)
      // expectedAfter = 0+500-1 = 499; actual=0; delta=499; tolerance=1000/100=10
      // 499 > 10 → verified=false
      const { verified } = smallEngine.verifyRepaymentResult(0n, 0n, plan, 500n);
      expect(verified).toBe(false);
    });

    it('handles zero profit (break-even)', () => {
      const plan = engine.buildRepaymentPlan(1_000_000n, USDC);
      const { actualProfitLamports } = engine.verifyRepaymentResult(1_000_000n, 1_000_000n, plan, 0n);
      expect(actualProfitLamports).toBe(0n);
    });
  });
});
