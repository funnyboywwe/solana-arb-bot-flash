// tests/unit/risk/CircuitBreaker.test.ts — v2
// Tests for in-memory state, no DB queries in hot path.

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { CircuitBreaker } from '../../../src/risk/CircuitBreaker';
import { CircuitBreakerError } from '../../../src/core/errors';

const makeDb = (consecutive = 0, todayNet: number | null = null) => ({
  getConsecutiveLosses: vi.fn().mockReturnValue(consecutive),
  getTodayPnL: vi.fn().mockReturnValue(todayNet !== null ? { netProfitUSD: todayNet } : null),
});

describe('CircuitBreaker v2', () => {
  describe('checkSync() — hot path, no I/O', () => {
    it('does not throw when not tripped', () => {
      const cb = new CircuitBreaker(3, 500, makeDb() as never);
      expect(() => cb.checkSync()).not.toThrow();
    });

    it('throws immediately when tripped', () => {
      const cb = new CircuitBreaker(3, 500, makeDb() as never);
      cb.recordLoss();
      cb.recordLoss();
      cb.recordLoss(); // trips at 3
      expect(() => cb.checkSync()).toThrow(CircuitBreakerError);
    });
  });

  describe('restoreState()', () => {
    it('trips on restore when DB shows >= max consecutive losses', async () => {
      const db = makeDb(5); // 5 > max 3
      const cb = new CircuitBreaker(3, 500, db as never);
      await cb.restoreState();
      expect(cb.isTripped()).toBe(true);
    });

    it('trips on restore when daily loss >= limit', async () => {
      const db = makeDb(0, -600); // -$600 > $500 limit
      const cb = new CircuitBreaker(3, 500, db as never);
      await cb.restoreState();
      expect(cb.isTripped()).toBe(true);
    });

    it('does not trip when within limits', async () => {
      const db = makeDb(1, -100);
      const cb = new CircuitBreaker(3, 500, db as never);
      await cb.restoreState();
      expect(cb.isTripped()).toBe(false);
    });

    it('queries DB exactly once during restore', async () => {
      const db = makeDb(0, 0);
      const cb = new CircuitBreaker(3, 500, db as never);
      await cb.restoreState();

      // After restore, multiple checkSync() calls should NOT call DB
      cb.checkSync();
      cb.checkSync();
      cb.checkSync();

      expect(db.getConsecutiveLosses).toHaveBeenCalledTimes(1);
    });
  });

  describe('recordLoss / recordWin', () => {
    it('trips after N consecutive recordLoss calls', () => {
      const cb = new CircuitBreaker(3, 500, makeDb() as never);
      cb.recordLoss(); cb.recordLoss();
      expect(cb.isTripped()).toBe(false);
      cb.recordLoss();
      expect(cb.isTripped()).toBe(true);
    });

    it('trips when daily loss accumulates', () => {
      const cb = new CircuitBreaker(10, 100, makeDb() as never); // low $100 limit
      cb.recordLoss(60);
      expect(cb.isTripped()).toBe(false);
      cb.recordLoss(50); // total $110 > $100
      expect(cb.isTripped()).toBe(true);
    });

    it('resets consecutive count on win', () => {
      const cb = new CircuitBreaker(3, 500, makeDb() as never);
      cb.recordLoss(); cb.recordLoss();
      cb.recordWin();  // reset
      cb.recordLoss(); cb.recordLoss();
      expect(cb.isTripped()).toBe(false);
    });
  });

  describe('reset()', () => {
    it('un-trips the breaker', () => {
      const cb = new CircuitBreaker(1, 500, makeDb() as never);
      cb.recordLoss();
      expect(cb.isTripped()).toBe(true);
      cb.reset();
      expect(cb.isTripped()).toBe(false);
      expect(() => cb.checkSync()).not.toThrow();
    });
  });
});
