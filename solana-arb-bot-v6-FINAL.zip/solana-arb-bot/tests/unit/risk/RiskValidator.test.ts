import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { RiskValidator } from '../../../src/risk/RiskValidator';
import { LiquidityGuard } from '../../../src/risk/LiquidityGuard';
import { CircuitBreaker } from '../../../src/risk/CircuitBreaker';
import { EmergencyStop } from '../../../src/risk/EmergencyStop';
import { SlippageModel } from '../../../src/calculator/SlippageModel';
import { PoolMonitor } from '../../../src/market/PoolMonitor';
import { ArbitrageOpportunity, PoolState } from '../../../src/core/types';
import { BotConfig } from '../../../src/config/loader';

const USDC = 'USDC_MINT';
const SOL  = 'SOL_MINT';

// Config: low min liquidity so mock pools pass liquidity check
const mockConfig: Partial<BotConfig> = {
  risk: {
    maxSlippagePct: 2.0,          // generous to avoid slippage rejection
    minLiquidityUSD: 500,         // low so mock pools with $1k liquidity pass
    maxPoolAgeMs: 5_000,
    maxDailyLossUSD: 500,
    circuitBreakerConsecutiveLosses: 3,
    maxTransactionSizeUSD: 50_000,
  } as BotConfig['risk'],
  profit: { minNetProfitUSD: 0.5, currency: 'USDC' },
};

// Pool with $2M reserves = passes liquidity check at minLiquidity=500
const makePool = (addr: string): PoolState => ({
  address: addr, dex: 'raydium', poolType: 'amm_v4',
  tokenA: USDC, tokenB: SOL,
  reserveA: 2_000_000_000_000n,  // large reserves for liquidity check
  reserveB: 20_000_000_000n,
  price: 100, liquidity: 2_000_000, lastUpdatedMs: Date.now(), fee: 0.003,
});

const makeOpp = (poolA = 'pool-A', poolB = 'pool-B', loanUSD = 10_000): ArbitrageOpportunity => ({
  id: 'test', detectedAtMs: Date.now(),
  route: {
    id: 'r1',
    hops: [
      { dex: 'raydium', poolAddress: poolA, tokenIn: USDC, tokenOut: SOL, fee: 0.003 },
      { dex: 'orca',    poolAddress: poolB, tokenIn: SOL,  tokenOut: USDC, fee: 0.003 },
    ],
    tokenIn: USDC, tokenOut: USDC,
    estimatedAmountIn: 1_000_000n, estimatedAmountOut: 1_005_000n,
    loanAmountUSD: loanUSD,
  },
  spreadPct: 0.5, estimatedGrossProfit: 5, estimatedNetProfit: 3,
  estimatedFees: {
    flashLoanFeeLamports: 900n, flashLoanFeeUSD: 0.9,
    txFeeSOL: 0.000025, txFeeUSD: 0.005, priorityFeeUSD: 0.001, totalUSD: 0.906,
  },
  status: 'detected',
});

describe('RiskValidator v2', () => {
  let poolMonitor: PoolMonitor;
  let circuitBreaker: CircuitBreaker;
  let stop: EmergencyStop;
  let validator: RiskValidator;

  afterEach(() => { stop?.cleanup(); });

  beforeEach(() => {
    poolMonitor = new PoolMonitor();
    const mockDb = {
      getConsecutiveLosses: vi.fn().mockReturnValue(0),
      getTodayPnL: vi.fn().mockReturnValue(null),
    };
    circuitBreaker = new CircuitBreaker(3, 500, mockDb as never);
    stop = new EmergencyStop();

    // Price tracker returns $150/SOL and $1/USDC
    const mockPriceTracker = {
      getPriceUSD: vi.fn().mockImplementation((mint: string) =>
        mint === SOL ? 150 : 1.0),
      lamportsToUSD: vi.fn().mockReturnValue(2_000_000), // large USD value = passes liquidity
    };
    const liquidityGuard = new LiquidityGuard(
      poolMonitor, mockPriceTracker as never,
      mockConfig.risk!.minLiquidityUSD,
      mockConfig.risk!.maxPoolAgeMs,
    );
    const slippageModel = new SlippageModel(mockConfig.risk!.maxSlippagePct);
    validator = new RiskValidator(
      liquidityGuard, circuitBreaker, stop,
      slippageModel, poolMonitor, mockConfig as BotConfig,
    );
  });

  describe('Transaction size — uses loanAmountUSD not netProfit (FIX)', () => {
    it('rejects loanAmountUSD > maxTransactionSizeUSD ($60k > $50k)', async () => {
      poolMonitor.updatePool(makePool('pool-A'));
      poolMonitor.updatePool(makePool('pool-B'));
      const opp = makeOpp('pool-A', 'pool-B', 60_000);
      const result = await validator.check(opp);
      expect(result.passed).toBe(false);
      expect((result as { reason: string }).reason).toContain('Loan');
    });

    it('passes all checks for valid $1k opportunity', async () => {
      poolMonitor.updatePool(makePool('pool-A'));
      poolMonitor.updatePool(makePool('pool-B'));
      const opp = makeOpp('pool-A', 'pool-B', 1_000);
      const result = await validator.check(opp);
      expect(result.passed).toBe(true);
    });
  });

  describe('Route health', () => {
    it('rejects duplicate pools', async () => {
      poolMonitor.updatePool(makePool('pool-A'));
      const opp = makeOpp('pool-A', 'pool-A');
      const result = await validator.check(opp);
      expect(result.passed).toBe(false);
      expect((result as { reason: string }).reason).toContain('duplicate');
    });

    it('rejects route not returning to start token', async () => {
      poolMonitor.updatePool(makePool('pool-A'));
      poolMonitor.updatePool(makePool('pool-B'));
      const opp = makeOpp();
      opp.route.hops[1]!.tokenOut = 'DIFFERENT_TOKEN';
      const result = await validator.check(opp);
      expect(result.passed).toBe(false);
      expect((result as { reason: string }).reason).toContain('starting token');
    });

    it('rejects broken hop chain — checked after liquidity', async () => {
      poolMonitor.updatePool(makePool('pool-A'));
      poolMonitor.updatePool(makePool('pool-B'));
      const opp = makeOpp();
      opp.route.hops[1]!.tokenIn = 'WRONG_TOKEN'; // breaks hop chain
      const result = await validator.check(opp);
      // Route health is checked after liquidity — either failure reason is valid
      expect(result.passed).toBe(false);
    });
  });
});
