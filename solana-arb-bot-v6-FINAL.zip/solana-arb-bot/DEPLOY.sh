#!/usr/bin/env bash
# =============================================================================
# Solana Arb Bot — v6 ONE-SHOT DEPLOY / VERIFY SCRIPT
# =============================================================================
# Run this ON THE VPS, from inside the extracted package folder:
#
#     unzip solana-arb-bot-v6-FINAL.zip -d solana-arb-bot-v6
#     cd solana-arb-bot-v6
#     chmod +x DEPLOY.sh
#     ./DEPLOY.sh
#
# It stops the bot, syncs the fixed source, FORCES a clean rebuild, VERIFIES
# that the new code actually compiled into dist/, then restarts and tails logs.
# If the build fails, it ABORTS and leaves the old bot untouched.
# =============================================================================
set -euo pipefail

BOT_DIR="${BOT_DIR:-/home/ubuntu/solana-arb-bot}"
SERVICE="${SERVICE:-arb-bot}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

bold() { printf '\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '\033[32m\u2713 %s\033[0m\n' "$*"; }
err()  { printf '\033[31m\u2717 %s\033[0m\n' "$*"; }

bold "==> 1/8  Stopping $SERVICE"
sudo systemctl stop "$SERVICE" || true

bold "==> 2/8  Backing up current source"
TS=$(date +%Y%m%d-%H%M%S)
if [ -d "$BOT_DIR/src" ]; then
  cp -r "$BOT_DIR/src" "$BOT_DIR/src.bak-$TS"
  ok "Backed up src -> src.bak-$TS"
fi

bold "==> 3/8  Syncing fixed source into $BOT_DIR"
cp -r "$SRC_DIR/src"            "$BOT_DIR/"
cp    "$SRC_DIR/tsconfig.json"  "$BOT_DIR/"
cp    "$SRC_DIR/package.json"   "$BOT_DIR/"
# Config: copy ONLY if you want to overwrite. Commented out to preserve your keys.
# cp -r "$SRC_DIR/config" "$BOT_DIR/"
ok "Source synced"

cd "$BOT_DIR"

bold "==> 4/8  SOURCE CHECK (new code present in source?)"
grep -q "batched polling"        src/market/MarketDataService.ts && ok "polling rewrite present"        || { err "polling code MISSING"; exit 1; }
grep -q "price/v3"               src/market/MarketDataService.ts && ok "Jupiter Price V3 present"        || { err "Jupiter V3 MISSING"; exit 1; }
! grep -rq "accountSubscribe"     src/                            && ok "no accountSubscribe in source"   || { err "accountSubscribe STILL in source"; exit 1; }
! grep -rq "onAccountChange"      src/                            && ok "no onAccountChange in source"    || { err "onAccountChange STILL in source"; exit 1; }

bold "==> 5/8  Installing deps (ensures @types/* present)"
npm install --no-audit --no-fund

bold "==> 6/8  Clean rebuild (rm -rf dist && npm run build)"
rm -rf dist
if ! npm run build; then
  err "BUILD FAILED — old bot left stopped. Fix errors above, do NOT start stale dist."
  exit 1
fi
ok "Build succeeded"

bold "==> 7/8  DIST CHECK (new code actually compiled into dist?)"
grep -rq "batched polling" dist/market/MarketDataService.js && ok "dist has polling rewrite"   || { err "dist is STALE — build did not emit new code"; exit 1; }
grep -rq "price/v3"        dist/market/MarketDataService.js && ok "dist has Jupiter V3"         || { err "dist is STALE"; exit 1; }
! grep -rq "accountSubscribe" dist/                          && ok "no accountSubscribe in dist" || { err "dist still has accountSubscribe"; exit 1; }

bold "==> 8/8  Starting $SERVICE"
sudo systemctl start "$SERVICE"
sleep 3
sudo systemctl --no-pager status "$SERVICE" | head -5

bold "==> DONE. Tailing pretty logs (Ctrl-C to stop) — watch for:"
echo "      'MarketDataService v3 started (batched polling)'"
echo "      fresh count climbing, and NO '429' / NO '-32007' storm."
sleep 2
sudo journalctl -fu "$SERVICE" -o cat | "$BOT_DIR/node_modules/.bin/pino-pretty"
