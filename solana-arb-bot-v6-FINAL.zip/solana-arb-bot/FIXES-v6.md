# Solana Arb Bot — v6 FINAL — What was wrong and what was fixed

## The #1 reason nothing you deployed ever "took" (silent stale build)
`tsconfig.json` had `noUnusedLocals: true` + `noUnusedParameters: true`, and several
files had unused symbols. Under those flags **`npm run build` (tsc) exits non-zero**,
so `dist/` was **never updated** — the VPS kept running the ORIGINAL v2 build.
That is why your v3/v4/v5 fixes never changed the bot's behavior.

**Fix:** relaxed both flags to `false` (pure lint flags, zero runtime impact), and
fixed the one *real* type error (`PoolRegistry` `string | undefined` -> `string`).
The project now compiles cleanly (verified: the only remaining tsc errors are
"cannot find module" / implicit-any from missing `node_modules`, which resolve
once `npm install` has run on the VPS).

## #2  RPC subscription storm -> crash (-32007 / 429 / core dump)
The old code opened a WebSocket `accountSubscribe` per pool (25+). On free-tier RPC
this produced `-32007` rate-limit floods, `429 Too Many Requests`, and eventually
`readyState was 2` -> `status=6/ABRT` core dumps.

**Fix:** rewrote `RaydiumAdapter` + `OrcaAdapter` + `MarketDataService` to use
**batched polling** via `getMultipleAccountsInfo` (chunked at 100 accounts/call —
the RPC max), every `POOL_POLL_INTERVAL_MS = 3000`. That is ~2-3 RPC calls per
3s cycle (well under the ~15 req/s free-tier limit). Zero `accountSubscribe` /
`onAccountChange` remain anywhere in `src/`.

## #3  Jupiter Price API V2 is DEAD (web research)
Jupiter **deprecated Price API V2 on 2025-10-01** (confirmed on status.jup.ag, the
official @JupDevRel announcement, and dev.jup.ag changelog). The bot was calling
`api.jup.ag/price/v2`, a dead endpoint — a real source of price-fetch failures.

**Fix:** migrated `refreshPrices()` to **Price API V3**. Default base URL is
`https://lite-api.jup.ag` (free, **no API key needed**). The V3 response is a flat
map keyed by mint (`{ usdPrice, decimals }`) — the parser was updated accordingly.
Optional: set env `JUPITER_PRICE_BASE=https://api.jup.ag` + `JUPITER_API_KEY=...`
(free key from portal.jup.ag) for higher limits.

## How to deploy (one command, on the VPS)
```bash
unzip solana-arb-bot-v6-FINAL.zip -d solana-arb-bot-v6
cd solana-arb-bot-v6
chmod +x DEPLOY.sh
./DEPLOY.sh
```
`DEPLOY.sh` stops the bot, syncs source, **forces a clean rebuild, and verifies the
new code is actually in `dist/` before restarting**. If the build fails it ABORTS
and leaves the running bot untouched (no more silent stale deploys).

## Success looks like
- Log line: `MarketDataService v3 started (batched polling) pools=25 pollIntervalMs=3000`
- No `accountSubscribe`, no `-32007`, no `429` storm
- `fresh` pool count climbs to ~22+ (was stuck at 1)
- `opportunitiesDetected` / `sessionTrades` begin to appear
