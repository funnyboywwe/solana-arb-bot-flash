// src/market/MarketDataService.ts — v3 (batched polling + Jupiter Price API V3)
// CHANGE LOG
//  - v3: Replaced per-pool WebSocket subscriptions (accountSubscribe) with
//        batched getMultipleAccountsInfo polling in the adapters. This service
//        now registers pools (no RPC) and drives a single poll loop. This kills
//        the -32007 / 429 subscription storm and the readyState-2 core dump on
//        free-tier RPC.
//  - v3: Jupiter Price API V2 (api.jup.ag/price/v2) was DEPRECATED on
//        2025-10-01. Migrated to Price API V3. Default base URL is
//        lite-api.jup.ag (free, no API key). The V3 response shape is a flat
//        map keyed by mint with { usdPrice, decimals }.

import { Connection } from '@solana/web3.js';
import { EventEmitter } from 'events';
import { PoolMonitor } from './PoolMonitor';
import { PriceTracker } from './PriceTracker';
import { RaydiumAdapter } from './adapters/RaydiumAdapter';
import { OrcaAdapter } from './adapters/OrcaAdapter';
import { PoolRegistry } from './registry/PoolRegistry';
import { RpcConnectionPool } from '../infra/RpcConnectionPool';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { PoolState, TokenMint } from '../core/types';
import {
  TOKEN_MINTS,
  TOKEN_SYMBOLS,
  TOKEN_DECIMALS,
  PRICE_REFRESH_MS,
  POOL_POLL_INTERVAL_MS,
} from '../core/constants';

const logger = createLogger('MarketDataService');

// Jupiter Price API V3 base URL.
// lite-api.jup.ag works WITHOUT an API key (free tier). If you obtain a key
// from portal.jup.ag, set JUPITER_PRICE_BASE=https://api.jup.ag and send it via
// the x-api-key header (see refreshPrices()).
const JUP_PRICE_BASE = process.env['JUPITER_PRICE_BASE'] ?? 'https://lite-api.jup.ag';
const JUP_API_KEY = process.env['JUPITER_API_KEY'] ?? '';

// Price API V3 response: { "<mint>": { usdPrice, decimals, blockId, priceChange24h } | null }
interface JupiterV3PriceEntry {
  usdPrice: number;
  decimals?: number;
  blockId?: number;
  priceChange24h?: number;
}
type JupiterV3PriceResp = Record<string, JupiterV3PriceEntry | null>;

export class MarketDataService extends EventEmitter {
  private readonly poolMonitor: PoolMonitor;
  private readonly priceTracker: PriceTracker;
  private readonly raydiumAdapter: RaydiumAdapter;
  private readonly orcaAdapter: OrcaAdapter;
  private priceTimer: NodeJS.Timeout | null = null;
  private poolTimer: NodeJS.Timeout | null = null;
  private polling = false;
  private readonly connection: Connection;

  constructor(
    private readonly config: BotConfig,
    private readonly rpcPool: RpcConnectionPool,
    private readonly registry: PoolRegistry,
  ) {
    super();
    this.connection   = rpcPool.primary;
    this.poolMonitor  = new PoolMonitor();
    this.priceTracker = new PriceTracker();

    this.raydiumAdapter = new RaydiumAdapter(
      this.connection, config.dexes.raydium.programId,
    );
    this.orcaAdapter = new OrcaAdapter(
      this.connection, config.dexes.orca.programId,
    );

    this.wireEvents();
  }

  private wireEvents(): void {
    this.raydiumAdapter.on('pool_updated', (p: PoolState) => this.poolMonitor.updatePool(p));
    this.orcaAdapter.on('pool_updated',    (p: PoolState) => this.poolMonitor.updatePool(p));
    this.poolMonitor.on('pool_updated',    (p: PoolState) => this.emit('pool_updated', p));
  }

  async start(): Promise<void> {
    logger.info('Starting MarketDataService v3 (batched polling)');

    // Initial price fetch
    await this.refreshPrices();

    // Schedule price refresh (Jupiter free tier — keep slow to avoid 429s)
    this.priceTimer = setInterval(() => {
      this.refreshPrices().catch(err => logger.warn({ err }, 'Price refresh failed'));
    }, PRICE_REFRESH_MS);

    // Register all pools from registry (no RPC, no subscriptions)
    this.registerRegistryPools();

    // Initial batched poll so pools are fresh immediately
    await this.pollAllPools();

    // Schedule recurring batched poll of ALL pool reserves (1 RPC call/cycle)
    this.poolTimer = setInterval(() => {
      this.pollAllPools().catch(err => logger.warn({ err }, 'Pool poll failed'));
    }, POOL_POLL_INTERVAL_MS);

    logger.info(
      { pools: this.poolMonitor.getPoolCount(), pollIntervalMs: POOL_POLL_INTERVAL_MS },
      'MarketDataService v3 started (batched polling)',
    );
  }

  /** Register every registry pool with its adapter. No RPC calls. */
  private registerRegistryPools(): void {
    const allPools = this.registry.getAllPools();
    let raydium = 0, orca = 0;

    for (const entry of allPools) {
      if (entry.dex === 'raydium' && this.config.dexes.raydium.enabled) {
        this.raydiumAdapter.registerPool(entry);
        raydium++;
      } else if (entry.dex === 'orca' && this.config.dexes.orca.enabled) {
        this.orcaAdapter.registerWhirlpool(entry);
        orca++;
      }
    }

    logger.info({ raydium, orca, total: allPools.length }, 'Registered registry pools for polling');
  }

  /**
   * Poll ALL registered pools in batched RPC calls (getMultipleAccountsInfo).
   * Guarded against overlap so a slow cycle never stacks on the next tick.
   */
  private async pollAllPools(): Promise<void> {
    if (this.polling) return;
    this.polling = true;
    try {
      await Promise.allSettled([
        this.raydiumAdapter.refreshAll(),
        this.orcaAdapter.refreshAll(),
      ]);
    } finally {
      this.polling = false;
    }
  }

  async subscribeToPool(address: string, dex: 'raydium' | 'orca'): Promise<void> {
    const entry = this.registry.getPool(address);
    if (!entry) { logger.warn({ address }, 'Pool not in registry'); return; }

    if (dex === 'raydium') this.raydiumAdapter.registerPool(entry);
    else this.orcaAdapter.registerWhirlpool(entry);
  }

  private async refreshPrices(): Promise<void> {
    const mints = [TOKEN_MINTS.SOL, TOKEN_MINTS.USDC, TOKEN_MINTS.USDT, TOKEN_MINTS.RAY];
    const url = `${JUP_PRICE_BASE}/price/v3?ids=${mints.join(',')}`;
    try {
      const headers: Record<string, string> = {};
      if (JUP_API_KEY) headers['x-api-key'] = JUP_API_KEY;

      const resp = await fetch(url, {
        headers,
        signal: AbortSignal.timeout(4_000),
      });
      if (!resp.ok) {
        logger.warn({ status: resp.status, url }, 'Jupiter price fetch non-OK');
        return;
      }

      // V3 returns a flat map keyed by mint: { "<mint>": { usdPrice, decimals } }
      const data = await resp.json() as JupiterV3PriceResp;
      let updated = 0;
      for (const [mint, info] of Object.entries(data)) {
        if (!info || typeof info.usdPrice !== 'number') continue;
        this.priceTracker.updatePrice({
          mint,
          symbol: TOKEN_SYMBOLS[mint] ?? mint.slice(0, 4),
          priceUSD: info.usdPrice,
          decimals: info.decimals ?? TOKEN_DECIMALS[mint] ?? 6,
          lastUpdatedMs: Date.now(),
        });
        updated++;
      }
      logger.trace({ updated }, 'Prices refreshed (Jupiter V3)');
    } catch (err) {
      logger.warn({ err, url }, 'Price refresh failed');
    }
  }

  getPoolMonitor():  PoolMonitor  { return this.poolMonitor; }
  getPriceTracker(): PriceTracker { return this.priceTracker; }
  getConnection():   Connection   { return this.connection; }

  getPoolsForPair(a: TokenMint, b: TokenMint) {
    return this.poolMonitor.getPoolsForPair(a, b);
  }

  async stop(): Promise<void> {
    logger.info('Stopping MarketDataService');
    if (this.priceTimer) clearInterval(this.priceTimer);
    if (this.poolTimer) clearInterval(this.poolTimer);
    await Promise.allSettled([
      this.raydiumAdapter.unsubscribeAll(),
      this.orcaAdapter.unsubscribeAll(),
    ]);
  }
}
