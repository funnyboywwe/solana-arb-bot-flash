// src/market/PoolMonitor.ts
import { EventEmitter } from 'events';
import { PoolState, PoolAddress, TokenMint } from '../core/types';
import { createLogger } from '../core/logger';
import { POOL_STALE_THRESHOLD_MS } from '../core/constants';

const logger = createLogger('PoolMonitor');

export class PoolMonitor extends EventEmitter {
  // In-memory ring buffer of current pool states
  private pools: Map<PoolAddress, PoolState> = new Map();
  // Index: tokenA+tokenB -> pool addresses
  private pairIndex: Map<string, Set<PoolAddress>> = new Map();

  updatePool(pool: PoolState): void {
    const prev = this.pools.get(pool.address);
    this.pools.set(pool.address, pool);

    // Build pair index
    const pairKey = this.pairKey(pool.tokenA, pool.tokenB);
    const reversedKey = this.pairKey(pool.tokenB, pool.tokenA);

    if (!this.pairIndex.has(pairKey)) this.pairIndex.set(pairKey, new Set());
    if (!this.pairIndex.has(reversedKey)) this.pairIndex.set(reversedKey, new Set());

    this.pairIndex.get(pairKey)!.add(pool.address);
    this.pairIndex.get(reversedKey)!.add(pool.address);

    if (!prev || this.hasSignificantChange(prev, pool)) {
      this.emit('pool_updated', pool);
      logger.trace(
        { pool: pool.address, dex: pool.dex, price: pool.price },
        'Pool updated'
      );
    }
  }

  getPool(address: PoolAddress): PoolState | undefined {
    return this.pools.get(address);
  }

  getPoolsForPair(tokenA: TokenMint, tokenB: TokenMint): PoolState[] {
    const key = this.pairKey(tokenA, tokenB);
    const addresses = this.pairIndex.get(key) ?? new Set();
    return [...addresses]
      .map(a => this.pools.get(a))
      .filter((p): p is PoolState => p !== undefined);
  }

  getAllPools(): PoolState[] {
    return [...this.pools.values()];
  }

  getFreshPools(maxAgeMs = POOL_STALE_THRESHOLD_MS): PoolState[] {
    const cutoff = Date.now() - maxAgeMs;
    return [...this.pools.values()].filter(p => p.lastUpdatedMs >= cutoff);
  }

  isStale(address: PoolAddress, maxAgeMs = POOL_STALE_THRESHOLD_MS): boolean {
    const pool = this.pools.get(address);
    if (!pool) return true;
    return Date.now() - pool.lastUpdatedMs > maxAgeMs;
  }

  getPoolCount(): number {
    return this.pools.size;
  }

  private hasSignificantChange(prev: PoolState, next: PoolState): boolean {
    // Emit event only when price changes by > 0.01% or reserves change
    const priceDelta = Math.abs(next.price - prev.price) / (prev.price || 1);
    return priceDelta > 0.0001 ||
      next.reserveA !== prev.reserveA ||
      next.reserveB !== prev.reserveB;
  }

  private pairKey(a: TokenMint, b: TokenMint): string {
    return `${a}:${b}`;
  }

  logStats(): void {
    const fresh = this.getFreshPools().length;
    logger.info(
      { total: this.pools.size, fresh, stale: this.pools.size - fresh },
      'Pool monitor stats'
    );
  }
}
