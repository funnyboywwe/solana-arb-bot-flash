// src/market/registry/PoolRegistry.ts — NEW
// FIX: subscribeToMonitoredPairs() was a stub — PoolMonitor always had 0 pools.

import * as fs from 'fs';
import * as path from 'path';
import { PoolRegistryEntry } from '../../core/types';
import { createLogger } from '../../core/logger';

const logger = createLogger('PoolRegistry');
// Raydium v2 SDK URL deprecated. Using v3 API: https://api-v3.raydium.io
// /pools/info/list returns paginated results; we filter client-side by pair.
const RAYDIUM_URL = 'https://api-v3.raydium.io/pools/info/list?poolType=all&poolSortField=liquidity&sortType=desc&pageSize=100&page=1';
const ORCA_URL    = 'https://api.orca.so/v1/whirlpool/list';  // FIX: mainnet subdomain removed

export class PoolRegistry {
  private pools = new Map<string, PoolRegistryEntry>();
  private byPair = new Map<string, PoolRegistryEntry[]>();

  async load(fallbackPath: string, monitoredPairs: [string, string][]): Promise<void> {
    const local = this.loadFromDisk(fallbackPath);
    for (const e of local) this.register(e);
    logger.info({ count: this.pools.size }, 'Pool registry loaded from disk');
    this.refreshFromCDN(monitoredPairs).catch(err =>
      logger.warn({ err }, 'CDN pool refresh failed'));
  }

  private loadFromDisk(filePath: string): PoolRegistryEntry[] {
    if (!fs.existsSync(filePath)) return [];
    try { return JSON.parse(fs.readFileSync(filePath, 'utf8')) as PoolRegistryEntry[]; }
    catch { return []; }
  }

  private async refreshFromCDN(pairs: [string, string][]): Promise<void> {
    const set = new Set(pairs.flatMap(([a,b]) => [`${a}:${b}`,`${b}:${a}`]));
    await Promise.allSettled([this.fetchRaydium(set), this.fetchOrca(set)]);
    logger.info({ count: this.pools.size }, 'Pool registry refreshed from CDN');
  }

  private async fetchRaydium(pairSet: Set<string>): Promise<void> {
    try {
      const r = await fetch(RAYDIUM_URL, { signal: AbortSignal.timeout(15_000) });
      if (!r.ok) return;
      // v3 API returns { data: { data: RaydiumPool[] } }
      const resp = await r.json() as { data?: { data?: RaydiumPool[] } };
      for (const p of (resp.data?.data ?? [])) {
        const tokenA = p.mintA?.address ?? p.baseMint;
        const tokenB = p.mintB?.address ?? p.quoteMint;
        if (!tokenA || !tokenB) continue;
        if (!pairSet.has(`${tokenA}:${tokenB}`) &&
            !pairSet.has(`${tokenB}:${tokenA}`)) continue;
        this.register({
          // v3 API: id→id, mintA.address→tokenA, mintB.address→tokenB
          address: p.id, dex: 'raydium',
          poolType: p.type === 'concentrated' ? 'clmm' : 'amm_v4',
          tokenA,
          tokenB,
          vaultA: p.vaultA ?? p.baseVault,
          vaultB: p.vaultB ?? p.quoteVault,
          fee: p.feeRate ?? (p.fees?.swapFeeNumerator ?? 25) / (p.fees?.swapFeeDenominator ?? 10000),
          tvlUSD: p.tvl ?? p.liquidity,
        });
      }
    } catch (err) { logger.warn({ err }, 'Raydium CDN fetch failed'); }
  }

  private async fetchOrca(pairSet: Set<string>): Promise<void> {
    try {
      const r = await fetch(ORCA_URL, { signal: AbortSignal.timeout(15_000) });
      if (!r.ok) return;
      const d = await r.json() as { whirlpools?: OrcaPool[] };
      for (const p of (d.whirlpools ?? [])) {
        if (!pairSet.has(`${p.tokenA.mint}:${p.tokenB.mint}`) &&
            !pairSet.has(`${p.tokenB.mint}:${p.tokenA.mint}`)) continue;
        this.register({
          address: p.address, dex: 'orca', poolType: 'whirlpool',
          tokenA: p.tokenA.mint, tokenB: p.tokenB.mint,
          vaultA: p.tokenA.vault, vaultB: p.tokenB.vault,
          fee: p.feeRate / 1_000_000, tvlUSD: p.tvl,
        });
      }
    } catch (err) { logger.warn({ err }, 'Orca CDN fetch failed'); }
  }

  private register(e: PoolRegistryEntry): void {
    this.pools.set(e.address, e);
    for (const k of [`${e.tokenA}:${e.tokenB}`, `${e.tokenB}:${e.tokenA}`]) {
      if (!this.byPair.has(k)) this.byPair.set(k, []);
      const arr = this.byPair.get(k)!;
      if (!arr.find(x => x.address === e.address)) arr.push(e);
    }
  }

  getPool(addr: string) { return this.pools.get(addr); }
  getPoolsForPair(a: string, b: string) {
    return this.byPair.get(`${a}:${b}`) ?? this.byPair.get(`${b}:${a}`) ?? [];
  }
  getAllPools() { return [...this.pools.values()]; }
  size() { return this.pools.size; }

  async saveToDisk(filePath: string): Promise<void> {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify([...this.pools.values()], null, 2));
    logger.info({ filePath, count: this.pools.size }, 'Pool registry saved');
  }
}

// v3 API pool shape (https://api-v3.raydium.io/pools/info/list)
interface RaydiumPool {
  id: string;
  type?: string;                       // 'standard' | 'concentrated' | 'allFarm'
  // v3 fields
  mintA?: { address: string };          // tokenA mint
  mintB?: { address: string };          // tokenB mint
  vaultA?: string;
  vaultB?: string;
  feeRate?: number;                     // decimal fraction e.g. 0.0025
  tvl?: number;                         // USD TVL
  // v1 SDK legacy fallback fields (may be absent in v3)
  baseMint?: string; quoteMint?: string;
  baseVault?: string; quoteVault?: string; liquidity?: number;
  fees?: { swapFeeNumerator: number; swapFeeDenominator: number };
}
interface OrcaPool {
  address: string;
  tokenA: { mint: string; vault: string };
  tokenB: { mint: string; vault: string };
  feeRate: number; tvl?: number;
}
