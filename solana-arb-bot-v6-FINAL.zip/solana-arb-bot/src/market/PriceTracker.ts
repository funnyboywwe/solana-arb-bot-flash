// src/market/PriceTracker.ts
import { TokenPrice, TokenMint } from '../core/types';
import { createLogger } from '../core/logger';

const logger = createLogger('PriceTracker');

export class PriceTracker {
  private prices: Map<TokenMint, TokenPrice> = new Map();
  private readonly staleThresholdMs: number;

  constructor(staleThresholdMs = 30_000) {
    this.staleThresholdMs = staleThresholdMs;
  }

  updatePrice(price: TokenPrice): void {
    this.prices.set(price.mint, price);
    logger.trace({ mint: price.mint, symbol: price.symbol, price: price.priceUSD }, 'Price updated');
  }

  getPrice(mint: TokenMint): TokenPrice | undefined {
    return this.prices.get(mint);
  }

  getPriceUSD(mint: TokenMint): number | undefined {
    const p = this.prices.get(mint);
    if (!p) return undefined;
    if (Date.now() - p.lastUpdatedMs > this.staleThresholdMs) {
      logger.warn({ mint }, 'Price is stale');
      return undefined;
    }
    return p.priceUSD;
  }

  /** Convert lamports to USD */
  lamportsToUSD(mint: TokenMint, lamports: bigint, decimals: number): number {
    const priceUSD = this.getPriceUSD(mint);
    if (!priceUSD) return 0;
    return Number(lamports) / Math.pow(10, decimals) * priceUSD;
  }

  /** Convert USD to lamports */
  usdToLamports(mint: TokenMint, usd: number, decimals: number): bigint {
    const priceUSD = this.getPriceUSD(mint);
    if (!priceUSD || priceUSD === 0) return 0n;
    return BigInt(Math.floor((usd / priceUSD) * Math.pow(10, decimals)));
  }

  getAllPrices(): TokenPrice[] {
    return [...this.prices.values()];
  }
}
