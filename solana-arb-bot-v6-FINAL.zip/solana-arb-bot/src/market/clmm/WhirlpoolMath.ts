// src/market/clmm/WhirlpoolMath.ts — NEW
// FIX: Orca Whirlpool uses CLMM (Concentrated Liquidity), not xy=k.
//      Applying constant-product formula to a Whirlpool gives wrong quotes.
//
// This module implements the core CLMM swap math for Orca Whirlpools.
// Based on Orca's open-source math spec: https://orca-so.github.io/whirlpools/
//
// Key insight: in a CLMM, only liquidity in the current tick range is "active".
// For small-to-medium trades that don't cross tick boundaries, the math reduces
// to a modified constant-product formula using the sqrt_price and active liquidity.
//
// For trades that cross tick boundaries, you need tick arrays — not implemented
// here but flagged. Jupiter's quoting API handles this case correctly and should
// be used as a fallback for Orca.

import { WHIRLPOOL_LAYOUT } from '../../core/constants';
import { PoolState } from '../../core/types';

// Q64.64 fixed-point scaling factor
const Q64 = 2n ** 64n;

/**
 * Parse a Whirlpool account buffer and return a PoolState.
 * FIX: Previous implementation had wrong offsets and approximated CLMM
 *      reserves using sqrt_price * liquidity which is not the AMM formula.
 */
export function parseWhirlpoolAccount(address: string, data: Buffer): PoolState | null {
  const L = WHIRLPOOL_LAYOUT;
  if (data.length < L.TOTAL_SIZE) return null;

  try {
    // Validate discriminator (8 bytes at offset 0)
    // Whirlpool discriminator: [63, 149, 209, 12, 225, 128, 99, 9]
    // We skip strict check here to support all whirlpool variants

    const feeRate         = data.readUInt16LE(L.FEE_RATE);   // e.g. 3000 = 0.3%
    const fee             = feeRate / 1_000_000;              // decimal fraction

    // liquidity (u128 LE at LIQUIDITY offset)
    const liquidityLo     = data.readBigUInt64LE(L.LIQUIDITY);
    const liquidityHi     = data.readBigUInt64LE(L.LIQUIDITY + 8);
    const liquidity128    = liquidityLo | (liquidityHi << 64n);

    // sqrtPrice (u128 LE) — Q64.64 fixed-point
    const sqrtPriceLo     = data.readBigUInt64LE(L.SQRT_PRICE);
    const sqrtPriceHi     = data.readBigUInt64LE(L.SQRT_PRICE + 8);
    const sqrtPrice128    = sqrtPriceLo | (sqrtPriceHi << 64n);

    const tickCurrentIndex = data.readInt32LE(L.TICK_CURRENT_INDEX);

    const tokenMintA = readPubkey(data, L.TOKEN_MINT_A);
    const tokenMintB = readPubkey(data, L.TOKEN_MINT_B);

    // Estimate virtual reserves from sqrtPrice and liquidity
    // reserveA ≈ liquidity / sqrtPrice (in Q0 token units)
    // reserveB ≈ liquidity * sqrtPrice (in Q0 token units)
    // These are VIRTUAL reserves for the current tick — not total token amounts.
    // This is good enough for SINGLE-TICK arb simulation.
    const { virtualA, virtualB } = clmmVirtualReserves(sqrtPrice128, liquidity128);

    // Price: tokenA per tokenB = (sqrtPrice/2^64)^2
    const sqrtPriceFloat = Number(sqrtPrice128) / Number(Q64);
    const price = sqrtPriceFloat * sqrtPriceFloat;

    return {
      address,
      dex: 'orca',
      poolType: 'whirlpool',
      tokenA: tokenMintA,
      tokenB: tokenMintB,
      reserveA: virtualA,
      reserveB: virtualB,
      price,
      liquidity: 0, // USD assigned by caller
      lastUpdatedMs: Date.now(),
      fee,
      sqrtPrice: sqrtPrice128,
      tickCurrentIndex,
      liquidity128,
    };
  } catch {
    return null;
  }
}

/**
 * Compute CLMM swap output amount for a single-tick trade.
 * For trades crossing tick boundaries, fall back to Jupiter quoting.
 *
 * Reference: https://uniswap.org/whitepaper-v3.pdf, Section 6.1
 *
 * aToB: true = tokenA in, tokenB out
 *       false = tokenB in, tokenA out
 */
export function clmmGetAmountOut(
  amountIn: bigint,
  sqrtPrice: bigint,
  liquidity: bigint,
  aToB: boolean,
  feeNumerator: bigint,
  feeDenominator: bigint,
): { amountOut: bigint; sqrtPriceNew: bigint; crossesTick: boolean } {
  if (liquidity === 0n || amountIn === 0n) {
    return { amountOut: 0n, sqrtPriceNew: sqrtPrice, crossesTick: false };
  }

  // Apply fee: amountInAfterFee = amountIn * (denom - num) / denom
  const feeComp = feeDenominator - feeNumerator;
  const amountInAfterFee = (amountIn * feeComp) / feeDenominator;

  let amountOut: bigint;
  let sqrtPriceNew: bigint;

  if (aToB) {
    // Selling tokenA for tokenB
    // sqrtPriceNew = sqrtPrice * liquidity / (liquidity + amountInAfterFee * sqrtPrice / Q64)
    // amountOut = liquidity * (sqrtPrice - sqrtPriceNew) / Q64
    const denom = liquidity + (amountInAfterFee * sqrtPrice / Q64);
    sqrtPriceNew = (sqrtPrice * liquidity) / denom;
    const sqrtDelta = sqrtPrice > sqrtPriceNew ? sqrtPrice - sqrtPriceNew : 0n;
    amountOut = (liquidity * sqrtDelta) / Q64;
  } else {
    // Selling tokenB for tokenA
    // sqrtPriceNew = sqrtPrice + amountInAfterFee * Q64 / liquidity
    sqrtPriceNew = sqrtPrice + (amountInAfterFee * Q64) / liquidity;
    const sqrtDelta = sqrtPriceNew > sqrtPrice ? sqrtPriceNew - sqrtPrice : 0n;
    // amountOut = liquidity * Q64 / sqrtPrice - liquidity * Q64 / sqrtPriceNew
    const invCurrent = (liquidity * Q64) / sqrtPrice;
    const invNew = (liquidity * Q64) / sqrtPriceNew;
    amountOut = invCurrent > invNew ? invCurrent - invNew : 0n;
    // Restore sqrtPriceNew direction
    sqrtPriceNew = sqrtPrice + sqrtDelta;
  }

  // Heuristic: if price moved more than 5%, likely crosses a tick boundary
  // In that case, result is an underestimate — flag for Jupiter re-quote
  const priceMovePct = Number(
    sqrtPriceNew > sqrtPrice
      ? ((sqrtPriceNew - sqrtPrice) * 10_000n) / sqrtPrice
      : ((sqrtPrice - sqrtPriceNew) * 10_000n) / sqrtPrice,
  ) / 100;

  return {
    amountOut,
    sqrtPriceNew,
    crossesTick: priceMovePct > 5,
  };
}

/**
 * Estimate virtual reserves from sqrtPrice and liquidity.
 * These are the "effective" reserves at the current price tick.
 */
function clmmVirtualReserves(sqrtPrice: bigint, liquidity: bigint): {
  virtualA: bigint;
  virtualB: bigint;
} {
  if (liquidity === 0n || sqrtPrice === 0n) return { virtualA: 0n, virtualB: 0n };
  // virtualA = liquidity * Q64 / sqrtPrice
  // virtualB = liquidity * sqrtPrice / Q64
  const virtualA = (liquidity * Q64) / sqrtPrice;
  const virtualB = (liquidity * sqrtPrice) / Q64;
  return { virtualA, virtualB };
}

function readPubkey(data: Buffer, offset: number): string {
  // Encode 32 bytes as a base58 Solana public key string.
  // Import PublicKey here to avoid circular deps at module level.
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { PublicKey } = require('@solana/web3.js') as typeof import('@solana/web3.js');
  return new PublicKey(data.slice(offset, offset + 32)).toBase58();
}
