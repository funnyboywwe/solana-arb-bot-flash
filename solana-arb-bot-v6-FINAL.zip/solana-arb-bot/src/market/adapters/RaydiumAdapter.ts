// src/market/adapters/RaydiumAdapter.ts — v3 (batched polling)
// CHANGE (v3): Replaced per-account WebSocket subscriptions (onAccountChange)
//   with batched polling via getMultipleAccountsInfo. The old design opened
//   ~3 subscriptions per pool (pool account + 2 vaults), which on a 15 req/s
//   free RPC tier triggered -32007 rate-limit storms and left ~96% of pools
//   stale. Now ALL pool/vault accounts are fetched in a single batched RPC
//   call per poll cycle (chunked at 100 accounts max).

import { Connection, PublicKey, AccountInfo } from '@solana/web3.js';
import { EventEmitter } from 'events';
import { PoolState } from '../../core/types';
import { createLogger } from '../../core/logger';
import { RAYDIUM_AMM_LAYOUT } from '../../core/constants';
import { PoolRegistryEntry } from '../../core/types';

const logger = createLogger('RaydiumAdapter');

interface CachedPoolMeta {
  coinMint: string;
  pcMint: string;
  coinVault: string;
  pcVault: string;
  feeNumerator: bigint;
  feeDenominator: bigint;
}

export class RaydiumAdapter extends EventEmitter {
  // address -> registry entry
  private pools     = new Map<string, PoolRegistryEntry>();
  private poolMeta  = new Map<string, CachedPoolMeta>();
  private reserves  = new Map<string, { reserveA: bigint; reserveB: bigint }>();

  constructor(
    private readonly connection: Connection,
    private readonly programId_unused: string,
  ) { super(); }

  /** Register a pool for polling. Does NOT perform any RPC call. */
  registerPool(entry: PoolRegistryEntry): void {
    this.pools.set(entry.address, entry);
  }

  /** Back-compat alias: registration only, no subscription. */
  async subscribeToPool(entry: PoolRegistryEntry): Promise<void> {
    this.registerPool(entry);
  }

  /**
   * Refresh ALL registered pools using batched getMultipleAccountsInfo.
   * Phase 1: fetch+parse pool meta for any pool missing it (vault addresses).
   * Phase 2: batch-fetch all vault token accounts and read balances.
   * Phase 3: emit updated PoolState for every pool with meta + reserves.
   */
  async refreshAll(): Promise<void> {
    const addresses = [...this.pools.keys()];
    if (addresses.length === 0) return;

    // ── Phase 1: meta (only for pools we haven't parsed yet) ──────────────
    const missingMeta = addresses.filter(a => !this.poolMeta.has(a));
    if (missingMeta.length > 0) {
      const infos = await this.getMultiple(missingMeta.map(a => new PublicKey(a)));
      missingMeta.forEach((addr, i) => {
        const info = infos[i];
        if (info?.data && info.data.length >= RAYDIUM_AMM_LAYOUT.TOTAL_SIZE) {
          this.poolMeta.set(addr, this.parsePoolMeta(info.data as Buffer));
        } else {
          logger.warn({ address: addr }, 'Raydium pool account too small or missing');
        }
      });
    }

    // ── Phase 2: vault balances (single batched call for every vault) ─────
    const vaultRefs: Array<{ pool: string; side: 'A' | 'B'; vault: string }> = [];
    for (const addr of addresses) {
      const meta = this.poolMeta.get(addr);
      if (!meta) continue;
      vaultRefs.push({ pool: addr, side: 'A', vault: meta.coinVault });
      vaultRefs.push({ pool: addr, side: 'B', vault: meta.pcVault });
    }
    if (vaultRefs.length === 0) return;

    const vaultInfos = await this.getMultiple(vaultRefs.map(v => new PublicKey(v.vault)));
    vaultRefs.forEach((ref, i) => {
      const info = vaultInfos[i];
      if (!info?.data || info.data.length < 72) return;
      const balance = (info.data as Buffer).readBigUInt64LE(64); // SPL token amount @ bytes 64-71
      const res = this.reserves.get(ref.pool) ?? { reserveA: 0n, reserveB: 0n };
      if (ref.side === 'A') this.reserves.set(ref.pool, { ...res, reserveA: balance });
      else                  this.reserves.set(ref.pool, { ...res, reserveB: balance });
    });

    // ── Phase 3: emit ────────────────────────────────────────────────────
    for (const addr of addresses) this.emitPoolState(addr);
  }

  /** Batched getMultipleAccountsInfo, chunked to the 100-account RPC limit. */
  private async getMultiple(pubkeys: PublicKey[]): Promise<Array<AccountInfo<Buffer> | null>> {
    const out: Array<AccountInfo<Buffer> | null> = [];
    for (let i = 0; i < pubkeys.length; i += 100) {
      const chunk = pubkeys.slice(i, i + 100);
      const infos = await this.connection.getMultipleAccountsInfo(chunk, 'confirmed');
      out.push(...infos);
    }
    return out;
  }

  private parsePoolMeta(data: Buffer): CachedPoolMeta {
    const L = RAYDIUM_AMM_LAYOUT;
    return {
      coinMint:       new PublicKey(data.slice(L.COIN_MINT, L.COIN_MINT + 32)).toBase58(),
      pcMint:         new PublicKey(data.slice(L.PC_MINT,   L.PC_MINT   + 32)).toBase58(),
      coinVault:      new PublicKey(data.slice(L.COIN_VAULT, L.COIN_VAULT + 32)).toBase58(),
      pcVault:        new PublicKey(data.slice(L.PC_VAULT,   L.PC_VAULT  + 32)).toBase58(),
      feeNumerator:   data.readBigUInt64LE(L.SWAP_FEE_NUMERATOR),
      feeDenominator: data.readBigUInt64LE(L.SWAP_FEE_DENOMINATOR),
    };
  }

  private emitPoolState(poolAddress: string): void {
    const meta = this.poolMeta.get(poolAddress);
    const res  = this.reserves.get(poolAddress);
    if (!meta || !res) return;

    const { reserveA, reserveB } = res;
    const fee = meta.feeDenominator > 0n
      ? Number(meta.feeNumerator) / Number(meta.feeDenominator)
      : 0.0025;

    // Spot price: reserveA / reserveB (coinMint per pcMint)
    const price = reserveB > 0n
      ? Number(reserveA) / Number(reserveB)
      : 0;

    const liquidity = 0; // USD assigned by PriceTracker in MarketDataService

    const pool: PoolState = {
      address: poolAddress,
      dex: 'raydium',
      poolType: 'amm_v4',
      tokenA: meta.coinMint,
      tokenB: meta.pcMint,
      reserveA,
      reserveB,
      price,
      liquidity,
      lastUpdatedMs: Date.now(),
      fee,
      vaultA: meta.coinVault,
      vaultB: meta.pcVault,
    };

    this.emit('pool_updated', pool);
  }

  async unsubscribeAll(): Promise<void> {
    this.pools.clear();
    this.poolMeta.clear();
    this.reserves.clear();
    logger.info('Cleared all Raydium pools');
  }
}
