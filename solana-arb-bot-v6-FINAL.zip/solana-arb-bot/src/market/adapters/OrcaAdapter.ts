// src/market/adapters/OrcaAdapter.ts — v3 (batched polling)
// CHANGE (v3): Replaced onAccountChange WebSocket subscriptions with batched
//   polling via getMultipleAccountsInfo. All whirlpool accounts are fetched in
//   a single batched RPC call per poll cycle (chunked at 100 accounts max),
//   eliminating the -32007 rate-limit storm on free-tier RPC.

import { Connection, PublicKey, AccountInfo } from '@solana/web3.js';
import { EventEmitter } from 'events';
import { createLogger } from '../../core/logger';
import { parseWhirlpoolAccount } from '../clmm/WhirlpoolMath';
import { PoolRegistryEntry } from '../../core/types';

const logger = createLogger('OrcaAdapter');

export class OrcaAdapter extends EventEmitter {
  private pools = new Map<string, PoolRegistryEntry>();

  constructor(
    private readonly connection: Connection,
    private readonly programId_unused: string,
  ) { super(); }

  /** Register a whirlpool for polling. Does NOT perform any RPC call. */
  registerWhirlpool(entry: PoolRegistryEntry): void {
    this.pools.set(entry.address, entry);
  }

  /** Back-compat alias: registration only, no subscription. */
  async subscribeToWhirlpool(entry: PoolRegistryEntry): Promise<void> {
    this.registerWhirlpool(entry);
  }

  /** Refresh ALL registered whirlpools using a single batched RPC call. */
  async refreshAll(): Promise<void> {
    const addresses = [...this.pools.keys()];
    if (addresses.length === 0) return;

    const infos = await this.getMultiple(addresses.map(a => new PublicKey(a)));
    addresses.forEach((addr, i) => {
      const info = infos[i];
      if (!info?.data) return;
      const pool = parseWhirlpoolAccount(addr, info.data as Buffer);
      if (pool) this.emit('pool_updated', pool);
    });
  }

  /** Batched getMultipleAccountsInfo, chunked to the 100-account RPC limit. */
  private async getMultiple(pubkeys: PublicKey[]): Promise<Array<AccountInfo<Buffer> | null>> {
    const out: Array<AccountInfo<Buffer> | null> = [];
    for (let i = 0; i < pubkeys.length; i += 100) {
      const chunk = pubkeys.slice(i, i + 100);
      const infos = await this.connection.getMultipleAccountsInfo(chunk, 'confirmed');
      out.push(...infos);
    }
    return out;
  }

  async unsubscribeAll(): Promise<void> {
    this.pools.clear();
    logger.info('Cleared all Orca Whirlpools');
  }
}
