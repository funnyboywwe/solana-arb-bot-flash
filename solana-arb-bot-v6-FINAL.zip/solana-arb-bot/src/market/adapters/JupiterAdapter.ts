// src/market/adapters/JupiterAdapter.ts
import { createLogger } from '../../core/logger';
import { ArbitrageRoute, SwapHop } from '../../core/types';

const logger = createLogger('JupiterAdapter');

interface JupiterQuoteResponse {
  inputMint: string;
  outputMint: string;
  inAmount: string;
  outAmount: string;
  priceImpactPct: string;
  routePlan: Array<{
    swapInfo: {
      ammKey: string;
      label: string;
      inputMint: string;
      outputMint: string;
      inAmount: string;
      outAmount: string;
      feeAmount: string;
      feeMint: string;
    };
    percent: number;
  }>;
  slippageBps: number;
  otherAmountThreshold: string;
}

interface JupiterSwapTransaction {
  swapTransaction: string;  // base64 encoded
}

export class JupiterAdapter {
  constructor(private readonly apiUrl: string) {}

  async getQuote(
    inputMint: string,
    outputMint: string,
    amountLamports: bigint,
    slippageBps = 50
  ): Promise<JupiterQuoteResponse | null> {
    try {
      const url = new URL(`${this.apiUrl}/quote`);
      url.searchParams.set('inputMint', inputMint);
      url.searchParams.set('outputMint', outputMint);
      url.searchParams.set('amount', amountLamports.toString());
      url.searchParams.set('slippageBps', slippageBps.toString());
      url.searchParams.set('onlyDirectRoutes', 'false');
      url.searchParams.set('asLegacyTransaction', 'false');

      const resp = await fetch(url.toString(), {
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(3_000),
      });

      if (!resp.ok) {
        logger.warn({ status: resp.status }, 'Jupiter quote request failed');
        return null;
      }

      return await resp.json() as JupiterQuoteResponse;
    } catch (err) {
      logger.warn({ err }, 'Jupiter quote fetch failed');
      return null;
    }
  }

  async getSwapTransaction(
    quoteResponse: JupiterQuoteResponse,
    userPublicKey: string,
    priorityFeeLamports = 5000
  ): Promise<JupiterSwapTransaction | null> {
    try {
      const resp = await fetch(`${this.apiUrl}/swap`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          quoteResponse,
          userPublicKey,
          wrapAndUnwrapSol: true,
          prioritizationFeeLamports: priorityFeeLamports,
          asLegacyTransaction: false,
        }),
        signal: AbortSignal.timeout(5_000),
      });

      if (!resp.ok) {
        logger.warn({ status: resp.status }, 'Jupiter swap request failed');
        return null;
      }

      return await resp.json() as JupiterSwapTransaction;
    } catch (err) {
      logger.warn({ err }, 'Jupiter swap fetch failed');
      return null;
    }
  }

  quoteToRoute(quote: JupiterQuoteResponse, amountIn: bigint): ArbitrageRoute {
    const hops: SwapHop[] = quote.routePlan.map(step => ({
      dex: 'jupiter',
      poolAddress: step.swapInfo.ammKey,
      tokenIn: step.swapInfo.inputMint,
      tokenOut: step.swapInfo.outputMint,
      fee: Number(step.swapInfo.feeAmount) / Number(step.swapInfo.inAmount),
    }));

    return {
      id: `jupiter-${Date.now()}`,
      hops,
      tokenIn: quote.inputMint,
      tokenOut: quote.outputMint,
      estimatedAmountIn: amountIn,
      estimatedAmountOut: BigInt(quote.outAmount), loanAmountUSD: 0,
    };
  }
}
