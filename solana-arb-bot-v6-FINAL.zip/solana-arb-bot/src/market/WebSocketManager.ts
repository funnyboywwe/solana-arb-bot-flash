// src/market/WebSocketManager.ts
import WebSocket from 'ws';
import { EventEmitter } from 'events';
import { createLogger } from '../core/logger';
import { RECONNECT_DELAY_MS, MAX_RECONNECT_ATTEMPTS } from '../core/constants';

const logger = createLogger('WebSocketManager');

export interface WsMessage {
  type: string;
  data: unknown;
}

export class WebSocketManager extends EventEmitter {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private _isConnected = false;
  private shouldReconnect = true;
  private pendingSubscriptions: Array<() => void> = [];

  constructor(
    private readonly url: string,
    private readonly name: string
  ) {
    super();
  }

  get isConnected(): boolean {
    return this._isConnected;
  }

  connect(): void {
    if (this.ws?.readyState === WebSocket.OPEN) return;

    logger.info({ url: this.url, name: this.name }, 'Connecting WebSocket');

    this.ws = new WebSocket(this.url);

    this.ws.on('open', () => {
      this._isConnected = true;
      this.reconnectAttempts = 0;
      logger.info({ name: this.name }, 'WebSocket connected');
      this.emit('connected');

      // Re-subscribe
      for (const sub of this.pendingSubscriptions) {
        sub();
      }
    });

    this.ws.on('message', (data: Buffer) => {
      try {
        const msg = JSON.parse(data.toString()) as WsMessage;
        this.emit('message', msg);
      } catch {
        logger.warn({ name: this.name }, 'Failed to parse WS message');
      }
    });

    this.ws.on('close', (code: number) => {
      this._isConnected = false;
      logger.warn({ code, name: this.name }, 'WebSocket closed');
      this.emit('disconnected');

      if (this.shouldReconnect) {
        this.scheduleReconnect();
      }
    });

    this.ws.on('error', (err: Error) => {
      logger.error({ err, name: this.name }, 'WebSocket error');
      this.emit('error', err);
    });

    // Keep-alive ping
    this.ws.on('ping', () => {
      this.ws?.pong();
    });
  }

  send(data: unknown): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error(`WebSocket ${this.name} not connected`);
    }
    this.ws.send(JSON.stringify(data));
  }

  addPendingSubscription(fn: () => void): void {
    this.pendingSubscriptions.push(fn);
    if (this._isConnected) fn();
  }

  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      logger.error({ name: this.name }, 'Max reconnect attempts reached');
      this.emit('fatal', new Error(`WebSocket ${this.name} failed permanently`));
      return;
    }

    const delay = RECONNECT_DELAY_MS * Math.pow(1.5, this.reconnectAttempts);
    this.reconnectAttempts++;

    logger.info({ attempt: this.reconnectAttempts, delayMs: delay, name: this.name }, 'Scheduling reconnect');

    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }

  disconnect(): void {
    this.shouldReconnect = false;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this._isConnected = false;
  }
}
