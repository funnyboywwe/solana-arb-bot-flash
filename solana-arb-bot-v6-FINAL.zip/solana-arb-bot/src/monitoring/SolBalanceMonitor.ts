// src/monitoring/SolBalanceMonitor.ts — NEW
// FIX: No SOL balance floor guard — bot drains fees paying for failed txs.
// Monitors native SOL balance. Triggers emergency stop if below floor.

import { Connection, PublicKey } from '@solana/web3.js';
import { createLogger } from '../core/logger';
import { AlertManager } from './AlertManager';
import { EmergencyStop } from '../risk/EmergencyStop';

const logger = createLogger('SolBalanceMonitor');

const CHECK_INTERVAL_MS = 30_000;   // every 30s
const WARN_THRESHOLD_SOL = 0.05;    // warn at 0.05 SOL
const STOP_THRESHOLD_SOL = 0.01;    // stop at 0.01 SOL

export class SolBalanceMonitor {
  private timer: NodeJS.Timeout | null = null;
  private lastBalanceSol = 0;

  constructor(
    private readonly connection: Connection,
    private readonly walletPubkey: PublicKey,
    private readonly emergencyStop: EmergencyStop,
    private readonly alertManager: AlertManager,
  ) {}

  start(): void {
    this.check().catch(() => {});
    this.timer = setInterval(() => this.check().catch(() => {}), CHECK_INTERVAL_MS);
    logger.info('SOL balance monitor started');
  }

  stop(): void {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  }

  getLastBalance(): number { return this.lastBalanceSol; }

  private async check(): Promise<void> {
    try {
      const lamports = await this.connection.getBalance(this.walletPubkey, 'confirmed');
      this.lastBalanceSol = lamports / 1e9;

      logger.trace({ solBalance: this.lastBalanceSol }, 'SOL balance checked');

      if (this.lastBalanceSol < STOP_THRESHOLD_SOL) {
        logger.error({ balance: this.lastBalanceSol }, '🚨 SOL balance critically low — stopping');
        this.emergencyStop.trigger(`SOL balance ${this.lastBalanceSol.toFixed(4)} < minimum ${STOP_THRESHOLD_SOL}`);
        await this.alertManager.sendAlert('critical', 'SOL Balance Critical',
          `Wallet SOL: ${this.lastBalanceSol.toFixed(4)} SOL — bot halted.`);

      } else if (this.lastBalanceSol < WARN_THRESHOLD_SOL) {
        logger.warn({ balance: this.lastBalanceSol }, 'SOL balance low');
        await this.alertManager.sendAlert('warning', 'SOL Balance Low',
          `Wallet SOL: ${this.lastBalanceSol.toFixed(4)} SOL — refill soon.`);
      }
    } catch (err) {
      logger.warn({ err }, 'SOL balance check failed');
    }
  }
}
