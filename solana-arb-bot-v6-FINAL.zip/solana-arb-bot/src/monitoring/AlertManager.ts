// src/monitoring/AlertManager.ts
import { createLogger } from '../core/logger';
import { TradeRecord } from '../core/types';

const logger = createLogger('AlertManager');

export type AlertLevel = 'info' | 'warning' | 'critical';

export class AlertManager {
  constructor(private readonly webhookUrl: string) {}

  async sendAlert(level: AlertLevel, title: string, message: string): Promise<void> {
    if (!this.webhookUrl) return;

    const colors: Record<AlertLevel, number> = {
      info: 0x00ff00,
      warning: 0xffa500,
      critical: 0xff0000,
    };

    const emojis: Record<AlertLevel, string> = {
      info: '✅',
      warning: '⚠️',
      critical: '🚨',
    };

    const payload = {
      embeds: [
        {
          title: `${emojis[level]} ${title}`,
          description: message,
          color: colors[level],
          timestamp: new Date().toISOString(),
          footer: { text: 'Solana Arb Bot' },
        },
      ],
    };

    try {
      const resp = await fetch(this.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(5_000),
      });

      if (!resp.ok) {
        logger.warn({ status: resp.status }, 'Alert webhook failed');
      }
    } catch (err) {
      logger.warn({ err }, 'Failed to send alert');
    }
  }

  async alertTradeSuccess(trade: TradeRecord): Promise<void> {
    if (trade.netProfitUSD < 1) return; // Only alert significant wins
    await this.sendAlert(
      'info',
      'Trade Executed',
      `Profit: **$${trade.netProfitUSD.toFixed(4)}** | Tx: \`${trade.txSignature?.slice(0, 16)}...\``
    );
  }

  async alertCircuitBreaker(reason: string): Promise<void> {
    await this.sendAlert('critical', 'Circuit Breaker Triggered', reason);
  }

  async alertEmergencyStop(reason: string): Promise<void> {
    await this.sendAlert('critical', 'Emergency Stop', reason);
  }

  async alertDailySummary(
    date: string,
    trades: number,
    netProfitUSD: number,
    winRate: number
  ): Promise<void> {
    const level: AlertLevel = netProfitUSD >= 0 ? 'info' : 'warning';
    await this.sendAlert(
      level,
      `Daily Summary — ${date}`,
      `Trades: ${trades} | Net: **$${netProfitUSD.toFixed(2)}** | Win Rate: ${(winRate * 100).toFixed(1)}%`
    );
  }
}
