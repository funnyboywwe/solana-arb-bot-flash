// src/monitoring/HealthCheck.ts
import * as http from 'http';
import { createLogger } from '../core/logger';
import { CircuitBreaker } from '../risk/CircuitBreaker';
import { EmergencyStop } from '../risk/EmergencyStop';
import { PoolMonitor } from '../market/PoolMonitor';
import { ProfitTracker } from '../tracking/ProfitTracker';

const logger = createLogger('HealthCheck');

interface HealthStatus {
  status: 'ok' | 'degraded' | 'stopped';
  uptime: number;
  timestamp: string;
  circuit_breaker: { tripped: boolean; reason?: string; consecutive_losses: number };
  emergency_stop: boolean;
  pools: { total: number; fresh: number };
  session: { trades: number; wins: number; net_profit_usd: number; win_rate: number };
  today_pnl: { net_profit_usd: number; trades: number } | null;
}

export class HealthCheck {
  private server: http.Server | null = null;
  private readonly startTime = Date.now();

  constructor(
    private readonly port: number,
    private readonly circuitBreaker: CircuitBreaker,
    private readonly emergencyStop: EmergencyStop,
    private readonly poolMonitor: PoolMonitor,
    private readonly profitTracker: ProfitTracker
  ) {}

  start(): void {
    this.server = http.createServer((req, res) => {
      if (req.url === '/health' || req.url === '/') {
        this.handleHealth(res);
      } else if (req.url === '/pnl') {
        this.handlePnL(res);
      } else if (req.url === '/trades') {
        this.handleTrades(res);
      } else {
        res.writeHead(404);
        res.end('Not found');
      }
    });

    this.server.listen(this.port, '127.0.0.1', () => {
      logger.info({ port: this.port }, 'Health check server listening');
    });

    this.server.on('error', (err: Error) => {
      logger.warn({ err }, 'Health check server error');
    });
  }

  private handleHealth(res: http.ServerResponse): void {
    const cbStatus = this.circuitBreaker.getStatus();
    const freshPools = this.poolMonitor.getFreshPools().length;
    const session = this.profitTracker.getSessionStats();
    const todayPnL = this.profitTracker.getTodayPnL();

    const isStopped = this.emergencyStop.isStopped() || cbStatus.tripped;

    const status: HealthStatus = {
      status: isStopped ? 'stopped' : freshPools > 0 ? 'ok' : 'degraded',
      uptime: Math.floor((Date.now() - this.startTime) / 1000),
      timestamp: new Date().toISOString(),
      circuit_breaker: {
        tripped: cbStatus.tripped,
        reason: cbStatus.reason || undefined,
        consecutive_losses: cbStatus.consecutiveLosses,
      },
      emergency_stop: this.emergencyStop.isStopped(),
      pools: {
        total: this.poolMonitor.getPoolCount(),
        fresh: freshPools,
      },
      session: {
        trades: session.trades,
        wins: session.wins,
        net_profit_usd: session.netProfitUSD,
        win_rate: session.winRate,
      },
      today_pnl: todayPnL
        ? { net_profit_usd: todayPnL.netProfitUSD, trades: todayPnL.tradesTotal }
        : null,
    };

    const httpStatus = status.status === 'ok' ? 200 : status.status === 'degraded' ? 200 : 503;
    res.writeHead(httpStatus, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(status, null, 2));
  }

  private handlePnL(res: http.ServerResponse): void {
    const summary = this.profitTracker.getSummary(30);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(summary, null, 2));
  }

  private handleTrades(res: http.ServerResponse): void {
    const trades = this.profitTracker.getRecentTrades(20);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(trades, null, 2));
  }

  stop(): void {
    this.server?.close();
    logger.info('Health check server stopped');
  }
}
