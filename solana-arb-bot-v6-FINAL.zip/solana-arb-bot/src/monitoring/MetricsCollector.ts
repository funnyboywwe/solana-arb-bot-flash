// src/monitoring/MetricsCollector.ts — NEW
// FIX: No metrics surface other than JSON health endpoint.
// Exposes Prometheus-compatible metrics via /metrics endpoint.
// Tracks: latency, scan rate, win rate, RPC health, priority fees.

import * as http from 'http';
import { createLogger } from '../core/logger';

const logger = createLogger('MetricsCollector');


export class MetricsCollector {
  // ── Counters ────────────────────────────────────────────────────────────────
  opportunitiesDetected = 0;
  opportunitiesRejectedProfit = 0;
  opportunitiesRejectedRisk = 0;
  opportunitiesRejectedSim = 0;
  tradesExecuted = 0;
  tradesSucceeded = 0;
  tradesFailed = 0;
  rpcErrors = 0;

  // ── Gauges ──────────────────────────────────────────────────────────────────
  activePoolCount = 0;
  freshPoolCount = 0;
  priorityFeeP75 = 0;
  priorityFeeP95 = 0;
  blockhashAgeMs = 0;
  dailyNetProfitUSD = 0;
  sessionWinRate = 0;
  solBalanceLamports = 0;

  // ── Histograms ──────────────────────────────────────────────────────────────
  private opportunityLatencyMs: number[] = [];    // scan → decision
  private executionLatencyMs: number[] = [];       // decision → submit
  private confirmLatencyMs: number[] = [];         // submit → confirm

  recordOpportunityLatency(ms: number): void { this.opportunityLatencyMs.push(ms); this.trim(this.opportunityLatencyMs); }
  recordExecutionLatency(ms: number):  void { this.executionLatencyMs.push(ms);  this.trim(this.executionLatencyMs); }
  recordConfirmLatency(ms: number):    void { this.confirmLatencyMs.push(ms);    this.trim(this.confirmLatencyMs); }

  private trim(arr: number[]): void { if (arr.length > 1000) arr.splice(0, arr.length - 1000); }

  private percentile(arr: number[], p: number): number {
    if (!arr.length) return 0;
    const sorted = [...arr].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length * p / 100)] ?? 0;
  }

  /** Prometheus text format */
  toPrometheusText(): string {
    const lines: string[] = [];

    const gauge = (name: string, help: string, value: number) => {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} gauge`);
      lines.push(`${name} ${value}`);
    };

    const counter = (name: string, help: string, value: number) => {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} counter`);
      lines.push(`${name}_total ${value}`);
    };

    const hist = (name: string, help: string, vals: number[]) => {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} summary`);
      lines.push(`${name}{quantile="0.5"} ${this.percentile(vals, 50)}`);
      lines.push(`${name}{quantile="0.75"} ${this.percentile(vals, 75)}`);
      lines.push(`${name}{quantile="0.95"} ${this.percentile(vals, 95)}`);
      lines.push(`${name}{quantile="0.99"} ${this.percentile(vals, 99)}`);
      lines.push(`${name}_sum ${vals.reduce((a,b)=>a+b,0)}`);
      lines.push(`${name}_count ${vals.length}`);
    };

    counter('arb_opportunities_detected',      'Total opportunities detected', this.opportunitiesDetected);
    counter('arb_opportunities_rejected_profit','Rejected: insufficient profit', this.opportunitiesRejectedProfit);
    counter('arb_opportunities_rejected_risk',  'Rejected: risk validation', this.opportunitiesRejectedRisk);
    counter('arb_opportunities_rejected_sim',   'Rejected: simulation failure', this.opportunitiesRejectedSim);
    counter('arb_trades_executed',  'Total trades executed', this.tradesExecuted);
    counter('arb_trades_succeeded', 'Trades succeeded', this.tradesSucceeded);
    counter('arb_trades_failed',    'Trades failed', this.tradesFailed);
    counter('arb_rpc_errors',       'RPC errors', this.rpcErrors);

    gauge('arb_pool_count_active',    'Active pool count', this.activePoolCount);
    gauge('arb_pool_count_fresh',     'Fresh pool count (<5s)', this.freshPoolCount);
    gauge('arb_priority_fee_p75',     'Priority fee microlamports p75', this.priorityFeeP75);
    gauge('arb_priority_fee_p95',     'Priority fee microlamports p95', this.priorityFeeP95);
    gauge('arb_blockhash_age_ms',     'Blockhash cache age ms', this.blockhashAgeMs);
    gauge('arb_daily_net_profit_usd', 'Daily net profit USD', this.dailyNetProfitUSD);
    gauge('arb_session_win_rate',     'Session win rate (0-1)', this.sessionWinRate);
    gauge('arb_sol_balance_lamports', 'Bot wallet SOL balance lamports', this.solBalanceLamports);

    hist('arb_opportunity_latency_ms', 'Opportunity scan to decision latency ms', this.opportunityLatencyMs);
    hist('arb_execution_latency_ms',   'Decision to submission latency ms', this.executionLatencyMs);
    hist('arb_confirm_latency_ms',     'Submission to confirmation latency ms', this.confirmLatencyMs);

    return lines.join('\n') + '\n';
  }
}

/** Lightweight HTTP server exposing /metrics for Prometheus scraping */
export class MetricsServer {
  private server: http.Server | null = null;

  constructor(private readonly metrics: MetricsCollector, private readonly port: number) {}

  start(): void {
    this.server = http.createServer((req, res) => {
      if (req.url === '/metrics') {
        res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
        res.end(this.metrics.toPrometheusText());
      } else {
        res.writeHead(404); res.end();
      }
    });
    this.server.listen(this.port, '127.0.0.1', () =>
      logger.info({ port: this.port }, 'Metrics server listening'));
  }

  stop(): void { this.server?.close(); }
}
