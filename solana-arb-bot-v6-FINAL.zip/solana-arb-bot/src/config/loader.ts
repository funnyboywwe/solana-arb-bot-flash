// src/config/loader.ts — v2
// Added: rpc.endpoint2/ws2 for failover, monitoring.metricsPort,
//        security.jitoEnabled, updated risk fields.

import * as fs from 'fs';
import * as path from 'path';
import * as yaml from 'js-yaml';
import * as dotenv from 'dotenv';
import { z } from 'zod';
import { ConfigError } from '../core/errors';

dotenv.config();

const DexConfigSchema = z.object({
  enabled:   z.boolean(),
  programId: z.string(),
  wsUrl:     z.string().optional(),
  apiUrl:    z.string().optional(),
});

const ConfigSchema = z.object({
  rpc: z.object({
    endpoint:    z.string().url(),
    wsEndpoint:  z.string(),
    commitment:  z.enum(['processed', 'confirmed', 'finalized']),
    maxRetries:  z.number().int().positive(),
    timeoutMs:   z.number().int().positive(),
  }),
  wallet: z.object({ keypairPath: z.string() }),
  dexes: z.object({
    raydium: DexConfigSchema,
    orca:    DexConfigSchema,
    jupiter: DexConfigSchema,
  }),
  scanner: z.object({
    intervalMs:     z.number().int().positive(),
    minSpreadPct:   z.number().positive(),
    maxHops:        z.number().int().min(2).max(3),
    monitoredPairs: z.array(z.tuple([z.string(), z.string()])),
  }),
  flashLoan: z.object({
    provider:           z.enum(['marginfi', 'solend']),
    maxLoanAmountUSD:   z.number().positive(),
    feeMultiplier:      z.number().min(1),
    jitoEnabled:        z.boolean().default(true),
    jitoTipLamports:    z.number().int().positive().default(100_000),
  }),
  risk: z.object({
    maxSlippagePct:                   z.number().positive(),
    minLiquidityUSD:                  z.number().positive(),
    maxPoolAgeMs:                     z.number().int().positive(),
    maxDailyLossUSD:                  z.number().positive(),
    circuitBreakerConsecutiveLosses:  z.number().int().positive(),
    maxTransactionSizeUSD:            z.number().positive(),
  }),
  simulation: z.object({
    enabled:              z.boolean(),
    rejectOnSimFailure:   z.boolean(),
  }),
  profit: z.object({
    minNetProfitUSD:  z.number().positive(),
    currency:         z.string(),
  }),
  database: z.object({
    path:                          z.string(),
    poolSnapshotRetentionHours:    z.number().int().positive(),
  }),
  monitoring: z.object({
    healthCheckPort:    z.number().int(),
    alertWebhook:       z.string(),
    metricsIntervalMs:  z.number().int().positive(),
  }),
  logging: z.object({
    level:  z.enum(['trace','debug','info','warn','error','fatal']),
    pretty: z.boolean(),
  }),
});

export type BotConfig = z.infer<typeof ConfigSchema>;

function loadYaml(filePath: string): Record<string, unknown> {
  if (!fs.existsSync(filePath)) return {};
  return (yaml.load(fs.readFileSync(filePath, 'utf8')) as Record<string, unknown>) ?? {};
}

function deepMerge(
  base: Record<string, unknown>,
  over: Record<string, unknown>,
): Record<string, unknown> {
  const r = { ...base };
  for (const k of Object.keys(over)) {
    const bv = base[k]; const ov = over[k];
    if (ov !== null && typeof ov === 'object' && !Array.isArray(ov) &&
        bv !== null && typeof bv === 'object' && !Array.isArray(bv)) {
      r[k] = deepMerge(bv as Record<string,unknown>, ov as Record<string,unknown>);
    } else { r[k] = ov; }
  }
  return r;
}

function applyEnv(c: Record<string, unknown>): Record<string, unknown> {
  type Sub = Record<string, unknown>;
  const rpc  = (c['rpc']  ?? {}) as Sub;
  const wal  = (c['wallet'] ?? {}) as Sub;
  const db   = (c['database'] ?? {}) as Sub;
  const mon  = (c['monitoring'] ?? {}) as Sub;
  const prof = (c['profit'] ?? {}) as Sub;
  const risk = (c['risk'] ?? {}) as Sub;
  const log  = (c['logging'] ?? {}) as Sub;
  const fl   = (c['flashLoan'] ?? {}) as Sub;

  if (process.env['RPC_ENDPOINT'])     rpc['endpoint']   = process.env['RPC_ENDPOINT'];
  if (process.env['RPC_WS_ENDPOINT'])  rpc['wsEndpoint'] = process.env['RPC_WS_ENDPOINT'];
  if (process.env['WALLET_KEYPAIR_PATH']) wal['keypairPath'] = process.env['WALLET_KEYPAIR_PATH'];
  if (process.env['DB_PATH'])          db['path']        = process.env['DB_PATH'];
  if (process.env['ALERT_WEBHOOK_URL']) mon['alertWebhook'] = process.env['ALERT_WEBHOOK_URL'];
  if (process.env['MIN_NET_PROFIT_USD']) prof['minNetProfitUSD'] = parseFloat(process.env['MIN_NET_PROFIT_USD']!);
  if (process.env['MAX_DAILY_LOSS_USD']) risk['maxDailyLossUSD'] = parseFloat(process.env['MAX_DAILY_LOSS_USD']!);
  if (process.env['LOG_LEVEL'])        log['level']      = process.env['LOG_LEVEL'];
  if (process.env['JITO_ENABLED'])     fl['jitoEnabled'] = process.env['JITO_ENABLED'] === 'true';
  if (process.env['JITO_TIP_LAMPORTS']) fl['jitoTipLamports'] = parseInt(process.env['JITO_TIP_LAMPORTS']!);

  return { ...c, rpc, wallet: wal, database: db, monitoring: mon, profit: prof, risk, logging: log, flashLoan: fl };
}

let _config: BotConfig | null = null;

export function loadConfig(): BotConfig {
  if (_config) return _config;
  const dir = path.resolve(process.cwd(), 'config');
  const env = process.env['NODE_ENV'] ?? 'development';
  const merged = applyEnv(deepMerge(loadYaml(path.join(dir, 'default.yaml')), loadYaml(path.join(dir, `${env}.yaml`))));
  const result = ConfigSchema.safeParse(merged);
  if (!result.success) {
    throw new ConfigError(`Invalid config: ${result.error.issues.map(i=>`${i.path.join('.')}: ${i.message}`).join(', ')}`);
  }
  _config = result.data;
  return _config;
}

export function resetConfig(): void { _config = null; }
