// src/infra/BlockhashCache.ts — NEW
// FIX: Eliminates the getLatestBlockhash() RPC round-trip from transaction
//      build time. Background refresh every 300ms. Sub-millisecond hot path.

import { Connection } from '@solana/web3.js';
import { CachedBlockhash } from '../core/types';
import { BLOCKHASH_REFRESH_MS } from '../core/constants';
import { createLogger } from '../core/logger';

const logger = createLogger('BlockhashCache');
const BLOCKHASH_MAX_AGE_MS = 50_000;

export class BlockhashCache {
  private current: CachedBlockhash | null = null;
  private previous: CachedBlockhash | null = null;
  private refreshTimer: NodeJS.Timeout | null = null;
  private refreshing = false;
  private failureCount = 0;

  constructor(private readonly connection: Connection) {}

  async start(): Promise<void> {
    await this.refresh();
    if (!this.current) throw new Error('BlockhashCache: failed to fetch initial blockhash');

    this.refreshTimer = setInterval(() => {
      this.refresh().catch(err => {
        this.failureCount++;
        logger.warn({ err, failureCount: this.failureCount }, 'Blockhash refresh failed');
      });
    }, BLOCKHASH_REFRESH_MS);

    logger.info({ blockhash: this.current.blockhash.slice(0, 12) }, 'BlockhashCache started');
  }

  stop(): void {
    if (this.refreshTimer) { clearInterval(this.refreshTimer); this.refreshTimer = null; }
  }

  /** Sub-millisecond — no I/O. Throws if stale (>50s). */
  get(): CachedBlockhash {
    if (this.current && !this.isStale(this.current)) return this.current;
    if (this.previous && !this.isStale(this.previous)) {
      logger.warn('Using previous cached blockhash');
      return this.previous;
    }
    throw new Error('BlockhashCache: no valid cached blockhash');
  }

  getAgeMs(): number { return this.current ? Date.now() - this.current.fetchedAtMs : Infinity; }

  getStats() {
    return { ageMs: this.getAgeMs(), failureCount: this.failureCount,
             hash: this.current?.blockhash.slice(0, 12) };
  }

  private async refresh(): Promise<void> {
    if (this.refreshing) return;
    this.refreshing = true;
    try {
      const result = await this.connection.getLatestBlockhash('confirmed');
      this.previous = this.current;
      this.current = {
        blockhash: result.blockhash,
        lastValidBlockHeight: result.lastValidBlockHeight,
        fetchedAtMs: Date.now(),
        slotAge: 0,
      };
      this.failureCount = 0;
    } finally {
      this.refreshing = false;
    }
  }

  private isStale(e: CachedBlockhash): boolean { return Date.now() - e.fetchedAtMs > BLOCKHASH_MAX_AGE_MS; }
}
