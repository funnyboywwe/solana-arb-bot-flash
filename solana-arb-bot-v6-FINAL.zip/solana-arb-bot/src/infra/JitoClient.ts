// src/infra/JitoClient.ts — NEW
// FIX: No MEV protection → every profitable opportunity front-run.
// Submits transactions as Jito bundles with validator tip.
// Falls back to standard RPC submission if Jito is unavailable.

import { VersionedTransaction, Connection, PublicKey,
         SystemProgram, TransactionMessage, Keypair } from '@solana/web3.js';
import { JITO_ENDPOINTS, JITO_TIP_ACCOUNTS } from '../core/constants';
import { createLogger } from '../core/logger';

const logger = createLogger('JitoClient');

export interface BundleResult {
  bundleId?: string;
  submitted: boolean;
  method: 'jito' | 'rpc_fallback';
  error?: string;
}

export class JitoClient {
  private currentEndpointIdx = 0;
  private tipLamports: number;
  private readonly tipAccounts: string[];

  constructor(
    private readonly wallet: Keypair,
    private readonly connection: Connection,
    tipLamports = 100_000, // 0.0001 SOL default tip
  ) {
    this.tipLamports = tipLamports;
    this.tipAccounts = [...JITO_TIP_ACCOUNTS];
  }

  /**
   * Submit a transaction as a Jito bundle.
   * The bundle contains: [tip tx, arb tx].
   * Falls back to standard RPC if Jito returns non-2xx.
   */
  async submitBundle(arbTx: VersionedTransaction): Promise<BundleResult> {
    try {
      const tipTx = await this.buildTipTransaction();
      const bundle = [tipTx, arbTx].map(tx =>
        Buffer.from(tx.serialize()).toString('base64')
      );

      const endpoint = this.getEndpoint();
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'sendBundle',
          params: [bundle],
        }),
        signal: AbortSignal.timeout(5_000),
      });

      if (!resp.ok) {
        throw new Error(`Jito HTTP ${resp.status}`);
      }

      const data = await resp.json() as { result?: string; error?: { message: string } };

      if (data.error) {
        throw new Error(data.error.message);
      }

      logger.info({ bundleId: data.result, tip: this.tipLamports }, 'Jito bundle submitted');
      return { bundleId: data.result, submitted: true, method: 'jito' };

    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      logger.warn({ err: errMsg }, 'Jito submission failed, falling back to RPC');

      // Fallback: submit directly to RPC
      try {
        const sig = await this.connection.sendRawTransaction(arbTx.serialize(), {
          skipPreflight: true,
          maxRetries: 3,
        });
        logger.info({ sig }, 'Submitted via RPC fallback');
        return { submitted: true, method: 'rpc_fallback' };
      } catch (fallbackErr) {
        return {
          submitted: false,
          method: 'rpc_fallback',
          error: fallbackErr instanceof Error ? fallbackErr.message : String(fallbackErr),
        };
      }
    }
  }

  /** Adjust tip based on opportunity profit — tip more for larger opportunities. */
  setAdaptiveTip(estimatedProfitLamports: bigint): void {
    // Tip = max(100k, min(5% of profit, 5M lamports))
    const pctOfProfit = Number(estimatedProfitLamports) * 0.05;
    this.tipLamports = Math.max(100_000, Math.min(Math.floor(pctOfProfit), 5_000_000));
  }

  getCurrentTip(): number { return this.tipLamports; }

  private async buildTipTransaction(): Promise<VersionedTransaction> {
    // Pick a random tip account to distribute load
    const tipAccountPubkey = new PublicKey(
      this.tipAccounts[Math.floor(Math.random() * this.tipAccounts.length)]!
    );

    const conn = this.connection;
    const { blockhash } = await conn.getLatestBlockhash('confirmed');

    const msg = new TransactionMessage({
      payerKey: this.wallet.publicKey,
      recentBlockhash: blockhash,
      instructions: [
        SystemProgram.transfer({
          fromPubkey: this.wallet.publicKey,
          toPubkey: tipAccountPubkey,
          lamports: this.tipLamports,
        }),
      ],
    }).compileToV0Message();

    const tx = new VersionedTransaction(msg);
    tx.sign([this.wallet]);
    return tx;
  }

  private getEndpoint(): string {
    const endpoints = Object.values(JITO_ENDPOINTS);
    const ep = endpoints[this.currentEndpointIdx % endpoints.length]!;
    this.currentEndpointIdx++;
    return ep;
  }
}
