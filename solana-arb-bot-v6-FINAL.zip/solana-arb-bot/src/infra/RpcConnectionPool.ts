// src/infra/RpcConnectionPool.ts — NEW
// FIX: Single RPC connection → full outage on degradation.
// Maintains primary + fallback connections. Auto-routes based on latency.

import { Connection, Commitment } from '@solana/web3.js';
import { createLogger } from '../core/logger';

const logger = createLogger('RpcConnectionPool');

interface RpcEndpoint {
  http: string;
  ws: string;
  name: string;
}

interface EndpointHealth {
  latencyMs: number;
  errors: number;
  lastCheckMs: number;
  healthy: boolean;
}

export class RpcConnectionPool {
  private connections: Map<string, Connection> = new Map();
  private health: Map<string, EndpointHealth> = new Map();
  private primaryName: string;
  private healthTimer: NodeJS.Timeout | null = null;

  constructor(
    private readonly endpoints: RpcEndpoint[],
    private readonly commitment: Commitment = 'confirmed',
  ) {
    if (!endpoints.length) throw new Error('At least one RPC endpoint required');

    for (const ep of endpoints) {
      this.connections.set(ep.name, new Connection(ep.http, {
        commitment,
        confirmTransactionInitialTimeout: 30_000,
        wsEndpoint: ep.ws,
      }));
      this.health.set(ep.name, {
        latencyMs: 999,
        errors: 0,
        lastCheckMs: 0,
        healthy: true,
      });
    }

    this.primaryName = endpoints[0]!.name;
  }

  async start(): Promise<void> {
    await this.checkAllEndpoints();
    this.healthTimer = setInterval(() => {
      this.checkAllEndpoints().catch(() => {});
    }, 10_000);
    logger.info({ primary: this.primaryName, endpoints: this.endpoints.length }, 'RPC pool started');
  }

  stop(): void {
    if (this.healthTimer) clearInterval(this.healthTimer);
  }

  /** Get the healthiest connection for the hot path. */
  get primary(): Connection {
    return this.connections.get(this.primaryName)!;
  }

  /** Get a specific named connection (for subscriptions that must stay on one endpoint). */
  getByName(name: string): Connection {
    return this.connections.get(name) ?? this.primary;
  }

  /** All healthy connections (for fan-out submission). */
  getAll(): Connection[] {
    return [...this.connections.entries()]
      .filter(([name]) => this.health.get(name)?.healthy ?? false)
      .map(([, conn]) => conn);
  }

  recordError(connectionName: string): void {
    const h = this.health.get(connectionName);
    if (!h) return;
    h.errors++;
    if (h.errors >= 3) {
      h.healthy = false;
      logger.warn({ name: connectionName }, 'Endpoint marked unhealthy');
      this.rotatePrimary();
    }
  }

  recordSuccess(connectionName: string): void {
    const h = this.health.get(connectionName);
    if (h) { h.errors = 0; h.healthy = true; }
  }

  getStatus() {
    return [...this.health.entries()].map(([name, h]) => ({ name, ...h }));
  }

  private async checkAllEndpoints(): Promise<void> {
    await Promise.allSettled(
      [...this.connections.entries()].map(async ([name, conn]) => {
        const start = Date.now();
        try {
          await conn.getSlot('processed');
          const latencyMs = Date.now() - start;
          const h = this.health.get(name)!;
          h.latencyMs = latencyMs;
          h.healthy = true;
          h.errors = 0;
          h.lastCheckMs = Date.now();
        } catch {
          const h = this.health.get(name)!;
          h.healthy = false;
          h.lastCheckMs = Date.now();
        }
      }),
    );
    this.rotatePrimary();
  }

  private rotatePrimary(): void {
    // Pick the healthy endpoint with lowest latency
    let best: string | null = null;
    let bestLatency = Infinity;

    for (const [name, h] of this.health.entries()) {
      if (h.healthy && h.latencyMs < bestLatency) {
        best = name;
        bestLatency = h.latencyMs;
      }
    }

    if (best && best !== this.primaryName) {
      logger.info({ from: this.primaryName, to: best, latencyMs: bestLatency }, 'Rotating primary RPC');
      this.primaryName = best;
    }
  }
}
