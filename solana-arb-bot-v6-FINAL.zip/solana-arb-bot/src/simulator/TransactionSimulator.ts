// src/simulator/TransactionSimulator.ts
import { Connection, Transaction, VersionedTransaction } from '@solana/web3.js';
import { SimulationResult } from '../core/types';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { SimulationFailedError } from '../core/errors';

const logger = createLogger('TransactionSimulator');

export class TransactionSimulator {
  constructor(
    private readonly connection: Connection,
    private readonly config: BotConfig
  ) {}

  async simulate(tx: VersionedTransaction | Transaction): Promise<SimulationResult> {
    if (!this.config.simulation.enabled) {
      logger.warn('Simulation disabled — skipping');
      return {
        success: true,
        logs: ['Simulation disabled'],
        repaymentVerified: true,
      };
    }

    try {
      let result;

      if (tx instanceof VersionedTransaction) {
        result = await this.connection.simulateTransaction(tx, {
          sigVerify: false,
          replaceRecentBlockhash: true,
        });
      } else {
        result = await this.connection.simulateTransaction(tx, undefined, true);
      }

      const logs = result.value.logs ?? [];
      const error = result.value.err;

      if (error) {
        const errorStr = JSON.stringify(error);
        logger.warn({ error: errorStr, logs }, 'Simulation returned error');

        return {
          success: false,
          logs,
          error: errorStr,
          repaymentVerified: false,
        };
      }

      // Verify repayment occurred by checking logs
      const repaymentVerified = this.verifyRepaymentInLogs(logs);

      if (!repaymentVerified) {
        logger.warn({ logs }, 'Repayment not verified in simulation logs');
      }

      logger.debug(
        { units: result.value.unitsConsumed, repaymentVerified },
        'Simulation successful'
      );

      return {
        success: true,
        logs,
        unitsConsumed: result.value.unitsConsumed ?? undefined,
        repaymentVerified,
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      logger.warn({ err: message }, 'Simulation threw exception');

      return {
        success: false,
        logs: [],
        error: message,
        repaymentVerified: false,
      };
    }
  }

  /** Throws if simulation fails and rejectOnSimFailure is true */
  async requireSuccess(tx: VersionedTransaction | Transaction): Promise<SimulationResult> {
    const result = await this.simulate(tx);

    if (!result.success && this.config.simulation.rejectOnSimFailure) {
      throw new SimulationFailedError(
        result.error ?? 'Unknown simulation error',
        result.logs
      );
    }

    if (!result.repaymentVerified && this.config.simulation.rejectOnSimFailure) {
      throw new SimulationFailedError('Repayment not verified in simulation', result.logs);
    }

    return result;
  }

  /**
   * Inspect transaction logs for flash loan repayment confirmation.
   * Flash loan providers emit specific log messages on repayment.
   */
  private verifyRepaymentInLogs(logs: string[]): boolean {
    const repaymentSignals = [
      'FlashRepay',
      'flash_repay',
      'repay_flash_loan',
      'Repaid flash loan',
    ];

    return logs.some(log =>
      repaymentSignals.some(signal => log.includes(signal))
    );
  }
}
