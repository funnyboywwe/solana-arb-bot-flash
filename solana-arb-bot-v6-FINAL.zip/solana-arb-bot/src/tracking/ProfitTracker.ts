// src/tracking/ProfitTracker.ts
import { TradeRecord, ArbitrageOpportunity, PnLSummary, DailyPnL } from '../core/types';
import { TradeRecorder } from './TradeRecorder';
import { PnLReporter } from './PnLReporter';
import { BotDatabase } from '../database/Database';
import { createLogger } from '../core/logger';

const logger = createLogger('ProfitTracker');

export class ProfitTracker {
  private readonly recorder: TradeRecorder;
  private readonly reporter: PnLReporter;

  // In-memory session stats
  private sessionTrades = 0;
  private sessionWins = 0;
  private sessionNetProfitUSD = 0;

  constructor(private readonly db: BotDatabase) {
    this.recorder = new TradeRecorder(db);
    this.reporter = new PnLReporter(db);
  }

  recordTrade(trade: TradeRecord): void {
    this.recorder.record(trade);

    this.sessionTrades++;
    if (trade.status === 'success' && trade.netProfitUSD > 0) {
      this.sessionWins++;
    }
    this.sessionNetProfitUSD += trade.netProfitUSD;

    // Log milestone every 10 trades
    if (this.sessionTrades % 10 === 0) {
      this.logSessionStats();
    }
  }

  recordOpportunity(opp: ArbitrageOpportunity): void {
    this.recorder.recordOpportunity(opp);
  }

  getTodayPnL(): DailyPnL | null {
    return this.reporter.getTodayPnL();
  }

  getSummary(days = 30): PnLSummary {
    return this.reporter.getSummary(days);
  }

  logDailySummary(): void {
    this.reporter.logDailySummary();
  }

  logAllTimeSummary(): void {
    this.reporter.logAllTimeSummary();
  }

  logSessionStats(): void {
    const winRate = this.sessionTrades > 0
      ? ((this.sessionWins / this.sessionTrades) * 100).toFixed(1)
      : '0.0';

    logger.info(
      {
        sessionTrades: this.sessionTrades,
        sessionWins: this.sessionWins,
        winRate: `${winRate}%`,
        sessionNetProfitUSD: this.sessionNetProfitUSD.toFixed(4),
      },
      '📊 Session stats'
    );
  }

  getSessionStats() {
    return {
      trades: this.sessionTrades,
      wins: this.sessionWins,
      netProfitUSD: this.sessionNetProfitUSD,
      winRate: this.sessionTrades > 0 ? this.sessionWins / this.sessionTrades : 0,
    };
  }

  getRecentTrades(limit = 20): TradeRecord[] {
    return this.recorder.getRecentTrades(limit);
  }
}
