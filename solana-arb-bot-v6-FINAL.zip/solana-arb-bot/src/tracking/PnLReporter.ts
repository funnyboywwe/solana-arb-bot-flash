// src/tracking/PnLReporter.ts
import { DailyPnL, PnLSummary } from '../core/types';
import { BotDatabase } from '../database/Database';
import { createLogger } from '../core/logger';

const logger = createLogger('PnLReporter');

export class PnLReporter {
  constructor(private readonly db: BotDatabase) {}

  getDailyPnL(days = 30): DailyPnL[] {
    return this.db.getDailyPnL(days);
  }

  getTodayPnL(): DailyPnL | null {
    return this.db.getTodayPnL();
  }

  getSummary(days = 30): PnLSummary {
    const daily = this.getDailyPnL(days);
    const allTime = this.db.getAllTimePnL();

    const sortedByProfit = [...daily].sort((a, b) => b.netProfitUSD - a.netProfitUSD);

    return {
      daily,
      allTime: {
        totalTrades: allTime.totalTrades,
        winRate: allTime.winRate,
        totalNetProfitUSD: allTime.totalNetProfitUSD,
        totalFeesUSD: 0, // could add to DB query
        bestDayUSD: sortedByProfit[0]?.netProfitUSD ?? 0,
        worstDayUSD: sortedByProfit[sortedByProfit.length - 1]?.netProfitUSD ?? 0,
      },
    };
  }

  logDailySummary(): void {
    const today = this.getTodayPnL();
    if (!today) {
      logger.info('No trades today');
      return;
    }

    logger.info(
      {
        date: today.date,
        tradesTotal: today.tradesTotal,
        tradesWon: today.tradesWon,
        winRate: `${(today.winRate * 100).toFixed(1)}%`,
        grossProfitUSD: today.grossProfitUSD.toFixed(2),
        netProfitUSD: today.netProfitUSD.toFixed(2),
        feesUSD: today.feesUSD.toFixed(2),
      },
      '📊 Daily PnL Summary'
    );
  }

  logAllTimeSummary(): void {
    const summary = this.getSummary();
    const at = summary.allTime;

    logger.info(
      {
        totalTrades: at.totalTrades,
        winRate: `${(at.winRate * 100).toFixed(1)}%`,
        totalNetProfitUSD: at.totalNetProfitUSD.toFixed(2),
        bestDayUSD: at.bestDayUSD.toFixed(2),
        worstDayUSD: at.worstDayUSD.toFixed(2),
      },
      '📈 All-Time PnL Summary'
    );
  }
}
