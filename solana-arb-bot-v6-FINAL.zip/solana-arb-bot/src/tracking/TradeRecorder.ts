// src/tracking/TradeRecorder.ts
import { TradeRecord, ArbitrageOpportunity } from '../core/types';
import { BotDatabase } from '../database/Database';
import { createLogger } from '../core/logger';

const logger = createLogger('TradeRecorder');

export class TradeRecorder {
  constructor(private readonly db: BotDatabase) {}

  record(trade: TradeRecord): void {
    try {
      this.db.insertTrade(trade);
      logger.info(
        {
          id: trade.id,
          status: trade.status,
          netProfitUSD: trade.netProfitUSD.toFixed(4),
          durationMs: trade.durationMs,
        },
        'Trade recorded'
      );
    } catch (err) {
      logger.error({ err, tradeId: trade.id }, 'Failed to record trade');
    }
  }

  recordOpportunity(opp: ArbitrageOpportunity): void {
    try {
      this.db.insertOpportunity(opp);
    } catch (err) {
      logger.warn({ err, oppId: opp.id }, 'Failed to record opportunity');
    }
  }

  getRecentTrades(limit = 50): TradeRecord[] {
    return this.db.getRecentTrades(limit);
  }
}
