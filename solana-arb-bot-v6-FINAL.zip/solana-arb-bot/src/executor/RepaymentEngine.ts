// src/executor/RepaymentEngine.ts
// import { PublicKey } from '@solana/web3.js';
import { createLogger } from '../core/logger';
import { RepaymentError } from '../core/errors';

const logger = createLogger('RepaymentEngine');

export interface RepaymentPlan {
  principalLamports: bigint;
  feeLamports: bigint;
  totalRepayLamports: bigint;
  tokenMint: string;
}

export class RepaymentEngine {
  constructor(private readonly feeMultiplier: number) {}

  buildRepaymentPlan(
    principalLamports: bigint,
    tokenMint: string
  ): RepaymentPlan {
    // FIX: use integer math to avoid float precision loss for large amounts
    const FEE_BASE = 1_000_000n;
    const feeFraction = BigInt(Math.round((this.feeMultiplier - 1) * 1_000_000));
    const feeLamports = (principalLamports * feeFraction + FEE_BASE - 1n) / FEE_BASE;
    const totalRepayLamports = principalLamports + feeLamports;

    logger.debug(
      {
        principal: principalLamports.toString(),
        fee: feeLamports.toString(),
        total: totalRepayLamports.toString(),
        mint: tokenMint,
      },
      'Repayment plan built'
    );

    return { principalLamports, feeLamports, totalRepayLamports, tokenMint };
  }

  /**
   * Verify that the bot wallet holds enough tokens to repay.
   * Called before submitting the transaction.
   */
  async verifyFundsAvailable(
    walletBalance: bigint,
    plan: RepaymentPlan
  ): Promise<void> {
    if (walletBalance < plan.totalRepayLamports) {
      throw new RepaymentError(plan.totalRepayLamports, walletBalance);
    }
  }

  /**
   * Verify post-execution that repayment was successful.
   * Checks the on-chain balance delta matches expectations.
   */
  verifyRepaymentResult(
    balanceBefore: bigint,
    balanceAfter: bigint,
    plan: RepaymentPlan,
    grossProfitLamports: bigint
  ): { verified: boolean; actualProfitLamports: bigint } {
    const expectedAfter = balanceBefore + grossProfitLamports - plan.feeLamports;
    const actualProfitLamports =
      balanceAfter > balanceBefore ? balanceAfter - balanceBefore : 0n;

    const delta = balanceAfter > expectedAfter
      ? balanceAfter - expectedAfter
      : expectedAfter - balanceAfter;

    // Allow 1% tolerance for slippage
    const tolerance = plan.totalRepayLamports / 100n;
    const verified = delta <= tolerance;

    if (!verified) {
      logger.warn(
        {
          expected: expectedAfter.toString(),
          actual: balanceAfter.toString(),
          delta: delta.toString(),
        },
        'Repayment verification mismatch'
      );
    }

    return { verified, actualProfitLamports };
  }
}
