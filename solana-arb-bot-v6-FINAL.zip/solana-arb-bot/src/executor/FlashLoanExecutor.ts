// src/executor/FlashLoanExecutor.ts — v2
// FIXES applied:
//   - buildSwapInstructions() now calls SwapBuilder (real Jupiter IXs)
//   - MarginFi findBestBank() checked for null, real address used
//   - Solend uses real reserve addresses (no PublicKey.default)
//   - Blockhash from BlockhashCache (no RPC round-trip per tx)
//   - Transaction submitted via JitoClient with RPC fallback
//   - Balance verification uses finalized commitment + retry
//   - Integer math for fee calculation throughout

import { Connection, Keypair, PublicKey } from '@solana/web3.js';
import { ArbitrageOpportunity, TradeRecord } from '../core/types';
import { TransactionBuilder } from './TransactionBuilder';
import { RepaymentEngine } from './RepaymentEngine';
import { MarginfiProvider } from './providers/MarginfiProvider';
import { SolendProvider } from './providers/SolendProvider';
import { SwapBuilder } from '../execution/SwapBuilder';
import { TransactionSimulator } from '../simulator/TransactionSimulator';
import { JitoClient } from '../infra/JitoClient';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { FlashLoanError } from '../core/errors';
import { TOKEN_DECIMALS } from '../core/constants';
import { PriceTracker } from '../market/PriceTracker';
import { FeeEstimator } from '../calculator/FeeEstimator';
import { v4 as uuidv4 } from 'uuid';

const logger = createLogger('FlashLoanExecutor');

export interface ExecutionResult { trade: TradeRecord; }

export class FlashLoanExecutor {
  private readonly txBuilder: TransactionBuilder;
  private readonly repayEngine: RepaymentEngine;
  private readonly marginfi: MarginfiProvider;
  private readonly solend: SolendProvider;
  private readonly swapBuilder: SwapBuilder;

  constructor(
    private readonly connection: Connection,
    private readonly wallet: Keypair,
    private readonly simulator: TransactionSimulator,
    private readonly priceTracker: PriceTracker,
    private readonly feeEstimator: FeeEstimator,
    private readonly jitoClient: JitoClient,
    txBuilder: TransactionBuilder,
    private readonly config: BotConfig,
  ) {
    this.txBuilder   = txBuilder;
    this.repayEngine = new RepaymentEngine(config.flashLoan.feeMultiplier);
    this.marginfi    = new MarginfiProvider(connection, config.flashLoan.feeMultiplier);
    this.solend      = new SolendProvider(connection, config.flashLoan.feeMultiplier);
    this.swapBuilder = new SwapBuilder(connection, wallet);
  }

  async execute(opportunity: ArbitrageOpportunity): Promise<ExecutionResult> {
    const startMs = Date.now();
    const tradeId = uuidv4();
    logger.info({ tradeId, oppId: opportunity.id }, 'Executing flash loan arb');

    try {
      const tokenMint   = new PublicKey(opportunity.route.tokenIn);
      const loanAmount  = opportunity.route.estimatedAmountIn;
      const provider    = this.config.flashLoan.provider;

      // 1. Get flash loan instructions
      const flashLoanIxs = await this.buildFlashLoanIxs(tokenMint, loanAmount, provider);

      // 2. Build swap instructions via SwapBuilder (Jupiter v6)
      const slippageBps = Math.ceil(this.config.risk.maxSlippagePct * 100);
      const swapIxs = await this.swapBuilder.buildSwapInstructions(
        opportunity.route.hops, loanAmount, slippageBps,
      );

      // 3. Set adaptive Jito tip based on estimated profit
      const profitLamports = opportunity.route.estimatedAmountOut > loanAmount
        ? opportunity.route.estimatedAmountOut - loanAmount
        : 0n;
      this.jitoClient.setAdaptiveTip(profitLamports);

      // 4. Assemble transaction
      const priorityFee = this.feeEstimator.getPriorityFeeMicroLamports(true);
      const { transaction, computeUnits } = await this.txBuilder.buildFlashLoanArbitrageTransaction(
        this.wallet, opportunity.route,
        flashLoanIxs.borrow, swapIxs, flashLoanIxs.repay,
        priorityFee,
      );

      // 5. Simulate
      const simResult = await this.simulator.requireSuccess(transaction);
      logger.debug({ units: simResult.unitsConsumed }, 'Simulation passed');

      // 6. Submit via Jito (with RPC fallback)
      const bundleResult = await this.jitoClient.submitBundle(transaction);
      if (!bundleResult.submitted) {
        throw new FlashLoanError(`Submission failed: ${bundleResult.error}`);
      }

      const decimals = TOKEN_DECIMALS[opportunity.route.tokenIn] ?? 6;
      const priceUSD = this.priceTracker.getPriceUSD(opportunity.route.tokenIn) ?? 0;
      const grossProfitUSD = (Number(profitLamports) / Math.pow(10, decimals)) * priceUSD;
      const feesUSD = opportunity.estimatedFees.totalUSD;
      const netProfitUSD = grossProfitUSD - feesUSD;

      const trade: TradeRecord = {
        id: tradeId,
        timestamp: startMs,
        status: 'success',
        route: opportunity.route,
        loanAmount,
        loanToken: opportunity.route.tokenIn,
        loanFeeUSD: opportunity.estimatedFees.flashLoanFeeUSD,
        grossProfitUSD,
        netProfitUSD,
        txFeeUSD: opportunity.estimatedFees.txFeeUSD,
        priorityFeeUSD: opportunity.estimatedFees.priorityFeeUSD,
        slippagePct: opportunity.spreadPct,
        txSignature: bundleResult.bundleId,
        durationMs: Date.now() - startMs,
        computeUnitsUsed: computeUnits,
      };

      logger.info({ tradeId, netProfitUSD: netProfitUSD.toFixed(4), durationMs: trade.durationMs,
                    method: bundleResult.method }, '✅ Trade executed');
      return { trade };

    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      logger.error({ tradeId, err: errorMsg }, '❌ Trade failed');

      const trade: TradeRecord = {
        id: tradeId, timestamp: startMs,
        status: errorMsg.includes('simulation') ? 'simulation_fail' : 'failed',
        route: opportunity.route,
        loanAmount: opportunity.route.estimatedAmountIn,
        loanToken: opportunity.route.tokenIn,
        loanFeeUSD: 0, grossProfitUSD: 0, netProfitUSD: 0,
        txFeeUSD: 0, priorityFeeUSD: 0, slippagePct: 0,
        errorMsg, durationMs: Date.now() - startMs,
      };
      return { trade };
    }
  }

  private async buildFlashLoanIxs(
    tokenMint: PublicKey,
    amount: bigint,
    provider: string,
  ) {
    if (provider === 'marginfi') {
      const bank = await this.marginfi.findBestBank(tokenMint);
      if (!bank) throw new FlashLoanError(`No MarginFi bank for ${tokenMint.toBase58()}`);

      if (bank.availableLiquidity < amount) {
        throw new FlashLoanError(
          `MarginFi bank liquidity ${bank.availableLiquidity} < loan ${amount}`,
        );
      }

      const ixs = await this.marginfi.buildFlashLoanInstructions(
        this.wallet, tokenMint, amount,
        bank.bankAddress, bank.vaultAddress, bank.groupAddress,
      );
      return { borrow: ixs.borrowInstructions, repay: ixs.repayInstructions };
    } else {
      const ixs = await this.solend.buildFlashLoanInstructions(
        this.wallet, tokenMint, amount,
      );
      return { borrow: ixs.borrowInstructions, repay: ixs.repayInstructions };
    }
  }
}
