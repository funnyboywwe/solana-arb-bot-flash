// src/executor/providers/SolendProvider.ts — v2
// FIX: Was using PublicKey.default (zero address) for reserve accounts.
// FIX: Real Solend reserve addresses per token (mainnet).
// FIX: Correct instruction encoding per Solend program IDL.

import { Connection, Keypair, PublicKey, TransactionInstruction } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, getAssociatedTokenAddress } from '@solana/spl-token';
import { createLogger } from '../../core/logger';
import { FlashLoanError } from '../../core/errors';
import { FLASH_LOAN_PROGRAMS, SOLEND_INSTRUCTIONS } from '../../core/constants';
import type { FlashLoanInstructions } from './MarginfiProvider';

const logger = createLogger('SolendProvider');

// Solend mainnet reserve addresses (main pool)
// Source: https://docs.solend.fi/protocol/reserves
const SOLEND_RESERVES: Record<string, {
  reserve: string;
  liquiditySupply: string;
  liquidityFeeReceiver: string;
  lendingMarket: string;
}> = {
  // USDC
  'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v': {
    reserve:             'BgxfHJDzm44T7XG68MYKx7YisTjZu73tVovyZSjJMpmw',  // verified: docs.save.finance/architecture/addresses/mainnet/main-pools
    liquiditySupply:     '8SheGtsopRUDzdiD6v6BR9a6bqZ9QwywYQY99Fp5meNf',
    liquidityFeeReceiver:'5Gdxn4yquneifE6uk9tK8X4CquPK4qQA4mcRRZjBE8KJ',
    lendingMarket:       'D4mFCJ4GEuC5NDPfz5oAUsPaHNDY3A7eEikPJP7VMKRD',
  },
  // SOL (wrapped)
  'So11111111111111111111111111111111111111112': {
    reserve:             '8PbodeaosQP19SjYFx855UMqWxH2HynZLdBXmsrbac36',
    liquiditySupply:     '5VVLD7BQp8y3bTgyF5ezm1ResyMTR3PhYsT4iHFU8Sxz',
    liquidityFeeReceiver:'5Gdxn4yquneifE6uk9tK8X4CquPK4qQA4mcRRZjBE8KJ',
    lendingMarket:       'D4mFCJ4GEuC5NDPfz5oAUsPaHNDY3A7eEikPJP7VMKRD',
  },
};

export class SolendProvider {
  private readonly programId = new PublicKey(FLASH_LOAN_PROGRAMS.SOLEND);

  constructor(
    private readonly connection: Connection,
    private readonly feeMultiplier: number,
  ) {}

  async buildFlashLoanInstructions(
    wallet: Keypair,
    tokenMint: PublicKey,
    amountLamports: bigint,
  ): Promise<FlashLoanInstructions> {
    const mintStr = tokenMint.toBase58();
    const reserveInfo = SOLEND_RESERVES[mintStr];

    if (!reserveInfo) {
      throw new FlashLoanError(`No Solend reserve for token: ${mintStr}`);
    }

    const reservePubkey         = new PublicKey(reserveInfo.reserve);
    const liquiditySupplyPubkey = new PublicKey(reserveInfo.liquiditySupply);
    const lendingMarketPubkey   = new PublicKey(reserveInfo.lendingMarket);
    const walletATA             = await getAssociatedTokenAddress(tokenMint, wallet.publicKey);

    // FIX: Integer-math fee calculation
    const FEE_BASE = 1_000_000n;
    const feeFraction = BigInt(Math.round((this.feeMultiplier - 1) * 1_000_000));
    const feeAmount = (amountLamports * feeFraction + FEE_BASE - 1n) / FEE_BASE;
    const expectedRepayAmount = amountLamports + feeAmount;

    // flash_borrow_reserve_liquidity (instruction index 20)
    const borrowData = Buffer.alloc(9);
    borrowData.writeUInt8(SOLEND_INSTRUCTIONS.FLASH_BORROW_RESERVE_LIQUIDITY, 0);
    borrowData.writeBigUInt64LE(amountLamports, 1);

    const borrowIx = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: liquiditySupplyPubkey, isSigner: false, isWritable: true  },
        { pubkey: walletATA,             isSigner: false, isWritable: true  },
        { pubkey: reservePubkey,         isSigner: false, isWritable: true  },
        { pubkey: lendingMarketPubkey,   isSigner: false, isWritable: false },
        { pubkey: wallet.publicKey,      isSigner: true,  isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID,      isSigner: false, isWritable: false },
      ],
      data: borrowData,
    });

    // flash_repay_reserve_liquidity (instruction index 21)
    // Includes the instruction index of the borrow IX for validation
    const repayData = Buffer.alloc(17);
    repayData.writeUInt8(SOLEND_INSTRUCTIONS.FLASH_REPAY_RESERVE_LIQUIDITY, 0);
    repayData.writeBigUInt64LE(expectedRepayAmount, 1);
    repayData.writeBigUInt64LE(0n, 9); // borrow instruction index = 0 (first in tx)

    const repayIx = new TransactionInstruction({
      programId: this.programId,
      keys: [
        { pubkey: walletATA,             isSigner: false, isWritable: true  },
        { pubkey: liquiditySupplyPubkey, isSigner: false, isWritable: true  },
        { pubkey: reservePubkey,         isSigner: false, isWritable: true  },
        { pubkey: lendingMarketPubkey,   isSigner: false, isWritable: false },
        { pubkey: wallet.publicKey,      isSigner: true,  isWritable: false },
        { pubkey: TOKEN_PROGRAM_ID,      isSigner: false, isWritable: false },
      ],
      data: repayData,
    });

    logger.debug({
      mint: mintStr, amount: amountLamports.toString(), repay: expectedRepayAmount.toString(),
    }, 'Solend flash loan instructions built');

    return { borrowInstructions: [borrowIx], repayInstructions: [repayIx], expectedRepayAmount };
  }

  async getAvailableLiquidity(tokenMint: PublicKey): Promise<bigint> {
    const mintStr = tokenMint.toBase58();
    const reserveInfo = SOLEND_RESERVES[mintStr];
    if (!reserveInfo) return 0n;

    try {
      const bal = await this.connection.getTokenAccountBalance(
        new PublicKey(reserveInfo.liquiditySupply), 'confirmed',
      );
      return BigInt(bal.value.amount);
    } catch { return 0n; }
  }
}
