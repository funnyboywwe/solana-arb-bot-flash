// src/executor/TransactionBuilder.ts — v2
// FIX: No longer calls getLatestBlockhash() — uses BlockhashCache (pre-fetched).
// FIX: Compute units estimated dynamically (not hardcoded 400k).
// FIX: Address Lookup Table support added to keep tx under 1232 bytes.
// FIX: Transaction size validated before returning.

import {
  Connection, Keypair,
  TransactionMessage, VersionedTransaction,
  ComputeBudgetProgram, TransactionInstruction,
  AddressLookupTableAccount,
} from '@solana/web3.js';
import { ArbitrageRoute } from '../core/types';
import { COMPUTE_UNITS } from '../core/constants';
import { BlockhashCache } from '../infra/BlockhashCache';
import { createLogger } from '../core/logger';
import { TransactionBuildError } from '../core/errors';

const logger = createLogger('TransactionBuilder');

const MAX_TX_SIZE_BYTES = 1232;

export interface BuildResult {
  transaction: VersionedTransaction;
  computeUnits: number;
  sizeBytes: number;
}

export class TransactionBuilder {
  constructor(
    private readonly connection: Connection,
    private readonly blockhashCache: BlockhashCache,
  ) {}

  async buildFlashLoanArbitrageTransaction(
    wallet: Keypair,
    route: ArbitrageRoute,
    flashLoanInstructions: TransactionInstruction[],
    swapInstructions: TransactionInstruction[],
    repayInstructions: TransactionInstruction[],
    priorityFeeMicroLamports: number,
    altAccounts: AddressLookupTableAccount[] = [],
  ): Promise<BuildResult> {
    try {
      // FIX: blockhash from cache — no RPC round-trip
      const cached = this.blockhashCache.get();
      const hops = route.hops.length;

      // Estimate CU budget based on hop count
      const computeUnits = hops >= 3
        ? COMPUTE_UNITS.FLASH_LOAN_3HOP
        : COMPUTE_UNITS.FLASH_LOAN_2HOP;

      const instructions: TransactionInstruction[] = [
        ComputeBudgetProgram.setComputeUnitLimit({ units: computeUnits }),
        ComputeBudgetProgram.setComputeUnitPrice({ microLamports: priorityFeeMicroLamports }),
        ...flashLoanInstructions,
        ...swapInstructions,
        ...repayInstructions,
      ];

      const message = new TransactionMessage({
        payerKey: wallet.publicKey,
        recentBlockhash: cached.blockhash,
        instructions,
      }).compileToV0Message(altAccounts);

      const transaction = new VersionedTransaction(message);
      transaction.sign([wallet]);

      // FIX: validate transaction size before returning
      const serialized = transaction.serialize();
      if (serialized.length > MAX_TX_SIZE_BYTES) {
        throw new TransactionBuildError(
          `Transaction ${serialized.length} bytes exceeds limit ${MAX_TX_SIZE_BYTES}. ` +
          `Add more ALT accounts or reduce route complexity.`,
        );
      }

      logger.debug({
        ixCount: instructions.length,
        sizeBytes: serialized.length,
        computeUnits,
        blockhashAge: this.blockhashCache.getAgeMs(),
      }, 'Transaction built');

      return { transaction, computeUnits, sizeBytes: serialized.length };
    } catch (err) {
      if (err instanceof TransactionBuildError) throw err;
      throw new TransactionBuildError(`Failed to build transaction: ${String(err)}`);
    }
  }

  /**
   * Estimate actual compute units via simulation.
   * Called during warm-up / strategy calibration, not in hot path.
   */
  async estimateComputeUnits(
    wallet: Keypair,
    instructions: TransactionInstruction[],
  ): Promise<number> {
    try {
      const cached = this.blockhashCache.get();
      const message = new TransactionMessage({
        payerKey: wallet.publicKey,
        recentBlockhash: cached.blockhash,
        instructions,
      }).compileToV0Message();

      const tx = new VersionedTransaction(message);
      const sim = await this.connection.simulateTransaction(tx, {
        sigVerify: false,
        replaceRecentBlockhash: true,
      });
      // Add 10% buffer above measured usage
      const measured = sim.value.unitsConsumed ?? COMPUTE_UNITS.FLASH_LOAN_2HOP;
      return Math.ceil(measured * 1.1);
    } catch {
      return COMPUTE_UNITS.FLASH_LOAN_2HOP;
    }
  }
}
