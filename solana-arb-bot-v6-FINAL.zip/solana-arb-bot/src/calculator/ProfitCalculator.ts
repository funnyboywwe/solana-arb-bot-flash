// src/calculator/ProfitCalculator.ts — v2
// FIX: Slippage cost now correctly applied to trade size, not to gross profit.
// FIX: Fee estimation is synchronous/cached — no per-opportunity async I/O.
// FIX: Uses loanAmountUSD from route for accurate sizing context.

import { ArbitrageOpportunity, FeeBreakdown } from '../core/types';
import { FeeEstimator } from './FeeEstimator';
import { SlippageModel } from './SlippageModel';
import { PoolMonitor } from '../market/PoolMonitor';
import { PriceTracker } from '../market/PriceTracker';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { TOKEN_DECIMALS } from '../core/constants';
import { UnprofitableError } from '../core/errors';

const logger = createLogger('ProfitCalculator');

export interface ProfitAnalysis {
  grossProfitUSD: number;
  fees: FeeBreakdown;
  slippageCostUSD: number;  // separate field so callers can see breakdown
  netProfitUSD: number;
  slippagePct: number;
  isProfitable: boolean;
  rejectionReason?: string;
}

export class ProfitCalculator {
  private readonly slippageModel: SlippageModel;

  constructor(
    private readonly feeEstimator: FeeEstimator,
    private readonly poolMonitor: PoolMonitor,
    private readonly priceTracker: PriceTracker,
    private readonly config: BotConfig,
  ) {
    this.slippageModel = new SlippageModel(config.risk.maxSlippagePct);
  }

  /**
   * Fully synchronous analysis — no RPC calls in hot path.
   * All fee estimates are pre-computed by FeeEstimator background refresh.
   */
  analyze(opportunity: ArbitrageOpportunity): ProfitAnalysis {
    const { route } = opportunity;
    const loanMint  = route.tokenIn;
    const decimals  = TOKEN_DECIMALS[loanMint] ?? 6;
    const priceUSD  = this.priceTracker.getPriceUSD(loanMint);

    if (!priceUSD) {
      return fail('No price data for loan token');
    }

    // ── Gross profit ─────────────────────────────────────────────────────────
    const profitLamports = route.estimatedAmountOut > route.estimatedAmountIn
      ? route.estimatedAmountOut - route.estimatedAmountIn
      : 0n;

    const grossProfitUSD =
      (Number(profitLamports) / Math.pow(10, decimals)) * priceUSD;

    // ── Fees (synchronous — cached by FeeEstimator) ───────────────────────────
    const fees = this.feeEstimator.getCachedFeeBreakdown(
      loanMint,
      route.estimatedAmountIn,
      decimals,
    );

    // ── Slippage ──────────────────────────────────────────────────────────────
    const pools = route.hops
      .map(h => this.poolMonitor.getPool(h.poolAddress))
      .filter((p): p is NonNullable<typeof p> => p !== undefined);

    let slippagePct = 0;
    let slippageCostUSD = 0;

    if (pools.length === route.hops.length) {
      const tokenIns = route.hops.map(h => h.tokenIn);
      const est = this.slippageModel.estimateForRoute(
        route.estimatedAmountIn, pools, tokenIns,
      );
      slippagePct = est.priceImpactPct;

      // FIX: slippage cost = tradeAmountUSD * slippagePct/100
      // NOT: grossProfitUSD * slippagePct/100  (was ~1000x wrong on large trades)
      const tradeAmountUSD = route.loanAmountUSD;
      slippageCostUSD = tradeAmountUSD * (slippagePct / 100);
    }

    // ── Net profit ────────────────────────────────────────────────────────────
    const netProfitUSD = grossProfitUSD - fees.totalUSD - slippageCostUSD;
    const minNet = this.config.profit.minNetProfitUSD;
    const isProfitable = netProfitUSD >= minNet;

    logger.trace({
      oppId: opportunity.id,
      grossProfitUSD: grossProfitUSD.toFixed(4),
      feesUSD: fees.totalUSD.toFixed(4),
      slippageCostUSD: slippageCostUSD.toFixed(4),
      netProfitUSD: netProfitUSD.toFixed(4),
      isProfitable,
    }, 'Profit analysis');

    return {
      grossProfitUSD,
      fees,
      slippageCostUSD,
      netProfitUSD,
      slippagePct,
      isProfitable,
      rejectionReason: isProfitable
        ? undefined
        : `Net profit $${netProfitUSD.toFixed(4)} < min $${minNet}`,
    };
  }

  requireProfitable(opportunity: ArbitrageOpportunity): ProfitAnalysis {
    const analysis = this.analyze(opportunity);
    if (!analysis.isProfitable) {
      throw new UnprofitableError(analysis.netProfitUSD, this.config.profit.minNetProfitUSD);
    }
    return analysis;
  }
}

function fail(reason: string): ProfitAnalysis {
  return {
    grossProfitUSD: 0,
    fees: emptyFees(),
    slippageCostUSD: 0,
    netProfitUSD: 0,
    slippagePct: 0,
    isProfitable: false,
    rejectionReason: reason,
  };
}

function emptyFees(): FeeBreakdown {
  return {
    flashLoanFeeLamports: 0n,
    flashLoanFeeUSD: 0,
    txFeeSOL: 0,
    txFeeUSD: 0,
    priorityFeeUSD: 0,
    totalUSD: 0,
  };
}
