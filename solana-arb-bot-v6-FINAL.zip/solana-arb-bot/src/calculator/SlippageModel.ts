// src/calculator/SlippageModel.ts — v2
// FIX: Slippage cost was being applied as a % of gross profit.
//      Correct: slippage reduces OUTPUT amount, cost = tradeSize * impactPct.

import { PoolState } from '../core/types';
import { getPriceImpactPct } from '../scanner/SpreadCalculator';

export interface SlippageEstimate {
  priceImpactPct: number;
  worstCaseOutputLamports: bigint;
  slippageCostUSD: number;  // RENAMED from slippageAdjustedProfitUSD — now correctly set by caller
}

export class SlippageModel {
  constructor(private readonly maxSlippagePct: number) {}

  estimateForHop(amountIn: bigint, pool: PoolState, tokenIn: string): number {
    const reserveIn = pool.tokenA === tokenIn ? pool.reserveA : pool.reserveB;
    return getPriceImpactPct(amountIn, reserveIn);
  }

  estimateForRoute(
    amountIn: bigint,
    pools: PoolState[],
    tokenIns: string[],
  ): SlippageEstimate {
    let totalImpactPct = 0;
    let currentAmount = amountIn;

    for (let i = 0; i < pools.length; i++) {
      const pool     = pools[i]!;
      const tokenIn  = tokenIns[i]!;
      const reserveIn = pool.tokenA === tokenIn ? pool.reserveA : pool.reserveB;

      const hopImpact = getPriceImpactPct(currentAmount, reserveIn);
      totalImpactPct += hopImpact;

      // FIX: use integer math for propagating amount through hops
      const FEE_BASE = 1_000_000n;
      const feeNum = BigInt(Math.round(pool.fee * 1_000_000));
      const feeComp = FEE_BASE - feeNum;
      const reserveOut = pool.tokenA === tokenIn ? pool.reserveB : pool.reserveA;

      if (reserveIn > 0n && reserveOut > 0n) {
        const amountWithFee = currentAmount * feeComp;
        const num = amountWithFee * reserveOut;
        const den = reserveIn * FEE_BASE + amountWithFee;
        currentAmount = den > 0n ? num / den : 0n;
      } else {
        currentAmount = 0n;
      }
    }

    return {
      priceImpactPct: totalImpactPct,
      worstCaseOutputLamports: currentAmount,
      slippageCostUSD: 0, // caller computes: tradeAmountUSD * totalImpactPct / 100
    };
  }

  exceedsMaxSlippage(priceImpactPct: number): boolean {
    return priceImpactPct > this.maxSlippagePct;
  }
}
