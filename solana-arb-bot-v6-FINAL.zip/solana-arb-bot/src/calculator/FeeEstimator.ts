// src/calculator/FeeEstimator.ts — v2
// FIX: All fee estimates are pre-computed and cached via background refresh.
//      No RPC calls in the hot path. getCachedFeeBreakdown() is synchronous.
// FIX: Priority fee uses real-time oracle (getRecentPrioritizationFees).

import { Connection } from '@solana/web3.js';
import { FeeBreakdown, PriorityFeeData } from '../core/types';
import { PriceTracker } from '../market/PriceTracker';
import { TOKEN_MINTS, COMPUTE_UNITS, PRIORITY_FEE_REFRESH_MS } from '../core/constants';
import { createLogger } from '../core/logger';

const logger = createLogger('FeeEstimator');

export class FeeEstimator {
  private priorityFeeCache: PriorityFeeData = {
    p50: COMPUTE_UNITS.PRIORITY_FEE_MICROLAMPORTS,
    p75: COMPUTE_UNITS.PRIORITY_FEE_MICROLAMPORTS * 3,
    p95: COMPUTE_UNITS.PRIORITY_FEE_MICROLAMPORTS * 10,
    fetchedAtMs: 0,
  };
  private refreshTimer: NodeJS.Timeout | null = null;

  constructor(
    private readonly connection: Connection,
    private readonly priceTracker: PriceTracker,
    private readonly flashLoanFeeMultiplier: number,
  ) {}

  /** Start background priority fee refresh */
  startBackgroundRefresh(): void {
    this.refreshPriorityFees().catch(() => {});
    this.refreshTimer = setInterval(() => {
      this.refreshPriorityFees().catch(err =>
        logger.warn({ err }, 'Priority fee refresh failed'),
      );
    }, PRIORITY_FEE_REFRESH_MS);
  }

  stopBackgroundRefresh(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  private async refreshPriorityFees(): Promise<void> {
    try {
      const fees = await this.connection.getRecentPrioritizationFees();
      if (!fees.length) return;

      const sorted = fees
        .map(f => f.prioritizationFee)
        .sort((a, b) => a - b);

      const p50 = sorted[Math.floor(sorted.length * 0.5)] ?? COMPUTE_UNITS.PRIORITY_FEE_MICROLAMPORTS;
      const p75 = sorted[Math.floor(sorted.length * 0.75)] ?? p50 * 2;
      const p95 = sorted[Math.floor(sorted.length * 0.95)] ?? p50 * 5;

      this.priorityFeeCache = { p50, p75, p95, fetchedAtMs: Date.now() };
      logger.trace({ p50, p75, p95 }, 'Priority fees updated');
    } catch (err) {
      logger.warn({ err }, 'getRecentPrioritizationFees failed');
    }
  }

  /**
   * Returns current recommended priority fee in microlamports.
   * Uses p75 for normal trades, p95 for time-critical ones.
   */
  getPriorityFeeMicroLamports(aggressive = false): number {
    const fee = aggressive ? this.priorityFeeCache.p95 : this.priorityFeeCache.p75;
    return Math.min(fee, COMPUTE_UNITS.MAX_PRIORITY_FEE_MLAMPORTS);
  }

  /**
   * Synchronous cached fee breakdown — safe to call in hot path.
   */
  getCachedFeeBreakdown(
    loanTokenMint: string,
    loanAmountLamports: bigint,
    loanTokenDecimals: number,
  ): FeeBreakdown {
    // Flash loan fee (integer math, no float)
    const flashLoanFeeLamports = this.calcFlashLoanFee(loanAmountLamports);

    // TX base fee (5000 lamports per signature, always 1 signature)
    const baseFeeSOL = 5000 / 1e9;

    // Priority fee for estimated CU budget
    const priorityMicroLamports = this.getPriorityFeeMicroLamports();
    const estimatedCUs = COMPUTE_UNITS.FLASH_LOAN_2HOP;
    const priorityFeeSOL = (priorityMicroLamports * estimatedCUs) / 1e12;

    const txFeeSOL = baseFeeSOL + priorityFeeSOL;

    const loanTokenPriceUSD = this.priceTracker.getPriceUSD(loanTokenMint) ?? 0;
    const solPriceUSD = this.priceTracker.getPriceUSD(TOKEN_MINTS.SOL) ?? 0;

    const flashLoanFeeUSD =
      (Number(flashLoanFeeLamports) / Math.pow(10, loanTokenDecimals)) * loanTokenPriceUSD;
    const txFeeUSD = txFeeSOL * solPriceUSD;
    const priorityFeeUSD = priorityFeeSOL * solPriceUSD;

    return {
      flashLoanFeeLamports,
      flashLoanFeeUSD,
      txFeeSOL,
      txFeeUSD,
      priorityFeeUSD,
      totalUSD: flashLoanFeeUSD + txFeeUSD + priorityFeeUSD,
    };
  }

  /**
   * Flash loan fee using integer math.
   * FIX: was BigInt(Math.ceil(Number(lamports) * multiplier)) — float precision risk.
   * Now: integer multiply with rounding.
   */
  calcFlashLoanFee(principalLamports: bigint): bigint {
    // feeMultiplier = 1.0009 → fee fraction = 0.0009 = 9/10000
    const FEE_BASE = 1_000_000n; // 6 decimal precision
    const feeFraction = BigInt(Math.round((this.flashLoanFeeMultiplier - 1) * 1_000_000));
    // fee = principal * feeFraction / FEE_BASE, rounded up
    return (principalLamports * feeFraction + FEE_BASE - 1n) / FEE_BASE;
  }

  getPriorityFeeCache(): PriorityFeeData {
    return this.priorityFeeCache;
  }
}
