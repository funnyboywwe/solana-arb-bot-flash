// src/scanner/OpportunityScanner.ts — v2
// FIX: 3-hop routes no longer silently disabled (removed `if length !== 2 continue`).
// FIX: Opportunity deduplication via route fingerprint + cooldown.
// FIX: loanAmountUSD correctly set on route for risk validation.
// FIX: Uses simulateMultiHopArb (not just 2-hop) for 3-hop routes.

import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { ArbitrageOpportunity, PoolState, TokenMint } from '../core/types';
import { PoolMonitor } from '../market/PoolMonitor';
import { PriceTracker } from '../market/PriceTracker';
import { RouteDiscovery } from './RouteDiscovery';
import { simulateMultiHopArb, findOptimalLoanSize } from './SpreadCalculator';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { TOKEN_DECIMALS } from '../core/constants';

const logger = createLogger('OpportunityScanner');

// Cooldown per route fingerprint to avoid duplicate submissions
const ROUTE_COOLDOWN_MS = 2_000;

export class OpportunityScanner extends EventEmitter {
  private readonly routeDiscovery: RouteDiscovery;
  private scanTimer: NodeJS.Timeout | null = null;
  private isScanning = false;
  private scanCount = 0;
  private opportunitiesFound = 0;
  // route fingerprint → last emit timestamp
  private routeCooldowns = new Map<string, number>();

  constructor(
    private readonly poolMonitor: PoolMonitor,
    private readonly priceTracker: PriceTracker,
    private readonly config: BotConfig,
  ) {
    super();
    this.routeDiscovery = new RouteDiscovery(poolMonitor, config.scanner.maxHops);
  }

  start(): void {
    if (this.scanTimer) return;

    // Event-driven scan on pool updates
    this.poolMonitor.on('pool_updated', (pool: PoolState) => {
      this.scanForPair(pool.tokenA, pool.tokenB).catch(err =>
        logger.warn({ err }, 'Triggered scan failed'));
    });

    // Periodic full sweep (catches any missed updates)
    this.scanTimer = setInterval(() => {
      this.fullScan().catch(err => logger.warn({ err }, 'Full scan failed'));
    }, this.config.scanner.intervalMs);

    logger.info({ intervalMs: this.config.scanner.intervalMs }, 'Scanner started');
  }

  stop(): void {
    if (this.scanTimer) { clearInterval(this.scanTimer); this.scanTimer = null; }
    this.poolMonitor.removeAllListeners('pool_updated');
    logger.info({ scanCount: this.scanCount, found: this.opportunitiesFound }, 'Scanner stopped');
  }

  private async fullScan(): Promise<void> {
    if (this.isScanning) return;
    this.isScanning = true;
    this.scanCount++;
    try {
      for (const [tokenA, tokenB] of this.config.scanner.monitoredPairs) {
        await this.scanForPair(tokenA, tokenB);
      }
    } finally {
      this.isScanning = false;
    }
  }

  private async scanForPair(tokenA: TokenMint, _tokenB: TokenMint): Promise<void> {
    const candidates = this.routeDiscovery.findArbitrageRoutes(
      tokenA, 0n, this.config.risk.maxPoolAgeMs,
    );

    for (const candidate of candidates) {
      const pools     = candidate.pools;
      const tokenIns  = candidate.route.hops.map(h => h.tokenIn);
      const tokenOuts = candidate.route.hops.map(h => h.tokenOut);

      // Quick spot-price spread filter
      if (pools.length >= 2) {
        const [p0, p1] = [pools[0]!, pools[1]!];
        const spread = Math.abs((p0.price - p1.price) / (p1.price || 1)) * 100;
        if (spread < this.config.scanner.minSpreadPct) continue;
      }

      // Deduplication: skip if this route was recently emitted
      const fingerprint = candidate.route.hops.map(h => `${h.poolAddress}:${h.tokenIn}`).join('|');
      const lastEmit = this.routeCooldowns.get(fingerprint) ?? 0;
      if (Date.now() - lastEmit < ROUTE_COOLDOWN_MS) continue;

      // Find optimal loan size via ternary search
      const priceUSD = this.priceTracker.getPriceUSD(tokenA) ?? 1;
      const decimals = TOKEN_DECIMALS[tokenA] ?? 6;
      const maxLoanLamports = BigInt(
        Math.floor((this.config.flashLoan.maxLoanAmountUSD / priceUSD) * Math.pow(10, decimals)),
      );
      const minLoanLamports = BigInt(Math.floor(1000 * Math.pow(10, decimals))); // $1k minimum

      const optimalAmount = findOptimalLoanSize(
        pools, tokenIns, tokenOuts, minLoanLamports, maxLoanLamports,
      );
      if (optimalAmount === 0n) continue;

      // FIX: use simulateMultiHopArb for all hop counts (not just 2-hop)
      const { profit, profitPct } = simulateMultiHopArb(
        optimalAmount, pools, tokenIns, tokenOuts,
      );
      if (profit <= 0n) continue;

      const grossProfitUSD = this.priceTracker.lamportsToUSD(tokenA, profit, decimals);
      const loanAmountUSD  = (Number(optimalAmount) / Math.pow(10, decimals)) * priceUSD;

      this.routeCooldowns.set(fingerprint, Date.now());

      const opportunity: ArbitrageOpportunity = {
        id: uuidv4(),
        detectedAtMs: Date.now(),
        route: {
          ...candidate.route,
          estimatedAmountIn: optimalAmount,
          estimatedAmountOut: optimalAmount + profit,
          loanAmountUSD,  // FIX: set for risk size validation
        },
        spreadPct: profitPct,
        estimatedGrossProfit: grossProfitUSD,
        estimatedNetProfit: grossProfitUSD,  // fees subtracted by ProfitCalculator
        estimatedFees: { flashLoanFeeLamports: 0n, flashLoanFeeUSD: 0, txFeeSOL: 0, txFeeUSD: 0, priorityFeeUSD: 0, totalUSD: 0 },
        status: 'detected',
      };

      this.opportunitiesFound++;
      logger.debug({ id: opportunity.id, hops: pools.length, spreadPct: profitPct.toFixed(4), grossProfitUSD: grossProfitUSD.toFixed(4) }, 'Opportunity detected');
      this.emit('opportunity', opportunity);
    }

    // Prune stale cooldowns every scan
    const now = Date.now();
    for (const [key, ts] of this.routeCooldowns.entries()) {
      if (now - ts > ROUTE_COOLDOWN_MS * 5) this.routeCooldowns.delete(key);
    }
  }

  getStats() { return { scanCount: this.scanCount, opportunitiesFound: this.opportunitiesFound }; }
}
