// src/scanner/RouteDiscovery.ts
import { PoolState, ArbitrageRoute, SwapHop, TokenMint } from '../core/types';
import { PoolMonitor } from '../market/PoolMonitor';
import { createLogger } from '../core/logger';
import { v4 as uuidv4 } from 'uuid';

const logger = createLogger('RouteDiscovery');

export interface RouteCandidate {
  route: ArbitrageRoute;
  pools: PoolState[];
}

export class RouteDiscovery {
  constructor(
    private readonly poolMonitor: PoolMonitor,
    private readonly maxHops: number
  ) {}

  /**
   * Find all circular routes starting and ending at tokenIn
   * that pass through at most maxHops pools.
   */
  findArbitrageRoutes(
    tokenIn: TokenMint,
    amountIn: bigint,
    maxPoolAgeMs: number
  ): RouteCandidate[] {
    const freshPools = this.poolMonitor.getFreshPools(maxPoolAgeMs);
    if (freshPools.length < 2) return [];

    const routes: RouteCandidate[] = [];

    // 2-hop routes: tokenIn → X → tokenIn across two different pools
    this.find2HopRoutes(tokenIn, amountIn, freshPools, routes);

    // 3-hop routes: tokenIn → X → Y → tokenIn (if maxHops >= 3)
    if (this.maxHops >= 3) {
      this.find3HopRoutes(tokenIn, amountIn, freshPools, routes);
    }

    logger.debug({ count: routes.length, tokenIn }, 'Routes discovered');
    return routes;
  }

  private find2HopRoutes(
    tokenIn: TokenMint,
    amountIn: bigint,
    pools: PoolState[],
    results: RouteCandidate[]
  ): void {
    // Find pools that have tokenIn
    const poolsWithTokenIn = pools.filter(
      p => p.tokenA === tokenIn || p.tokenB === tokenIn
    );

    for (const poolA of poolsWithTokenIn) {
      // What token do we get from poolA?
      const tokenOut = poolA.tokenA === tokenIn ? poolA.tokenB : poolA.tokenA;

      // Find pools on other DEXes that can swap tokenOut back to tokenIn
      const poolsBack = pools.filter(
        p =>
          p.address !== poolA.address &&
          (p.tokenA === tokenOut || p.tokenB === tokenOut) &&
          (p.tokenA === tokenIn || p.tokenB === tokenIn)
      );

      for (const poolB of poolsBack) {
        const hopA: SwapHop = {
          dex: poolA.dex,
          poolAddress: poolA.address,
          tokenIn,
          tokenOut,
          fee: poolA.fee,
        };
        const hopB: SwapHop = {
          dex: poolB.dex,
          poolAddress: poolB.address,
          tokenIn: tokenOut,
          tokenOut: tokenIn,
          fee: poolB.fee,
        };

        results.push({
          route: {
            id: uuidv4(),
            hops: [hopA, hopB],
            tokenIn,
            tokenOut: tokenIn,
            estimatedAmountIn: amountIn,
            estimatedAmountOut: 0n, loanAmountUSD: 0,
          },
          pools: [poolA, poolB],
        });
      }
    }
  }

  private find3HopRoutes(
    tokenIn: TokenMint,
    amountIn: bigint,
    pools: PoolState[],
    results: RouteCandidate[]
  ): void {
    const poolsWithTokenIn = pools.filter(
      p => p.tokenA === tokenIn || p.tokenB === tokenIn
    );

    for (const poolA of poolsWithTokenIn) {
      const tokenMid1 = poolA.tokenA === tokenIn ? poolA.tokenB : poolA.tokenA;

      // Find intermediate pools
      const midPools = pools.filter(
        p =>
          p.address !== poolA.address &&
          (p.tokenA === tokenMid1 || p.tokenB === tokenMid1)
      );

      for (const poolB of midPools) {
        const tokenMid2 = poolB.tokenA === tokenMid1 ? poolB.tokenB : poolB.tokenA;
        if (tokenMid2 === tokenIn) continue; // Already a 2-hop

        // Find pools back to tokenIn
        const returnPools = pools.filter(
          p =>
            p.address !== poolA.address &&
            p.address !== poolB.address &&
            (p.tokenA === tokenMid2 || p.tokenB === tokenMid2) &&
            (p.tokenA === tokenIn || p.tokenB === tokenIn)
        );

        for (const poolC of returnPools) {
          results.push({
            route: {
              id: uuidv4(),
              hops: [
                { dex: poolA.dex, poolAddress: poolA.address, tokenIn, tokenOut: tokenMid1, fee: poolA.fee },
                { dex: poolB.dex, poolAddress: poolB.address, tokenIn: tokenMid1, tokenOut: tokenMid2, fee: poolB.fee },
                { dex: poolC.dex, poolAddress: poolC.address, tokenIn: tokenMid2, tokenOut: tokenIn, fee: poolC.fee },
              ],
              tokenIn,
              tokenOut: tokenIn,
              estimatedAmountIn: amountIn,
              estimatedAmountOut: 0n, loanAmountUSD: 0,
            },
            pools: [poolA, poolB, poolC],
          });
        }
      }
    }
  }
}
