// src/scanner/SpreadCalculator.ts — v2
// FIX: All AMM math uses pure BigInt arithmetic. No Number() conversion in
//      the hot path. This eliminates precision loss for amounts up to 2^128.

import { PoolState } from '../core/types';

// ─── Integer AMM Math ────────────────────────────────────────────────────────

/**
 * Constant-product AMM output formula: x * y = k
 * All arithmetic is BigInt — zero floating-point precision loss.
 *
 * FIX audit finding: was BigInt(Math.floor(Number(amountIn) * feeMultiplier))
 * Now: integer multiply then integer divide, no Number() conversion.
 */
export function getAmountOut(
  amountIn: bigint,
  reserveIn: bigint,
  reserveOut: bigint,
  feeNumerator: bigint,
  feeDenominator: bigint,
): bigint {
  if (reserveIn === 0n || reserveOut === 0n || amountIn === 0n) return 0n;

  // amountInWithFee = amountIn * (feeDenominator - feeNumerator) / feeDenominator
  // e.g. 0.3% fee: feeNumerator=3, feeDenominator=1000
  //   amountInWithFee = amountIn * 997 / 1000
  const feeComplement = feeDenominator - feeNumerator;
  const amountInWithFee = amountIn * feeComplement;
  const numerator = amountInWithFee * reserveOut;
  const denominator = reserveIn * feeDenominator + amountInWithFee;

  if (denominator === 0n) return 0n;
  return numerator / denominator;
}

/**
 * Convenience wrapper: fee expressed as a decimal (0.003 = 0.3%)
 * Converts to integer numerator/denominator pair with 1,000,000 precision.
 */
export function getAmountOutFromFeeDecimal(
  amountIn: bigint,
  reserveIn: bigint,
  reserveOut: bigint,
  feePct: number,
): bigint {
  // Convert decimal fee to integer fraction with 1M base for sub-bip precision
  const FEE_BASE = 1_000_000n;
  const feeNum = BigInt(Math.round(feePct * 1_000_000));
  return getAmountOut(amountIn, reserveIn, reserveOut, feeNum, FEE_BASE);
}

/**
 * Price impact as a fraction in [0, 1].
 * FIX audit finding: previous formula had a sign error and computed
 * output-side impact rather than input-side. Correct formula:
 *   priceImpact = amountIn / (reserveIn + amountIn)
 * This is exact for constant-product AMMs.
 */
export function getPriceImpactPct(
  amountIn: bigint,
  reserveIn: bigint,
): number {
  if (reserveIn === 0n) return 100;
  if (amountIn === 0n) return 0;
  // scale by 1e12 for precision then convert at end
  const SCALE = 1_000_000_000_000n;
  const impactScaled = (amountIn * SCALE) / (reserveIn + amountIn);
  return Number(impactScaled) / 1e10; // returns percentage (0–100)
}

/**
 * Simulate a two-hop arbitrage.
 * Returns profit in tokenIn lamports and profit as percentage.
 *
 * FIX: 3-hop routing is now handled in simulateMultiHopArb below.
 */
export function simulateTwoHopArb(
  amountIn: bigint,
  poolA: PoolState,
  poolB: PoolState,
  tokenIn: string,
  tokenOut: string,
): { amountOut: bigint; profit: bigint; profitPct: number } {
  // Determine reserve direction for each pool
  const poolAReserveIn  = poolA.tokenA === tokenIn  ? poolA.reserveA : poolA.reserveB;
  const poolAReserveOut = poolA.tokenA === tokenOut ? poolA.reserveA : poolA.reserveB;
  const poolBReserveIn  = poolB.tokenA === tokenOut ? poolB.reserveA : poolB.reserveB;
  const poolBReserveOut = poolB.tokenA === tokenIn  ? poolB.reserveA : poolB.reserveB;

  const intermediate = getAmountOutFromFeeDecimal(amountIn, poolAReserveIn, poolAReserveOut, poolA.fee);
  if (intermediate === 0n) return { amountOut: 0n, profit: 0n, profitPct: 0 };

  const finalOut = getAmountOutFromFeeDecimal(intermediate, poolBReserveIn, poolBReserveOut, poolB.fee);

  const profit = finalOut > amountIn ? finalOut - amountIn : 0n;
  // profitPct: scale amountIn to avoid division precision loss
  const profitPct = amountIn > 0n
    ? Number((profit * 1_000_000n) / amountIn) / 10_000  // returns percent
    : 0;

  return { amountOut: finalOut, profit, profitPct };
}

/**
 * Simulate a variable-hop arbitrage route (2 or 3 hops).
 * FIX audit finding: 3-hop routes were silently disabled.
 */
export function simulateMultiHopArb(
  amountIn: bigint,
  pools: PoolState[],
  tokenIns: string[],
  tokenOuts: string[],
): { amountOut: bigint; profit: bigint; profitPct: number } {
  let current = amountIn;

  for (let i = 0; i < pools.length; i++) {
    const pool = pools[i]!;
    const tIn  = tokenIns[i]!;
    const tOut = tokenOuts[i]!;

    const reserveIn  = pool.tokenA === tIn  ? pool.reserveA : pool.reserveB;
    const reserveOut = pool.tokenA === tOut ? pool.reserveA : pool.reserveB;

    current = getAmountOutFromFeeDecimal(current, reserveIn, reserveOut, pool.fee);
    if (current === 0n) return { amountOut: 0n, profit: 0n, profitPct: 0 };
  }

  const profit = current > amountIn ? current - amountIn : 0n;
  const profitPct = amountIn > 0n
    ? Number((profit * 1_000_000n) / amountIn) / 10_000
    : 0;

  return { amountOut: current, profit, profitPct };
}

/**
 * Ternary search for optimal loan size.
 * FIX audit finding: was a 20-step LINEAR SCAN mislabelled as binary search.
 * Ternary search converges in O(log n) iterations, finding true maximum
 * of the unimodal profit function.
 */
export function findOptimalLoanSize(
  pools: PoolState[],
  tokenIns: string[],
  tokenOuts: string[],
  minAmount: bigint,
  maxAmount: bigint,
  iterations = 50,
): bigint {
  if (maxAmount <= minAmount) return 0n;

  let lo = minAmount;
  let hi = maxAmount;

  for (let i = 0; i < iterations; i++) {
    if (hi - lo < 1000n) break; // converged to within 1000 lamports

    const m1 = lo + (hi - lo) / 3n;
    const m2 = hi - (hi - lo) / 3n;

    const { profit: p1 } = simulateMultiHopArb(m1, pools, tokenIns, tokenOuts);
    const { profit: p2 } = simulateMultiHopArb(m2, pools, tokenIns, tokenOuts);

    if (p1 < p2) {
      lo = m1;
    } else {
      hi = m2;
    }
  }

  const optimal = (lo + hi) / 2n;
  const { profit } = simulateMultiHopArb(optimal, pools, tokenIns, tokenOuts);
  return profit > 0n ? optimal : 0n;
}

/**
 * Spread between two pools for same pair (spot price comparison).
 * Used for quick pre-filter only — not for profit calculation.
 */
export function calculateSpread(poolA: PoolState, poolB: PoolState): number {
  if (poolA.price === 0 || poolB.price === 0) return 0;
  return ((poolA.price - poolB.price) / poolB.price) * 100;
}
