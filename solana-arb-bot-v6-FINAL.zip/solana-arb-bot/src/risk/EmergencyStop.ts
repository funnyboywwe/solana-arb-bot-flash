// src/risk/EmergencyStop.ts — v2
// FIX: Previous version called fs.existsSync() synchronously in the hot path.
//      Now: polling interval updates an in-memory flag. check() is a pure
//      in-memory boolean test — zero filesystem I/O in the hot path.
// FIX: fs.watch() is unreliable on Linux (inotify misses). Use setInterval polling.

import * as fs from 'fs';
import * as path from 'path';
import { createLogger } from '../core/logger';
import { EmergencyStopError } from '../core/errors';

const logger = createLogger('EmergencyStop');
const STOP_FILE = path.resolve(process.cwd(), 'EMERGENCY_STOP');
const POLL_MS   = 500; // poll every 500ms — fast enough without blocking hot path

export class EmergencyStop {
  // In-memory flag — the only thing check() tests
  private stopped = false;
  private reason  = '';
  private pollTimer: NodeJS.Timeout | null = null;

  constructor() {
    // Start polling
    this.pollTimer = setInterval(() => this.poll(), POLL_MS);

    // Also handle OS signals
    process.on('SIGTERM', () => this.trigger('SIGTERM received'));
    process.on('SIGINT',  () => this.trigger('SIGINT received'));

    // Check immediately in case file exists at startup
    this.poll();
  }

  /**
   * Hot-path check — pure in-memory boolean. Zero I/O. <1µs.
   */
  check(): void {
    if (this.stopped) throw new EmergencyStopError(this.reason);
  }

  trigger(reason: string): void {
    if (this.stopped) return;
    this.stopped = true;
    this.reason  = reason;
    logger.fatal({ reason }, '🛑 EMERGENCY STOP TRIGGERED');
  }

  isStopped(): boolean { return this.stopped; }

  cleanup(): void {
    if (this.pollTimer) { clearInterval(this.pollTimer); this.pollTimer = null; }
    // Remove stop file if we placed it
    if (fs.existsSync(STOP_FILE)) {
      try { fs.unlinkSync(STOP_FILE); } catch { /* ignore */ }
    }
  }

  // ── Private ────────────────────────────────────────────────────────────────

  private poll(): void {
    if (this.stopped) return; // already stopped, no need to poll
    try {
      if (fs.existsSync(STOP_FILE)) {
        const content = fs.readFileSync(STOP_FILE, 'utf8').trim();
        this.trigger(content || 'Emergency stop file detected');
      }
    } catch { /* ignore FS errors */ }
  }
}
