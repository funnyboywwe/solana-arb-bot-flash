// src/risk/LiquidityGuard.ts
import { ArbitrageOpportunity, PoolState, RiskResult } from '../core/types';
import { PoolMonitor } from '../market/PoolMonitor';
import { PriceTracker } from '../market/PriceTracker';
import { TOKEN_DECIMALS } from '../core/constants';
import { createLogger } from '../core/logger';

// logger unused in this module

export class LiquidityGuard {
  constructor(
    private readonly poolMonitor: PoolMonitor,
    private readonly priceTracker: PriceTracker,
    private readonly minLiquidityUSD: number,
    private readonly maxPoolAgeMs: number
  ) {}

  validate(opportunity: ArbitrageOpportunity): RiskResult {
    for (const hop of opportunity.route.hops) {
      const pool = this.poolMonitor.getPool(hop.poolAddress);

      if (!pool) {
        return { passed: false, reason: `Pool ${hop.poolAddress.slice(0, 8)}... not found` };
      }

      // Freshness check
      const ageMs = Date.now() - pool.lastUpdatedMs;
      if (ageMs > this.maxPoolAgeMs) {
        return { passed: false, reason: `Pool ${pool.address.slice(0, 8)}... is stale (${ageMs}ms)` };
      }

      // Liquidity check
      const liquidityUSD = this.estimateLiquidityUSD(pool);
      if (liquidityUSD < this.minLiquidityUSD) {
        return {
          passed: false,
          reason: `Pool ${pool.address.slice(0, 8)}... liquidity $${liquidityUSD.toFixed(0)} < min $${this.minLiquidityUSD}`,
        };
      }

      // Trade size vs pool depth check (max 10% of pool)
      const loanAmountUSD = this.estimateLoanUSD(opportunity);
      if (loanAmountUSD > liquidityUSD * 0.1) {
        return {
          passed: false,
          reason: `Trade size $${loanAmountUSD.toFixed(0)} > 10% of pool $${liquidityUSD.toFixed(0)}`,
        };
      }
    }

    return { passed: true };
  }

  private estimateLiquidityUSD(pool: PoolState): number {
    const priceA = this.priceTracker.getPriceUSD(pool.tokenA);
    const priceB = this.priceTracker.getPriceUSD(pool.tokenB);

    const decimalsA = TOKEN_DECIMALS[pool.tokenA] ?? 6;
    const decimalsB = TOKEN_DECIMALS[pool.tokenB] ?? 6;

    const valueA = priceA
      ? (Number(pool.reserveA) / Math.pow(10, decimalsA)) * priceA
      : 0;
    const valueB = priceB
      ? (Number(pool.reserveB) / Math.pow(10, decimalsB)) * priceB
      : 0;

    return valueA + valueB;
  }

  private estimateLoanUSD(opportunity: ArbitrageOpportunity): number {
    const mint = opportunity.route.tokenIn;
    const decimals = TOKEN_DECIMALS[mint] ?? 6;
    const priceUSD = this.priceTracker.getPriceUSD(mint) ?? 0;
    return (Number(opportunity.route.estimatedAmountIn) / Math.pow(10, decimals)) * priceUSD;
  }
}
