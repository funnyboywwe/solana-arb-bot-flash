// src/risk/RiskValidator.ts — v2
// FIX: checkTransactionSize now compares loanAmountUSD (not netProfit) to limit.
// FIX: Emergency stop check no longer calls fs.existsSync() in hot path.
// FIX: Circuit breaker state cached in-memory, DB queried only on state change.

import { ArbitrageOpportunity, RiskResult } from '../core/types';
import { LiquidityGuard } from './LiquidityGuard';
import { CircuitBreaker } from './CircuitBreaker';
import { EmergencyStop } from './EmergencyStop';
import { SlippageModel } from '../calculator/SlippageModel';
import { PoolMonitor } from '../market/PoolMonitor';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { RiskValidationError } from '../core/errors';

const logger = createLogger('RiskValidator');

export class RiskValidator {
  constructor(
    private readonly liquidityGuard: LiquidityGuard,
    private readonly circuitBreaker: CircuitBreaker,
    private readonly emergencyStop: EmergencyStop,
    private readonly slippageModel: SlippageModel,
    private readonly poolMonitor: PoolMonitor,
    private readonly config: BotConfig,
  ) {}

  async validate(opportunity: ArbitrageOpportunity): Promise<void> {
    // L1: Emergency stop — in-memory flag check, no filesystem I/O
    this.emergencyStop.check();

    // L2: Circuit breaker — in-memory state, no DB query per call
    this.circuitBreaker.checkSync();

    // L3: Transaction (loan) size limit
    // FIX: was comparing estimatedNetProfit to maxTransactionSizeUSD
    //      which bypassed position sizing entirely. Now uses loanAmountUSD.
    const loanUSD = opportunity.route.loanAmountUSD;
    if (loanUSD > this.config.risk.maxTransactionSizeUSD) {
      throw new RiskValidationError(
        `Loan $${loanUSD.toFixed(0)} exceeds max transaction size $${this.config.risk.maxTransactionSizeUSD}`,
      );
    }

    // L4: Liquidity guard
    const liquidityResult = this.liquidityGuard.validate(opportunity);
    if (!liquidityResult.passed) {
      throw new RiskValidationError(liquidityResult.reason);
    }

    // L5: Route health
    const routeResult = this.validateRouteHealth(opportunity);
    if (!routeResult.passed) {
      throw new RiskValidationError(routeResult.reason);
    }

    // L6: Slippage check
    const slippageResult = this.validateSlippage(opportunity);
    if (!slippageResult.passed) {
      throw new RiskValidationError(slippageResult.reason);
    }

    logger.trace({ oppId: opportunity.id }, 'Risk validation passed');
  }

  async check(opportunity: ArbitrageOpportunity): Promise<RiskResult> {
    try {
      await this.validate(opportunity);
      return { passed: true };
    } catch (err) {
      return { passed: false, reason: err instanceof Error ? err.message : String(err) };
    }
  }

  private validateRouteHealth(opportunity: ArbitrageOpportunity): RiskResult {
    const { hops } = opportunity.route;

    // Must return to starting token
    if (hops[0]?.tokenIn !== hops[hops.length - 1]?.tokenOut) {
      return { passed: false, reason: 'Route does not return to starting token' };
    }

    // No duplicate pools
    const addrs = hops.map(h => h.poolAddress);
    if (new Set(addrs).size !== addrs.length) {
      return { passed: false, reason: 'Route contains duplicate pools' };
    }

    // Hop chain continuity
    for (let i = 1; i < hops.length; i++) {
      if (hops[i]!.tokenIn !== hops[i - 1]!.tokenOut) {
        return { passed: false, reason: `Broken route at hop ${i}: tokenIn mismatch` };
      }
    }

    return { passed: true };
  }

  private validateSlippage(opportunity: ArbitrageOpportunity): RiskResult {
    const pools = opportunity.route.hops
      .map(h => this.poolMonitor.getPool(h.poolAddress))
      .filter((p): p is NonNullable<typeof p> => p !== undefined);

    if (pools.length !== opportunity.route.hops.length) {
      return { passed: false, reason: 'Some pools not found for slippage check' };
    }

    const tokenIns = opportunity.route.hops.map(h => h.tokenIn);
    const est = this.slippageModel.estimateForRoute(
      opportunity.route.estimatedAmountIn, pools, tokenIns,
    );

    if (this.slippageModel.exceedsMaxSlippage(est.priceImpactPct)) {
      return {
        passed: false,
        reason: `Price impact ${est.priceImpactPct.toFixed(3)}% > max ${this.config.risk.maxSlippagePct}%`,
      };
    }

    return { passed: true };
  }
}
