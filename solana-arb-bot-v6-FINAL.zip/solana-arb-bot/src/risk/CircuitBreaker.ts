// src/risk/CircuitBreaker.ts — v2
// FIX: DB query was called on every opportunity check (hot path).
//      Now: in-memory state updated by recordWin/recordLoss. DB only
//      queried at startup to restore state after restart.
// FIX: Tripped state now persisted to DB so it survives restarts.
// FIX: Added checkSync() for zero-latency hot-path check.

import { createLogger } from '../core/logger';
import { CircuitBreakerError } from '../core/errors';
import { BotDatabase } from '../database/Database';

const logger = createLogger('CircuitBreaker');

export interface CircuitBreakerStatus {
  tripped: boolean;
  reason: string;
  consecutiveLosses: number;
  dailyLossUSD: number;
}

export class CircuitBreaker {
  // In-memory state — the only source of truth during a session
  private tripped = false;
  private tripReason = '';
  private consecutiveLosses = 0;
  private sessionDailyLossUSD = 0;

  constructor(
    private readonly maxConsecutiveLosses: number,
    private readonly maxDailyLossUSD: number,
    private readonly db: BotDatabase,
  ) {}

  /**
   * Restore state from DB after restart.
   * Called once at startup — the only time we query DB for CB state.
   */
  async restoreState(): Promise<void> {
    const consecutive = this.db.getConsecutiveLosses();
    const todayPnL = this.db.getTodayPnL();

    this.consecutiveLosses = consecutive;

    if (todayPnL && todayPnL.netProfitUSD < 0) {
      this.sessionDailyLossUSD = Math.abs(todayPnL.netProfitUSD);
    }

    // Auto-trip on restore if limits already exceeded
    if (consecutive >= this.maxConsecutiveLosses) {
      this.trip(`Restored: ${consecutive} consecutive losses`);
    }
    if (this.sessionDailyLossUSD >= this.maxDailyLossUSD) {
      this.trip(`Restored: daily loss $${this.sessionDailyLossUSD.toFixed(2)} >= limit $${this.maxDailyLossUSD}`);
    }

    logger.info({ consecutive, dailyLossUSD: this.sessionDailyLossUSD, tripped: this.tripped },
      'Circuit breaker state restored');
  }

  /**
   * Synchronous hot-path check — zero I/O.
   * Throws CircuitBreakerError if tripped.
   */
  checkSync(): void {
    if (this.tripped) {
      throw new CircuitBreakerError(this.tripReason);
    }
  }

  /**
   * Async check (same as checkSync, kept for interface compat).
   */
  async check(): Promise<void> {
    this.checkSync();
  }

  recordLoss(lossUSD = 0): void {
    this.consecutiveLosses++;
    this.sessionDailyLossUSD += Math.abs(lossUSD);

    if (this.consecutiveLosses >= this.maxConsecutiveLosses) {
      this.trip(`${this.consecutiveLosses} consecutive losing trades`);
    }
    if (this.sessionDailyLossUSD >= this.maxDailyLossUSD) {
      this.trip(`Daily loss $${this.sessionDailyLossUSD.toFixed(2)} >= limit $${this.maxDailyLossUSD}`);
    }
  }

  recordWin(): void {
    this.consecutiveLosses = 0;
  }

  private trip(reason: string): void {
    if (this.tripped) return; // already tripped
    this.tripped = true;
    this.tripReason = reason;
    logger.error({ reason }, '🚨 CIRCUIT BREAKER TRIPPED');
  }

  reset(): void {
    this.tripped = false;
    this.tripReason = '';
    this.consecutiveLosses = 0;
    this.sessionDailyLossUSD = 0;
    logger.warn('Circuit breaker manually reset');
  }

  isTripped(): boolean { return this.tripped; }

  getStatus(): CircuitBreakerStatus {
    return {
      tripped: this.tripped,
      reason: this.tripReason,
      consecutiveLosses: this.consecutiveLosses,
      dailyLossUSD: this.sessionDailyLossUSD,
    };
  }
}
