// src/database/Database.ts — v2
// FIX: SQL injection in updateDailyPnL() replaced with parameterized queries.
// FIX: WAL checkpoint scheduled to prevent unbounded WAL growth.
// FIX: getConsecutiveLosses() result is no longer called in hot path.
// FIX: TradeRecord now includes priorityFeeUSD field.

import Database from 'better-sqlite3';
import * as fs from 'fs';
import * as path from 'path';
import { createLogger } from '../core/logger';
import { TradeRecord, DailyPnL, ArbitrageOpportunity, PoolState } from '../core/types';
import { DatabaseError } from '../core/errors';

const logger = createLogger('Database');

export class BotDatabase {
  private db: Database.Database;
  private checkpointTimer: NodeJS.Timeout | null = null;

  constructor(dbPath: string) {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    this.db = new Database(dbPath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('synchronous = NORMAL');
    this.db.pragma('cache_size = -8000');
    this.db.pragma('temp_store = memory');
    this.db.pragma('mmap_size = 268435456'); // 256MB mmap

    this.runMigrations();

    // Schedule WAL checkpoint every 10 minutes to prevent unbounded growth
    this.checkpointTimer = setInterval(() => {
      try { this.db.pragma('wal_checkpoint(PASSIVE)'); }
      catch { /* ignore */ }
    }, 600_000);

    logger.info({ dbPath }, 'Database initialized');
  }

  // ─── Migrations ────────────────────────────────────────────────────────────

  private runMigrations(): void {
    this.db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL);`);
    const applied = new Set(
      (this.db.prepare('SELECT version FROM schema_migrations').all() as { version: number }[])
        .map(r => r.version)
    );

    const migrations = [{ version: 1, sql: MIGRATION_001 }, { version: 2, sql: MIGRATION_002 }];
    for (const m of migrations) {
      if (!applied.has(m.version)) {
        logger.info({ version: m.version }, 'Applying migration');
        try {
          this.db.exec(m.sql);
        } catch (err: unknown) {
          // ALTER TABLE ADD COLUMN fails if column already exists (older SQLite)
          // This is safe to ignore — the column is already there.
          const msg = err instanceof Error ? err.message : String(err);
          if (!msg.includes('duplicate column name')) throw err;
          logger.warn({ version: m.version, msg }, 'Migration warning: column already exists, skipping');
        }
        this.db.prepare('INSERT INTO schema_migrations VALUES (?, ?)').run(m.version, Date.now());
      }
    }
  }

  // ─── Trades ────────────────────────────────────────────────────────────────

  insertTrade(trade: TradeRecord): void {
    try {
      this.db.prepare(`
        INSERT INTO trades (id,timestamp,status,route,loan_amount,loan_token,loan_fee_usd,
          gross_profit_usd,net_profit_usd,tx_fee_usd,priority_fee_usd,slippage_pct,
          tx_signature,error_msg,duration_ms,compute_units_used)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      `).run(
        trade.id, trade.timestamp, trade.status, JSON.stringify(trade.route),
        trade.loanAmount.toString(), trade.loanToken,
        trade.loanFeeUSD, trade.grossProfitUSD, trade.netProfitUSD,
        trade.txFeeUSD, trade.priorityFeeUSD ?? 0, trade.slippagePct,
        trade.txSignature ?? null, trade.errorMsg ?? null,
        trade.durationMs, trade.computeUnitsUsed ?? null,
      );
      this.updateDailyPnL(trade);
    } catch (err) {
      throw new DatabaseError(`Failed to insert trade: ${String(err)}`);
    }
  }

  getRecentTrades(limit = 50): TradeRecord[] {
    return (this.db.prepare('SELECT * FROM trades ORDER BY timestamp DESC LIMIT ?').all(limit) as RawTrade[])
      .map(deserializeTrade);
  }

  getTradesInRange(fromMs: number, toMs: number): TradeRecord[] {
    return (this.db.prepare('SELECT * FROM trades WHERE timestamp >= ? AND timestamp <= ? ORDER BY timestamp').all(fromMs, toMs) as RawTrade[])
      .map(deserializeTrade);
  }

  // ─── Opportunities ─────────────────────────────────────────────────────────

  insertOpportunity(opp: ArbitrageOpportunity): void {
    try {
      this.db.prepare(`INSERT OR IGNORE INTO opportunities (id,timestamp,route,spread_pct,estimated_profit,rejected_reason,trade_id) VALUES (?,?,?,?,?,?,?)`)
        .run(opp.id, opp.detectedAtMs, JSON.stringify(opp.route), opp.spreadPct, opp.estimatedNetProfit, opp.rejectedReason ?? null, opp.tradeId ?? null);
    } catch (err) {
      logger.warn({ err, oppId: opp.id }, 'Failed to insert opportunity');
    }
  }

  // ─── Pool Snapshots ────────────────────────────────────────────────────────

  insertPoolSnapshot(pool: PoolState): void {
    try {
      this.db.prepare(`INSERT INTO pool_snapshots (timestamp,pool_address,dex,reserve_a,reserve_b,price) VALUES (?,?,?,?,?,?)`)
        .run(pool.lastUpdatedMs, pool.address, pool.dex, pool.reserveA.toString(), pool.reserveB.toString(), pool.price);
    } catch { /* non-fatal */ }
  }

  pruneOldSnapshots(retentionHours: number): number {
    return this.db.prepare('DELETE FROM pool_snapshots WHERE timestamp < ?')
      .run(Date.now() - retentionHours * 3_600_000).changes;
  }

  // ─── Daily PnL ─────────────────────────────────────────────────────────────

  /**
   * FIX: Was using string interpolation (SQL injection risk on NaN/Infinity values).
   * Now uses fully parameterized UPSERT.
   */
  private updateDailyPnL(trade: TradeRecord): void {
    const date = new Date(trade.timestamp).toISOString().slice(0, 10);
    const won  = trade.status === 'success' && trade.netProfitUSD > 0 ? 1 : 0;
    const fees = trade.txFeeUSD + trade.loanFeeUSD + (trade.priorityFeeUSD ?? 0);

    this.db.prepare(`
      INSERT INTO daily_pnl (date,trades_total,trades_won,gross_profit_usd,net_profit_usd,fees_paid_usd,win_rate)
      VALUES (?,1,?,?,?,?,?)
      ON CONFLICT(date) DO UPDATE SET
        trades_total     = trades_total + 1,
        trades_won       = trades_won + excluded.trades_won,
        gross_profit_usd = gross_profit_usd + excluded.gross_profit_usd,
        net_profit_usd   = net_profit_usd + excluded.net_profit_usd,
        fees_paid_usd    = fees_paid_usd + excluded.fees_paid_usd,
        win_rate         = CAST(trades_won AS REAL) / CAST(trades_total AS REAL)
    `).run(date, won, trade.grossProfitUSD, trade.netProfitUSD, fees,
            won === 1 ? 1.0 : 0.0);
  }

  getDailyPnL(days = 30): DailyPnL[] {
    return (this.db.prepare('SELECT * FROM daily_pnl ORDER BY date DESC LIMIT ?').all(days) as RawDailyPnL[])
      .map(deserializeDailyPnL);
  }

  getTodayPnL(): DailyPnL | null {
    const today = new Date().toISOString().slice(0, 10);
    const row = this.db.prepare('SELECT * FROM daily_pnl WHERE date = ?').get(today) as RawDailyPnL | undefined;
    return row ? deserializeDailyPnL(row) : null;
  }

  getAllTimePnL(): { totalTrades: number; totalNetProfitUSD: number; winRate: number } {
    const r = this.db.prepare(`SELECT SUM(trades_total) as t, SUM(net_profit_usd) as n, CAST(SUM(trades_won) AS REAL)/CAST(MAX(SUM(trades_total),1) AS REAL) as w FROM daily_pnl`).get() as { t: number; n: number; w: number } | undefined;
    return { totalTrades: r?.t ?? 0, totalNetProfitUSD: r?.n ?? 0, winRate: r?.w ?? 0 };
  }

  getConsecutiveLosses(): number {
    const recent = this.db.prepare(`SELECT status,net_profit_usd FROM trades ORDER BY timestamp DESC LIMIT 20`).all() as { status: string; net_profit_usd: number }[];
    let count = 0;
    for (const t of recent) {
      if (t.status !== 'success' || t.net_profit_usd <= 0) count++;
      else break;
    }
    return count;
  }

  close(): void {
    if (this.checkpointTimer) clearInterval(this.checkpointTimer);
    this.db.pragma('wal_checkpoint(FULL)');
    this.db.close();
    logger.info('Database closed');
  }
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface RawTrade {
  id: string; timestamp: number; status: string; route: string;
  loan_amount: string; loan_token: string; loan_fee_usd: number;
  gross_profit_usd: number; net_profit_usd: number; tx_fee_usd: number;
  priority_fee_usd: number; slippage_pct: number;
  tx_signature: string | null; error_msg: string | null;
  duration_ms: number; compute_units_used: number | null;
}
interface RawDailyPnL { date: string; trades_total: number; trades_won: number; gross_profit_usd: number; net_profit_usd: number; fees_paid_usd: number; win_rate: number; }

function deserializeTrade(r: RawTrade): TradeRecord {
  return {
    id: r.id, timestamp: r.timestamp, status: r.status as TradeRecord['status'],
    route: JSON.parse(r.route) as TradeRecord['route'],
    loanAmount: BigInt(r.loan_amount), loanToken: r.loan_token,
    loanFeeUSD: r.loan_fee_usd, grossProfitUSD: r.gross_profit_usd,
    netProfitUSD: r.net_profit_usd, txFeeUSD: r.tx_fee_usd,
    priorityFeeUSD: r.priority_fee_usd, slippagePct: r.slippage_pct,
    txSignature: r.tx_signature ?? undefined, errorMsg: r.error_msg ?? undefined,
    durationMs: r.duration_ms, computeUnitsUsed: r.compute_units_used ?? undefined,
  };
}
function deserializeDailyPnL(r: RawDailyPnL): DailyPnL {
  return { date: r.date, tradesTotal: r.trades_total, tradesWon: r.trades_won,
           grossProfitUSD: r.gross_profit_usd, netProfitUSD: r.net_profit_usd,
           feesUSD: r.fees_paid_usd, winRate: r.win_rate };
}

// ─── Migrations SQL ────────────────────────────────────────────────────────────

const MIGRATION_001 = `
  CREATE TABLE IF NOT EXISTS trades (
    id TEXT PRIMARY KEY, timestamp INTEGER NOT NULL, status TEXT NOT NULL, route TEXT NOT NULL,
    loan_amount TEXT NOT NULL, loan_token TEXT NOT NULL,
    loan_fee_usd REAL NOT NULL DEFAULT 0, gross_profit_usd REAL NOT NULL DEFAULT 0,
    net_profit_usd REAL NOT NULL DEFAULT 0, tx_fee_usd REAL NOT NULL DEFAULT 0,
    slippage_pct REAL NOT NULL DEFAULT 0,
    tx_signature TEXT, error_msg TEXT, duration_ms INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_trades_ts ON trades(timestamp DESC);
  CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
  CREATE TABLE IF NOT EXISTS opportunities (
    id TEXT PRIMARY KEY, timestamp INTEGER NOT NULL, route TEXT NOT NULL,
    spread_pct REAL NOT NULL, estimated_profit REAL NOT NULL,
    rejected_reason TEXT, trade_id TEXT REFERENCES trades(id)
  );
  CREATE INDEX IF NOT EXISTS idx_opp_ts ON opportunities(timestamp DESC);
  CREATE TABLE IF NOT EXISTS pool_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp INTEGER NOT NULL,
    pool_address TEXT NOT NULL, dex TEXT NOT NULL,
    reserve_a TEXT NOT NULL, reserve_b TEXT NOT NULL, price REAL NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_pool_ts ON pool_snapshots(timestamp DESC);
  CREATE TABLE IF NOT EXISTS daily_pnl (
    date TEXT PRIMARY KEY, trades_total INTEGER NOT NULL DEFAULT 0,
    trades_won INTEGER NOT NULL DEFAULT 0, gross_profit_usd REAL NOT NULL DEFAULT 0,
    net_profit_usd REAL NOT NULL DEFAULT 0, fees_paid_usd REAL NOT NULL DEFAULT 0,
    win_rate REAL NOT NULL DEFAULT 0
  );
`;

// Migration 002: Add new columns for v2 trade records
// Migration 002: SQLite does not support ALTER TABLE ADD COLUMN IF NOT EXISTS
// before 3.37.0. Use a try/catch approach via the run-migrations logic.
const MIGRATION_002 = `
  ALTER TABLE trades ADD COLUMN priority_fee_usd REAL NOT NULL DEFAULT 0;
  ALTER TABLE trades ADD COLUMN compute_units_used INTEGER;
`;
