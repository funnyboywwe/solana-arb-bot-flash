// src/core/types.ts — v2: Extended with all types needed for fixed modules

export type TokenMint = string;
export type PoolAddress = string;
export type TxSignature = string;

// ─── DEX / Pool ───────────────────────────────────────────────────────────────

export type DexName = 'raydium' | 'raydium_clmm' | 'orca' | 'jupiter';

export type PoolType = 'amm_v4' | 'clmm' | 'whirlpool';

export interface PoolState {
  address: PoolAddress;
  dex: DexName;
  poolType: PoolType;
  tokenA: TokenMint;
  tokenB: TokenMint;
  reserveA: bigint;          // actual vault balance in lamports
  reserveB: bigint;
  price: number;             // tokenA per tokenB (spot, from reserves)
  liquidity: number;         // USD value
  lastUpdatedMs: number;
  fee: number;               // 0.003 = 0.3%
  // CLMM-specific (Orca Whirlpool / Raydium CLMM)
  sqrtPrice?: bigint;        // Q64.64 sqrt price
  tickCurrentIndex?: number;
  liquidity128?: bigint;     // current tick liquidity (u128)
  // Raydium AMM v4 vault addresses (needed for reserve fetching)
  vaultA?: string;
  vaultB?: string;
}

export interface TokenPrice {
  mint: TokenMint;
  symbol: string;
  priceUSD: number;
  decimals: number;
  lastUpdatedMs: number;
}

// ─── Routes ───────────────────────────────────────────────────────────────────

export interface SwapHop {
  dex: DexName;
  poolAddress: PoolAddress;
  tokenIn: TokenMint;
  tokenOut: TokenMint;
  fee: number;
}

export interface ArbitrageRoute {
  id: string;
  hops: SwapHop[];
  tokenIn: TokenMint;
  tokenOut: TokenMint;
  estimatedAmountIn: bigint;
  estimatedAmountOut: bigint;
  loanAmountUSD: number;     // actual loan size in USD — used for size limit checks
}

// ─── Opportunities ────────────────────────────────────────────────────────────

export type OpportunityStatus =
  | 'detected'
  | 'rejected_profit'
  | 'rejected_risk'
  | 'rejected_simulation'
  | 'executed'
  | 'failed';

export interface ArbitrageOpportunity {
  id: string;
  detectedAtMs: number;
  route: ArbitrageRoute;
  spreadPct: number;
  estimatedGrossProfit: number;
  estimatedNetProfit: number;
  estimatedFees: FeeBreakdown;
  status: OpportunityStatus;
  rejectedReason?: string;
  tradeId?: string;
}

// ─── Fees ─────────────────────────────────────────────────────────────────────

export interface FeeBreakdown {
  flashLoanFeeLamports: bigint;
  flashLoanFeeUSD: number;
  txFeeSOL: number;
  txFeeUSD: number;
  priorityFeeUSD: number;
  totalUSD: number;
}

// ─── Risk ─────────────────────────────────────────────────────────────────────

export type RiskResult =
  | { passed: true }
  | { passed: false; reason: string };

// ─── Simulation ───────────────────────────────────────────────────────────────

export interface SimulationResult {
  success: boolean;
  logs: string[];
  unitsConsumed?: number;
  error?: string;
  repaymentVerified: boolean;
  expectedProfit?: number;
}

// ─── Flash Loan ───────────────────────────────────────────────────────────────

export type FlashLoanProvider = 'marginfi' | 'solend';

export interface FlashLoanParams {
  provider: FlashLoanProvider;
  tokenMint: TokenMint;
  amountLamports: bigint;
  route: ArbitrageRoute;
}

// ─── Trades ───────────────────────────────────────────────────────────────────

export type TradeStatus = 'success' | 'failed' | 'reverted' | 'simulation_fail';

export interface TradeRecord {
  id: string;
  timestamp: number;
  status: TradeStatus;
  route: ArbitrageRoute;
  loanAmount: bigint;
  loanToken: TokenMint;
  loanFeeUSD: number;
  grossProfitUSD: number;
  netProfitUSD: number;
  txFeeUSD: number;
  priorityFeeUSD: number;
  slippagePct: number;
  actualSlippagePct?: number;  // recorded post-execution
  txSignature?: TxSignature;
  errorMsg?: string;
  durationMs: number;
  computeUnitsUsed?: number;
}

// ─── PnL ──────────────────────────────────────────────────────────────────────

export interface DailyPnL {
  date: string;
  tradesTotal: number;
  tradesWon: number;
  grossProfitUSD: number;
  netProfitUSD: number;
  feesUSD: number;
  winRate: number;
}

export interface PnLSummary {
  daily: DailyPnL[];
  allTime: {
    totalTrades: number;
    winRate: number;
    totalNetProfitUSD: number;
    totalFeesUSD: number;
    bestDayUSD: number;
    worstDayUSD: number;
  };
}

// ─── Pool Registry ────────────────────────────────────────────────────────────

export interface PoolRegistryEntry {
  address: string;
  dex: DexName;
  poolType: PoolType;
  tokenA: string;
  tokenB: string;
  vaultA?: string;
  vaultB?: string;
  fee: number;
  tvlUSD?: number;
}

// ─── Blockhash Cache ──────────────────────────────────────────────────────────

export interface CachedBlockhash {
  blockhash: string;
  lastValidBlockHeight: number;
  fetchedAtMs: number;
  slotAge: number;
}

// ─── Priority Fee ─────────────────────────────────────────────────────────────

export interface PriorityFeeData {
  p50: number;
  p75: number;
  p95: number;
  fetchedAtMs: number;
}

// ─── Metrics ──────────────────────────────────────────────────────────────────

export interface LatencyMetrics {
  opportunityToDecisionMs: number[];
  decisionToSubmitMs: number[];
  submitToConfirmMs: number[];
}

// ─── Events ───────────────────────────────────────────────────────────────────

export type BotEvent =
  | { type: 'pool_updated'; pool: PoolState }
  | { type: 'opportunity_detected'; opportunity: ArbitrageOpportunity }
  | { type: 'trade_executed'; trade: TradeRecord }
  | { type: 'circuit_breaker_triggered'; reason: string }
  | { type: 'emergency_stop'; reason: string }
  | { type: 'error'; error: Error; context: string };
