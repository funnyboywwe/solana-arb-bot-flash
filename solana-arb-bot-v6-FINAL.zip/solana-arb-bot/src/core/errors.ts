// src/core/errors.ts

export class BotError extends Error {
  constructor(message: string, public readonly context?: Record<string, unknown>) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

// Market data errors
export class MarketDataError extends BotError {}
export class WebSocketError extends BotError {}
export class StaleDataError extends BotError {
  constructor(poolAddress: string, ageMs: number) {
    super(`Pool ${poolAddress} data is stale: ${ageMs}ms old`, { poolAddress, ageMs });
  }
}

// Opportunity / Scanning errors
export class NoOpportunityError extends BotError {}
export class InsufficientSpreadError extends BotError {
  constructor(spreadPct: number, minSpreadPct: number) {
    super(`Spread ${spreadPct.toFixed(4)}% < minimum ${minSpreadPct}%`, {
      spreadPct,
      minSpreadPct,
    });
  }
}

// Profit errors
export class UnprofitableError extends BotError {
  constructor(netProfit: number, minProfit: number) {
    super(`Net profit $${netProfit.toFixed(4)} < minimum $${minProfit}`, {
      netProfit,
      minProfit,
    });
  }
}

// Risk errors
export class RiskValidationError extends BotError {
  constructor(reason: string, context?: Record<string, unknown>) {
    super(`Risk validation failed: ${reason}`, context);
  }
}

export class InsufficientLiquidityError extends BotError {
  constructor(poolAddress: string, liquidityUSD: number, minUSD: number) {
    super(`Pool ${poolAddress} liquidity $${liquidityUSD} < min $${minUSD}`, {
      poolAddress,
      liquidityUSD,
      minUSD,
    });
  }
}

export class CircuitBreakerError extends BotError {
  constructor(reason: string) {
    super(`Circuit breaker triggered: ${reason}`, { reason });
  }
}

export class EmergencyStopError extends BotError {
  constructor(reason: string) {
    super(`Emergency stop: ${reason}`, { reason });
  }
}

// Simulation errors
export class SimulationFailedError extends BotError {
  constructor(message: string, public readonly logs: string[]) {
    super(`Simulation failed: ${message}`, { logs });
  }
}

// Execution errors
export class FlashLoanError extends BotError {}
export class TransactionBuildError extends BotError {}
export class RepaymentError extends BotError {
  constructor(expected: bigint, actual: bigint) {
    super(`Repayment failed: expected ${expected}, got ${actual}`, {
      expected: expected.toString(),
      actual: actual.toString(),
    });
  }
}

// Configuration errors
export class ConfigError extends BotError {}

// Database errors
export class DatabaseError extends BotError {}
