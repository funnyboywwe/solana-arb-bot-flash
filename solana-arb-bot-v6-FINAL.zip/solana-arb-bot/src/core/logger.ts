// src/core/logger.ts
import pino, { Logger } from 'pino';

let rootLogger: Logger;

export function createLogger(name: string): Logger {
  if (!rootLogger) {
    const level = process.env['LOG_LEVEL'] ?? 'info';
    const pretty = process.env['LOG_PRETTY'] === 'true';

    rootLogger = pino({
      level,
      name: 'arb-bot',
      timestamp: pino.stdTimeFunctions.isoTime,
      ...(pretty
        ? {
            transport: {
              target: 'pino-pretty',
              options: {
                colorize: true,
                translateTime: 'SYS:standard',
                ignore: 'pid,hostname',
              },
            },
          }
        : {}),
    });
  }

  return rootLogger.child({ module: name });
}

export type { Logger };
