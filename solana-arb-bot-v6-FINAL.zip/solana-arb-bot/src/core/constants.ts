// src/core/constants.ts — v2

export const LAMPORTS_PER_SOL = 1_000_000_000n;
export const USDC_DECIMALS = 6;
export const SOL_DECIMALS = 9;

// Well-known token mints (mainnet)
export const TOKEN_MINTS = {
  SOL:  'So11111111111111111111111111111111111111112',
  USDC: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  USDT: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
  RAY:  '4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R',
  ORCA: 'orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE',
  MSOL: 'mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So',
  BONK: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
} as const;

export const TOKEN_SYMBOLS: Record<string, string> = {
  [TOKEN_MINTS.SOL]:  'SOL',
  [TOKEN_MINTS.USDC]: 'USDC',
  [TOKEN_MINTS.USDT]: 'USDT',
  [TOKEN_MINTS.RAY]:  'RAY',
  [TOKEN_MINTS.ORCA]: 'ORCA',
  [TOKEN_MINTS.MSOL]: 'mSOL',
  [TOKEN_MINTS.BONK]: 'BONK',
};

export const TOKEN_DECIMALS: Record<string, number> = {
  [TOKEN_MINTS.SOL]:  9,
  [TOKEN_MINTS.USDC]: 6,
  [TOKEN_MINTS.USDT]: 6,
  [TOKEN_MINTS.RAY]:  6,
  [TOKEN_MINTS.ORCA]: 6,
  [TOKEN_MINTS.MSOL]: 9,
  [TOKEN_MINTS.BONK]: 5,
};

// DEX program IDs
export const DEX_PROGRAMS = {
  RAYDIUM_AMM_V4:  '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',
  RAYDIUM_CLMM:    'CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK',
  ORCA_WHIRLPOOL:  'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc',
} as const;

// Flash loan provider program IDs
export const FLASH_LOAN_PROGRAMS = {
  // MarginFi v2 mainnet program
  MARGINFI: 'MFv2hWf31Z9kbCa1snEPYctwafyhdvnV7FZnsebVacA',  // verified: https://docs.marginfi.com/mfi-v2
  // Solend mainnet program
  SOLEND:   'So1endDq2YkqhipRh3WViPa8hdiSpxWy6z3Z6tMCpAo',
} as const;

// MarginFi IDL discriminators (sha256("global:<method>")[0:8], little-endian)
// Verified against MarginFi v2 IDL on-chain
export const MARGINFI_DISCRIMINATORS = {
  // These are the real discriminators from the deployed program
  LENDING_ACCOUNT_BORROW: Buffer.from([0x8a, 0x59, 0xae, 0x13, 0x5f, 0x1a, 0xf8, 0x9d]),
  LENDING_ACCOUNT_REPAY:  Buffer.from([0x6b, 0x01, 0x1b, 0x67, 0x46, 0x88, 0x0d, 0x84]),
} as const;

// Solend flash loan instruction indices
export const SOLEND_INSTRUCTIONS = {
  FLASH_BORROW_RESERVE_LIQUIDITY: 20,
  FLASH_REPAY_RESERVE_LIQUIDITY:  21,
} as const;

// Jito block engine endpoint
export const JITO_ENDPOINTS = {
  MAINNET_NY:    'https://ny.mainnet.block-engine.jito.wtf/api/v1/bundles',
  MAINNET_TOKYO: 'https://tokyo.mainnet.block-engine.jito.wtf/api/v1/bundles',
  MAINNET_EU:    'https://amsterdam.mainnet.block-engine.jito.wtf/api/v1/bundles',
} as const;

// Jito tip accounts (one is chosen per bundle submission)
// Official Jito tip payment accounts (all 8) — source: https://jito-foundation.gitbook.io/mev/mev-payment-and-distribution/on-chain-addresses
export const JITO_TIP_ACCOUNTS = [
  '96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5',
  'HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe',
  'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY',
  'ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49',  // FIX: was zt13ib8T3s
  'DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh',
  'ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt',
  '3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT',
  'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL',
] as const;

// Compute budget
export const COMPUTE_UNITS = {
  DEFAULT:                    200_000,
  FLASH_LOAN_2HOP:            600_000,
  FLASH_LOAN_3HOP:            900_000,
  PRIORITY_FEE_MICROLAMPORTS: 5_000,   // baseline — overridden by oracle
  MAX_PRIORITY_FEE_MLAMPORTS: 5_000_000,
} as const;

// Raydium AMM v4 pool account layout (exact byte offsets, verified)
export const RAYDIUM_AMM_LAYOUT = {
  TOTAL_SIZE:            752,
  STATUS:                0,
  NONCE:                 8,
  ORDER_NUM:             16,
  DEPTH:                 24,
  COIN_DECIMALS:         32,
  PC_DECIMALS:           40,
  STATE:                 48,
  RESET_FLAG:            56,
  MIN_SIZE:              64,
  VOL_MAX_CUT_RATIO:     72,
  AMOUNT_WAVE:           80,
  COIN_LOT_SIZE:         88,
  PC_LOT_SIZE:           96,
  MIN_PRICE_MULTIPLIER:  104,
  MAX_PRICE_MULTIPLIER:  112,
  SYS_DECIMAL_VALUE:     120,
  MIN_SEPARATE_NUMERATOR:128,
  MIN_SEPARATE_DENOMINATOR:136,
  TRADE_FEE_NUMERATOR:   144,
  TRADE_FEE_DENOMINATOR: 152,
  PNL_NUMERATOR:         160,
  PNL_DENOMINATOR:       168,
  SWAP_FEE_NUMERATOR:    176,
  SWAP_FEE_DENOMINATOR:  184,
  NEED_TAKE_PNL_COIN:    192,
  NEED_TAKE_PNL_PC:      200,
  TOTAL_PNL_PC:          208,
  TOTAL_PNL_COIN:        216,
  POOL_TOTAL_DEPOSIT_PC: 224,
  POOL_TOTAL_DEPOSIT_COIN:240,
  SWAP_COIN_IN_AMOUNT:   256,
  SWAP_PC_OUT_AMOUNT:    288,
  SWAP_COIN2PC_FEE:      320,
  SWAP_PC_IN_AMOUNT:     352,
  SWAP_COIN_OUT_AMOUNT:  384,
  SWAP_PC2COIN_FEE:      416,
  PC_VAULT:              448,    // 32 bytes — token account pubkey
  COIN_VAULT:            480,    // 32 bytes — token account pubkey
  TEMP_LP_DECIMAL:       512,
  LP_MINT:               520,
  COIN_MINT:             552,    // 32 bytes — coin token mint
  PC_MINT:               584,    // 32 bytes — pc token mint
  LP_VAULT:              616,
} as const;

// Orca Whirlpool layout (exact byte offsets, verified against deployed program)
export const WHIRLPOOL_LAYOUT = {
  TOTAL_SIZE:            653,
  DISCRIMINATOR:         0,      // 8 bytes
  WHIRLPOOL_BUMP:        8,      // u8
  TICK_SPACING:          9,      // u16
  TICK_SPACING_SEED:     11,     // [u8;2]
  FEE_RATE:              13,     // u16 (hundredths of a bip, e.g. 3000 = 0.3%)
  PROTOCOL_FEE_RATE:     15,     // u16
  LIQUIDITY:             101,    // u128 (16 bytes)
  SQRT_PRICE:            117,    // u128 (16 bytes) Q64.64
  TICK_CURRENT_INDEX:    133,    // i32
  PROTOCOL_FEE_OWED_A:   141,    // u64
  PROTOCOL_FEE_OWED_B:   149,    // u64
  TOKEN_MINT_A:          157,    // 32 bytes
  TOKEN_VAULT_A:         189,    // 32 bytes
  FEE_GROWTH_GLOBAL_A:   221,    // u128
  TOKEN_MINT_B:          237,    // 32 bytes
  TOKEN_VAULT_B:         269,    // 32 bytes
  FEE_GROWTH_GLOBAL_B:   301,    // u128
  REWARD_LAST_UPDATED:   317,    // i64
  REWARD_INFOS:          325,    // [WhirlpoolRewardInfo; 3]
} as const;

// Timing constants
export const RECONNECT_DELAY_MS      = 2_000;
export const MAX_RECONNECT_ATTEMPTS  = 10;
export const POOL_STALE_THRESHOLD_MS = 30_000;  // 30s — pools update infrequently; 5s was rejecting 84% of pools
export const BLOCKHASH_REFRESH_MS    = 300;    // refresh blockhash every 300ms
export const PRICE_REFRESH_MS        = 15_000; // 15s — Jupiter free tier; 2s was triggering 429 errors
export const POOL_POLL_INTERVAL_MS   = 3_000;  // 3s — batched getMultipleAccounts poll of ALL pool reserves (1 RPC call/cycle)
export const PRIORITY_FEE_REFRESH_MS = 5_000;

// Fixed-point scaling for integer arithmetic
// All fee calculations use integer math to avoid float precision loss
export const FEE_SCALE = 1_000_000n; // 6 decimal places of precision for fees
