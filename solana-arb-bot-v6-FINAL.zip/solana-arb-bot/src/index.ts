// src/index.ts — v2 (redesigned)
// All critical fixes applied:
//   - RpcConnectionPool: multi-endpoint failover
//   - BlockhashCache: pre-fetched, no RPC in tx build
//   - JitoClient: MEV-protected bundle submission
//   - PoolRegistry: real pool discovery (Raydium + Orca CDN)
//   - SwapBuilder: Jupiter v6 real swap instructions
//   - MarginFi/Solend: real SDK integration
//   - ATAManager: pre-creation of all token accounts
//   - MetricsCollector: Prometheus metrics
//   - SolBalanceMonitor: floor guard with emergency stop
//   - CircuitBreaker: in-memory state, DB-restored on restart
//   - EmergencyStop: polling-based, zero hot-path I/O
//   - ProfitCalculator: sync, correct slippage formula
//   - FeeEstimator: background refresh, sync hot-path
//   - OpportunityScanner: 3-hop enabled, deduplication
//   - Database: parameterized SQL, WAL checkpoint

import * as fs from 'fs';
import { Keypair } from '@solana/web3.js';
import bs58 from 'bs58';

import { loadConfig } from './config/loader';
import { createLogger } from './core/logger';

// Infra
import { RpcConnectionPool } from './infra/RpcConnectionPool';
import { BlockhashCache } from './infra/BlockhashCache';
import { JitoClient } from './infra/JitoClient';

// Market
import { MarketDataService } from './market/MarketDataService';
import { PoolRegistry } from './market/registry/PoolRegistry';

// Scanner
import { OpportunityScanner } from './scanner/OpportunityScanner';

// Calculator
import { FeeEstimator } from './calculator/FeeEstimator';
import { SlippageModel } from './calculator/SlippageModel';
import { ProfitCalculator } from './calculator/ProfitCalculator';

// Risk
import { LiquidityGuard } from './risk/LiquidityGuard';
import { CircuitBreaker } from './risk/CircuitBreaker';
import { EmergencyStop } from './risk/EmergencyStop';
import { RiskValidator } from './risk/RiskValidator';

// Executor
import { TransactionBuilder } from './executor/TransactionBuilder';
import { TransactionSimulator } from './simulator/TransactionSimulator';
import { FlashLoanExecutor } from './executor/FlashLoanExecutor';

// Execution
import { ATAManager } from './execution/ATAManager';

// Tracking
import { ProfitTracker } from './tracking/ProfitTracker';

// Monitoring
import { HealthCheck } from './monitoring/HealthCheck';
import { AlertManager } from './monitoring/AlertManager';
import { MetricsCollector, MetricsServer } from './monitoring/MetricsCollector';
import { SolBalanceMonitor } from './monitoring/SolBalanceMonitor';

// Database
import { BotDatabase } from './database/Database';

// Types
import { ArbitrageOpportunity } from './core/types';
import { TOKEN_MINTS } from './core/constants';

const logger = createLogger('Bot');

// ── Opportunity queue: bounded, priority-ordered ────────────────────────────
// FIX: Previous sequential processing dropped all but one opportunity.
// Now: small bounded queue, processed in order.
const MAX_QUEUE_SIZE = 5;

async function main(): Promise<void> {
  logger.info('🚀 Solana Arb Bot v2 starting');

  // ── Config ────────────────────────────────────────────────────────────────
  const config = loadConfig();

  // Set log level from config
  process.env['LOG_LEVEL']  = config.logging.level;
  process.env['LOG_PRETTY'] = config.logging.pretty ? 'true' : 'false';

  // ── Wallet ────────────────────────────────────────────────────────────────
  const wallet = loadWallet(config.wallet.keypairPath);
  logger.info({ pubkey: wallet.publicKey.toBase58() }, 'Wallet loaded');

  // ── Database ──────────────────────────────────────────────────────────────
  const db = new BotDatabase(config.database.path);

  // ── RPC pool (multi-endpoint failover) ────────────────────────────────────
  const rpcPool = new RpcConnectionPool([
    { http: config.rpc.endpoint, ws: config.rpc.wsEndpoint, name: 'primary' },
    // secondary endpoint from env (optional)
    ...(process.env['RPC_ENDPOINT_2'] ? [{
      http: process.env['RPC_ENDPOINT_2'],
      ws:   process.env['RPC_WS_ENDPOINT_2'] ?? process.env['RPC_ENDPOINT_2'].replace('https', 'wss'),
      name: 'secondary',
    }] : []),
  ], config.rpc.commitment);
  await rpcPool.start();
  const connection = rpcPool.primary;

  // ── Blockhash cache ───────────────────────────────────────────────────────
  const blockhashCache = new BlockhashCache(connection);
  await blockhashCache.start();

  // ── Jito client ───────────────────────────────────────────────────────────
  const jitoClient = new JitoClient(wallet, connection);

  // ── Pool registry ─────────────────────────────────────────────────────────
  const poolRegistry = new PoolRegistry();
  await poolRegistry.load(
    './data/pool-registry.json',
    config.scanner.monitoredPairs as [string,string][],
  );
  logger.info({ pools: poolRegistry.size() }, 'Pool registry ready');

  // ── Market data ───────────────────────────────────────────────────────────
  const marketData = new MarketDataService(config, rpcPool, poolRegistry);
  await marketData.start();

  const poolMonitor  = marketData.getPoolMonitor();
  const priceTracker = marketData.getPriceTracker();

  // ── ATA pre-creation ──────────────────────────────────────────────────────
  const ataManager = new ATAManager(connection, wallet);
  const allMints = [...new Set(
    config.scanner.monitoredPairs.flat().concat([TOKEN_MINTS.SOL, TOKEN_MINTS.USDC])
  )];
  await ataManager.ensureATAs(allMints);

  // ── Metrics ───────────────────────────────────────────────────────────────
  const metrics = new MetricsCollector();
  const metricsServer = new MetricsServer(metrics, config.monitoring.healthCheckPort + 1);
  metricsServer.start();

  // ── Fee estimator (background refresh) ────────────────────────────────────
  const feeEstimator = new FeeEstimator(
    connection, priceTracker, config.flashLoan.feeMultiplier,
  );
  feeEstimator.startBackgroundRefresh();

  // ── Slippage model ────────────────────────────────────────────────────────
  const slippageModel = new SlippageModel(config.risk.maxSlippagePct);

  // ── Profit calculator ─────────────────────────────────────────────────────
  const profitCalculator = new ProfitCalculator(
    feeEstimator, poolMonitor, priceTracker, config,
  );

  // ── Risk stack ────────────────────────────────────────────────────────────
  const circuitBreaker = new CircuitBreaker(
    config.risk.circuitBreakerConsecutiveLosses,
    config.risk.maxDailyLossUSD,
    db,
  );
  await circuitBreaker.restoreState(); // restore from DB after restart

  const emergencyStop = new EmergencyStop();

  const liquidityGuard = new LiquidityGuard(
    poolMonitor, priceTracker, config.risk.minLiquidityUSD, config.risk.maxPoolAgeMs,
  );

  const riskValidator = new RiskValidator(
    liquidityGuard, circuitBreaker, emergencyStop, slippageModel, poolMonitor, config,
  );

  // ── Simulator ─────────────────────────────────────────────────────────────
  const simulator = new TransactionSimulator(connection, config);

  // ── Transaction builder (uses blockhash cache) ────────────────────────────
  const txBuilder = new TransactionBuilder(connection, blockhashCache);

  // ── Executor ──────────────────────────────────────────────────────────────
  const executor = new FlashLoanExecutor(
    connection, wallet, simulator, priceTracker,
    feeEstimator, jitoClient, txBuilder, config,
  );

  // ── Profit tracker ────────────────────────────────────────────────────────
  const profitTracker = new ProfitTracker(db);

  // ── Alert manager ─────────────────────────────────────────────────────────
  const alertManager = new AlertManager(config.monitoring.alertWebhook);

  // ── SOL balance monitor ───────────────────────────────────────────────────
  const solMonitor = new SolBalanceMonitor(
    connection, wallet.publicKey, emergencyStop, alertManager,
  );
  solMonitor.start();

  // ── Health check ──────────────────────────────────────────────────────────
  const healthCheck = new HealthCheck(
    config.monitoring.healthCheckPort,
    circuitBreaker, emergencyStop, poolMonitor, profitTracker,
  );
  healthCheck.start();

  // ── Scanner ───────────────────────────────────────────────────────────────
  const scanner = new OpportunityScanner(poolMonitor, priceTracker, config);

  // ── Pipeline: bounded queue with sequential processing ────────────────────
  const queue: ArbitrageOpportunity[] = [];
  let processing = false;

  async function processNext(): Promise<void> {
    if (processing || queue.length === 0) return;
    processing = true;
    const opp = queue.shift()!;
    try {
      await processOpportunity(
        opp, profitCalculator, riskValidator, executor,
        profitTracker, circuitBreaker, alertManager, metrics,
      );
    } finally {
      processing = false;
      if (queue.length > 0) setImmediate(processNext);
    }
  }

  scanner.on('opportunity', (opp: ArbitrageOpportunity) => {
    metrics.opportunitiesDetected++;
    if (queue.length >= MAX_QUEUE_SIZE) {
      logger.trace('Queue full — dropping opportunity');
      return;
    }
    queue.push(opp);
    setImmediate(processNext);
  });

  scanner.start();

  // ── Metrics refresh ───────────────────────────────────────────────────────
  setInterval(() => {
    metrics.activePoolCount = poolMonitor.getPoolCount();
    metrics.freshPoolCount  = poolMonitor.getFreshPools().length;
    metrics.blockhashAgeMs  = blockhashCache.getAgeMs();
    metrics.solBalanceLamports = Math.floor(solMonitor.getLastBalance() * 1e9);
    const pfc = feeEstimator.getPriorityFeeCache();
    metrics.priorityFeeP75 = pfc.p75;
    metrics.priorityFeeP95 = pfc.p95;
    const today = profitTracker.getTodayPnL();
    if (today) {
      metrics.dailyNetProfitUSD = today.netProfitUSD;
      metrics.sessionWinRate    = today.winRate;
    }
  }, 5_000);

  // ── Scheduled tasks ───────────────────────────────────────────────────────
  scheduleDailySummary(profitTracker, alertManager);

  setInterval(() => {
    const pruned = db.pruneOldSnapshots(config.database.poolSnapshotRetentionHours);
    if (pruned > 0) logger.debug({ pruned }, 'Pruned old pool snapshots');
  }, 3_600_000);

  setInterval(() => {
    profitTracker.logSessionStats();
    poolMonitor.logStats();
    logger.info(blockhashCache.getStats(), 'Blockhash cache stats');
    logger.info(rpcPool.getStatus(), 'RPC pool status');
  }, 300_000);

  // ── Graceful shutdown ─────────────────────────────────────────────────────
  const shutdown = async (signal: string) => {
    logger.info({ signal }, 'Graceful shutdown');
    scanner.stop();
    feeEstimator.stopBackgroundRefresh();
    blockhashCache.stop();
    rpcPool.stop();
    solMonitor.stop();
    metricsServer.stop();
    healthCheck.stop();
    await marketData.stop();
    profitTracker.logDailySummary();
    profitTracker.logAllTimeSummary();
    db.close();
    emergencyStop.cleanup();
    await poolRegistry.saveToDisk('./data/pool-registry.json');
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT',  () => shutdown('SIGINT'));

  // Catch unhandled rejections to prevent silent failures
  process.on('unhandledRejection', (err) => {
    logger.error({ err }, 'Unhandled rejection');
  });

  logger.info({
    pools: poolRegistry.size(),
    cbStatus: circuitBreaker.getStatus(),
  }, '✅ Bot v2 running');
}

// ── Opportunity pipeline ──────────────────────────────────────────────────────

async function processOpportunity(
  opportunity: ArbitrageOpportunity,
  profitCalc: ProfitCalculator,
  riskValidator: RiskValidator,
  executor: FlashLoanExecutor,
  profitTracker: ProfitTracker,
  circuitBreaker: CircuitBreaker,
  alertManager: AlertManager,
  metrics: MetricsCollector,
): Promise<void> {
  const pipelineStart = Date.now();

  try {
    // Step 1: Profit check (synchronous)
    const analysis = profitCalc.analyze(opportunity);
    if (!analysis.isProfitable) {
      opportunity.status = 'rejected_profit';
      opportunity.rejectedReason = analysis.rejectionReason;
      profitTracker.recordOpportunity(opportunity);
      metrics.opportunitiesRejectedProfit++;
      return;
    }

    opportunity.estimatedFees        = analysis.fees;
    opportunity.estimatedGrossProfit = analysis.grossProfitUSD;
    opportunity.estimatedNetProfit   = analysis.netProfitUSD;

    metrics.recordOpportunityLatency(Date.now() - pipelineStart);

    // Step 2: Risk validation
    const riskResult = await riskValidator.check(opportunity);
    if (!riskResult.passed) {
      opportunity.status = 'rejected_risk';
      opportunity.rejectedReason = riskResult.reason;
      profitTracker.recordOpportunity(opportunity);
      metrics.opportunitiesRejectedRisk++;
      logger.debug({ reason: riskResult.reason }, 'Rejected by risk');
      return;
    }

    // Step 3: Execute
    const execStart = Date.now();
    opportunity.status = 'executed';
    const { trade } = await executor.execute(opportunity);
    opportunity.tradeId = trade.id;

    metrics.recordExecutionLatency(Date.now() - execStart);
    metrics.tradesExecuted++;

    // Step 4: Record
    profitTracker.recordTrade(trade);
    profitTracker.recordOpportunity(opportunity);

    // Step 5: Update circuit breaker state
    if (trade.status === 'success' && trade.netProfitUSD > 0) {
      circuitBreaker.recordWin();
      metrics.tradesSucceeded++;
      await alertManager.alertTradeSuccess(trade);
    } else {
      circuitBreaker.recordLoss(Math.abs(trade.netProfitUSD));
      opportunity.status = 'failed';
      metrics.tradesFailed++;
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err: msg, oppId: opportunity.id }, 'Pipeline error');
    if (msg.includes('Circuit breaker') || msg.includes('Emergency stop')) {
      await alertManager.alertCircuitBreaker(msg);
    }
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function loadWallet(keypairPath: string): Keypair {
  if (!fs.existsSync(keypairPath)) throw new Error(`Keypair not found: ${keypairPath}`);
  const raw = fs.readFileSync(keypairPath, 'utf8').trim();
  if (raw.startsWith('[')) return Keypair.fromSecretKey(Uint8Array.from(JSON.parse(raw) as number[]));
  return Keypair.fromSecretKey(bs58.decode(raw));
}

function scheduleDailySummary(profitTracker: ProfitTracker, alertManager: AlertManager): void {
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  setTimeout(() => {
    const pnl = profitTracker.getTodayPnL();
    if (pnl) {
      profitTracker.logDailySummary();
      alertManager.alertDailySummary(pnl.date, pnl.tradesTotal, pnl.netProfitUSD, pnl.winRate).catch(() => {});
    }
    setInterval(() => {
      const p = profitTracker.getTodayPnL();
      if (p) alertManager.alertDailySummary(p.date, p.tradesTotal, p.netProfitUSD, p.winRate).catch(() => {});
    }, 86_400_000);
  }, midnight.getTime() - now.getTime());
}

main().catch(err => { console.error('Fatal:', err); process.exit(1); });
