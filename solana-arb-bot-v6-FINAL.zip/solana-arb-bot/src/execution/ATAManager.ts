// src/execution/ATAManager.ts — NEW
// FIX: No ATA pre-creation → first trade per pair fails with AccountNotFound.
// Verifies and creates all required Associated Token Accounts before trading.

import { Connection, Keypair, PublicKey } from '@solana/web3.js';
import { getAssociatedTokenAddress, createAssociatedTokenAccountInstruction,
         getAccount, TokenAccountNotFoundError } from '@solana/spl-token';
import { createLogger } from '../core/logger';

const logger = createLogger('ATAManager');

export class ATAManager {
  private verified = new Set<string>();

  constructor(
    private readonly connection: Connection,
    private readonly wallet: Keypair,
  ) {}

  /**
   * Ensure ATAs exist for all tokens in monitored routes.
   * Called once at startup. Creates any missing ATAs in a single transaction.
   */
  async ensureATAs(tokenMints: string[]): Promise<void> {
    const missing: { mint: PublicKey; ata: PublicKey }[] = [];

    for (const mintStr of tokenMints) {
      if (this.verified.has(mintStr)) continue;
      const mint = new PublicKey(mintStr);
      const ata = await getAssociatedTokenAddress(mint, this.wallet.publicKey);

      try {
        await getAccount(this.connection, ata, 'confirmed');
        this.verified.add(mintStr);
        logger.debug({ mint: mintStr }, 'ATA already exists');
      } catch (err) {
        if (err instanceof TokenAccountNotFoundError) {
          missing.push({ mint, ata });
        }
      }
    }

    if (missing.length === 0) {
      logger.info('All ATAs verified');
      return;
    }

    logger.info({ count: missing.length }, 'Creating missing ATAs');

    // Build create instructions
    const { blockhash, lastValidBlockHeight } = await this.connection.getLatestBlockhash();
    const { TransactionMessage, VersionedTransaction } = await import('@solana/web3.js');

    const ixs = missing.map(({ mint, ata }) =>
      createAssociatedTokenAccountInstruction(
        this.wallet.publicKey, ata, this.wallet.publicKey, mint,
      ));

    // Split into batches of 8 IXs (stay under compute limits)
    for (let i = 0; i < ixs.length; i += 8) {
      const batch = ixs.slice(i, i + 8);
      const msg = new TransactionMessage({
        payerKey: this.wallet.publicKey,
        recentBlockhash: blockhash,
        instructions: batch,
      }).compileToV0Message();
      const tx = new VersionedTransaction(msg);
      tx.sign([this.wallet]);

      const sig = await this.connection.sendRawTransaction(tx.serialize());
      await this.connection.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight });
      logger.info({ sig, count: batch.length }, 'ATAs created');
    }

    for (const { mint } of missing) {
      this.verified.add(mint.toBase58());
    }
  }

  isVerified(mint: string): boolean { return this.verified.has(mint); }
}
