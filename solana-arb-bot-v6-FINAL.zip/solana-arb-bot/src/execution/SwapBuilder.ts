// src/execution/SwapBuilder.ts — NEW
// FIX: buildSwapInstructions() was an empty for-loop returning [].
// Uses Jupiter v6 API for real, executable swap instructions across all DEXes.

import { Connection, Keypair, TransactionInstruction, VersionedTransaction } from '@solana/web3.js';
import { SwapHop } from '../core/types';
import { createLogger } from '../core/logger';

const logger = createLogger('SwapBuilder');
// Jupiter Swap API v1 (quote-api.jup.ag/v6 was sunset June 2025)
// Requires API key: set JUPITER_API_KEY env variable
// Get key at: https://dev.jup.ag/docs/get-started
const JUPITER_API = 'https://api.jup.ag/swap/v1';
const JUPITER_API_KEY = process.env['JUPITER_API_KEY'] ?? '';
const COMPUTE_BUDGET_PROGRAM = 'ComputeBudget111111111111111111111111111111';

interface JupiterQuote { inputMint: string; outputMint: string; inAmount: string; outAmount: string; otherAmountThreshold: string; priceImpactPct: string; routePlan: unknown[]; slippageBps: number; }
interface JupiterSwapResp { swapTransaction: string; }

export class SwapBuilder {
  constructor(
    private readonly connection: Connection,
    private readonly wallet: Keypair,
  ) {}

  async buildSwapInstructions(
    hops: SwapHop[],
    initialAmountLamports: bigint,
    slippageBps = 50,
  ): Promise<TransactionInstruction[]> {
    const all: TransactionInstruction[] = [];
    let amount = initialAmountLamports;

    for (const hop of hops) {
      const quote = await this.quote(hop.tokenIn, hop.tokenOut, amount, slippageBps);
      if (!quote) throw new Error(`No quote: ${hop.tokenIn}→${hop.tokenOut}`);

      const swapTxB64 = await this.swapTx(quote);
      if (!swapTxB64) throw new Error(`No swap tx: ${hop.tokenIn}→${hop.tokenOut}`);

      all.push(...this.extractIxs(swapTxB64));
      amount = BigInt(quote.outAmount);
    }

    logger.debug({ hops: hops.length, ixCount: all.length }, 'Swap instructions built');
    return all;
  }

  private async quote(inputMint: string, outputMint: string, amount: bigint, slippageBps: number): Promise<JupiterQuote|null> {
    try {
      const url = new URL(`${JUPITER_API}/quote`);
      url.searchParams.set('inputMint', inputMint);
      url.searchParams.set('outputMint', outputMint);
      url.searchParams.set('amount', amount.toString());
      url.searchParams.set('slippageBps', slippageBps.toString());
      const r = await fetch(url.toString(), { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(3_000) });
      if (!r.ok) return null;
      return await r.json() as JupiterQuote;
    } catch { return null; }
  }

  private async swapTx(quote: JupiterQuote): Promise<string|null> {
    try {
      const r = await fetch(`${JUPITER_API}/swap`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': JUPITER_API_KEY },
        body: JSON.stringify({ quoteResponse: quote, userPublicKey: this.wallet.publicKey.toBase58(), wrapAndUnwrapSol: true, dynamicComputeUnitLimit: true, asLegacyTransaction: false }),
        signal: AbortSignal.timeout(5_000),
      });
      if (!r.ok) return null;
      return ((await r.json()) as JupiterSwapResp).swapTransaction;
    } catch { return null; }
  }

  private extractIxs(txB64: string): TransactionInstruction[] {
    const tx = VersionedTransaction.deserialize(Buffer.from(txB64, 'base64'));
    const msg = tx.message;
    return msg.compiledInstructions
      .filter(ix => msg.staticAccountKeys[ix.programIdIndex]?.toBase58() !== COMPUTE_BUDGET_PROGRAM)
      .map(ix => new TransactionInstruction({
        programId: msg.staticAccountKeys[ix.programIdIndex]!,
        keys: ix.accountKeyIndexes.map(idx => ({
          pubkey: msg.staticAccountKeys[idx]!,
          isSigner: msg.isAccountSigner(idx),
          isWritable: msg.isAccountWritable(idx),
        })),
        data: Buffer.from(ix.data),
      }));
  }
}
