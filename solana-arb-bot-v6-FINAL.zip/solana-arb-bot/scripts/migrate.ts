// scripts/migrate.ts
import { loadConfig } from '../src/config/loader';
import { BotDatabase } from '../src/database/Database';

const config = loadConfig();
const db = new BotDatabase(config.database.path);
console.log('Migrations applied successfully');
db.close();
