#!/usr/bin/env bash
# deploy.sh — Deploy solana-arb-bot to Ubuntu 22.04 VPS
# Usage: ./scripts/deploy.sh [--update]
set -euo pipefail

BOT_DIR="/home/ubuntu/solana-arb-bot"
DATA_DIR="/var/lib/arb-bot"
LOG_DIR="/var/log/arb-bot"
SERVICE="arb-bot"

echo "🚀 Deploying Solana Arb Bot..."

# ── Prerequisites ──────────────────────────────────────────────────────────────
install_node() {
  if ! command -v node &>/dev/null; then
    echo "Installing Node.js 20 via nvm..."
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    export NVM_DIR="$HOME/.nvm"
    # shellcheck source=/dev/null
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    nvm install 20
    nvm use 20
    nvm alias default 20
  else
    echo "Node.js $(node --version) already installed"
  fi
}

# ── Directories ────────────────────────────────────────────────────────────────
setup_dirs() {
  sudo mkdir -p "$DATA_DIR" "$LOG_DIR"
  sudo chown ubuntu:ubuntu "$DATA_DIR" "$LOG_DIR"
  mkdir -p "$BOT_DIR"
}

# ── Install deps ───────────────────────────────────────────────────────────────
install_deps() {
  cd "$BOT_DIR"
  npm ci --production=false
  npm run build
}

# ── Systemd ────────────────────────────────────────────────────────────────────
install_service() {
  sudo cp "$BOT_DIR/arb-bot.service" /etc/systemd/system/
  sudo systemctl daemon-reload
  sudo systemctl enable "$SERVICE"
}

# ── Firewall ───────────────────────────────────────────────────────────────────
setup_firewall() {
  if command -v ufw &>/dev/null; then
    sudo ufw allow 22/tcp comment 'SSH'
    sudo ufw --force enable
    echo "UFW enabled (SSH only)"
  fi
}

# ── Logrotate ──────────────────────────────────────────────────────────────────
setup_logrotate() {
  sudo tee /etc/logrotate.d/arb-bot > /dev/null <<EOF
/var/log/arb-bot/*.log {
  daily
  rotate 14
  compress
  delaycompress
  missingok
  notifempty
  create 0640 ubuntu ubuntu
}
EOF
}

# ── Main ───────────────────────────────────────────────────────────────────────
install_node
setup_dirs
install_deps
install_service
setup_firewall
setup_logrotate

# Run migrations
cd "$BOT_DIR"
npx tsx scripts/migrate.ts || true

echo ""
echo "✅ Deployment complete!"
echo ""
echo "Next steps:"
echo "  1. Copy your keypair to the path in .env (WALLET_KEYPAIR_PATH)"
echo "  2. Edit .env with your RPC endpoint and config overrides"
echo "  3. sudo systemctl start arb-bot"
echo "  4. sudo journalctl -fu arb-bot"
echo "  5. curl http://localhost:3001/health"
