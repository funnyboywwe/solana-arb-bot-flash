# Solana Flash Loan Arbitrage Bot

Production-ready, modular flash loan arbitrage bot for Solana DEXes.

---

## Architecture Overview

```
Market Data (WebSocket)
        ↓
Opportunity Scanner (100ms intervals + event-driven)
        ↓
Profit Calculator (gross - fees - slippage = net)
        ↓
Risk Validator (6 layered checks)
        ↓
Transaction Simulator (RPC simulate before submit)
        ↓
Flash Loan Executor (MarginFi or Solend)
        ↓
Repayment Engine (atomic, in-transaction)
        ↓
Profit Tracker (SQLite, daily PnL, win rate)
```

## Folder Structure

```
src/
├── core/           Shared types, errors, logger
├── config/         YAML + env config loader (Zod validated)
├── market/         WebSocket feeds, pool monitor, price tracker
│   └── adapters/   Raydium, Orca, Jupiter DEX adapters
├── scanner/        Opportunity detection, route discovery, spread calc
├── calculator/     Profit, fees, slippage models
├── risk/           6-layer risk framework, circuit breaker, emergency stop
├── simulator/      Pre-execution RPC simulation
├── executor/       Flash loan execution, transaction builder, repayment
│   └── providers/  MarginFi and Solend flash loan providers
├── tracking/       Trade recording, PnL reporting
└── monitoring/     HTTP health check, Discord/Slack alerts
```

---

## Quick Start

### Prerequisites
- Node.js 20+
- A Solana wallet keypair (JSON array or base58)
- Private RPC endpoint (strongly recommended for production)

### Install

```bash
npm install
cp config/.env.example .env
# Edit .env with your RPC endpoint and wallet path
npm run build
npm run migrate
npm start
```

### Development

```bash
npm run dev          # tsx watch mode
npm test             # run all unit tests
npm run test:coverage
npm run typecheck
```

---

## Configuration

All settings in `config/default.yaml`. Override via environment variables:

| Env Var | Description |
|---|---|
| `RPC_ENDPOINT` | Solana RPC HTTP URL |
| `RPC_WS_ENDPOINT` | Solana RPC WebSocket URL |
| `WALLET_KEYPAIR_PATH` | Path to keypair file |
| `DB_PATH` | SQLite database path |
| `MIN_NET_PROFIT_USD` | Minimum net profit to execute |
| `MAX_DAILY_LOSS_USD` | Daily loss circuit breaker |
| `ALERT_WEBHOOK_URL` | Discord/Slack webhook |
| `LOG_LEVEL` | trace/debug/info/warn/error |
| `LOG_PRETTY` | `true` for human-readable logs |

---

## Risk Framework

Six sequential layers protect against losses:

1. **Emergency Stop** — File-based kill switch (`touch EMERGENCY_STOP`)
2. **Circuit Breaker** — Halts on N consecutive losses or daily loss limit
3. **Transaction Size** — Maximum USD value per trade
4. **Liquidity Guard** — Pool must have sufficient TVL; trade ≤ 10% of depth
5. **Route Health** — Chain continuity, no duplicate pools, token circularity
6. **Slippage Model** — Estimated price impact must be within tolerance

---

## Monitoring

Health endpoint (local only):

```bash
curl http://localhost:3001/health   # bot status
curl http://localhost:3001/pnl      # 30-day PnL summary
curl http://localhost:3001/trades   # last 20 trades
```

Emergency stop:

```bash
echo "manual stop" > EMERGENCY_STOP   # triggers graceful halt
```

Reset circuit breaker: handled programmatically or restart the service.

---

## VPS Deployment

```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh

sudo systemctl start arb-bot
sudo journalctl -fu arb-bot
```

**Recommended VPS spec:** 2 vCPU, 4 GB RAM, Ubuntu 22.04  
**Estimated RAM usage:** ~150–250 MB

---

## Production Checklist

### Before First Run
- [ ] Use a private RPC endpoint (Helius, QuickNode, Triton, etc.)
- [ ] Fund wallet with enough SOL for transaction fees (~0.1 SOL minimum)
- [ ] Set `MIN_NET_PROFIT_USD` conservatively (start at $1.00+)
- [ ] Set `MAX_DAILY_LOSS_USD` conservatively (start at $50–100)
- [ ] Test with small `MAX_LOAN_AMOUNT_USD` first (e.g., $1,000)
- [ ] Enable simulation (`simulation.enabled: true`)
- [ ] Configure alert webhook for critical events
- [ ] Verify keypair file permissions: `chmod 600 keypair.json`

### RPC Considerations
- Public RPCs (api.mainnet-beta.solana.com) have aggressive rate limits
- Use a dedicated private RPC node for reliable WebSocket feeds
- Recommended providers: Helius, QuickNode, Triton One

### Flash Loan Providers
The bot supports **MarginFi** and **Solend**. In production:
- Install the official SDK (`@marginfi/marginfi-client-v2` or `@solendprotocol/solend-sdk`)
- Replace the structural instruction builders in `providers/` with SDK calls
- The SDKs handle bank discovery, account setup, and instruction encoding

### DEX Integration
Adapters in `src/market/adapters/` provide the structural pattern.
For full production use, integrate official SDKs:
- Raydium: `@raydium-io/raydium-sdk`
- Orca: `@orca-so/whirlpools-sdk`
- Jupiter: already REST-based, works as-is for routing

---

## Security Recommendations

1. **Wallet isolation** — Use a dedicated wallet for the bot, not your main wallet
2. **Minimal funds** — Keep only enough capital for trades in the bot wallet
3. **RPC auth** — Use authenticated private RPC (API key, not public endpoint)
4. **No root** — Run as a non-root user (systemd service enforces this)
5. **Firewall** — Block all inbound ports except SSH (UFW config included)
6. **Keypair permissions** — `chmod 600 keypair.json`, never commit to git
7. **Env secrets** — Use `.env` file, never hardcode keys
8. **Monitoring** — Set up alerts for circuit breaker and emergency stop events
9. **Regular audits** — Review daily PnL and trade history for anomalies
10. **Kill switch** — Know how to use `EMERGENCY_STOP` file immediately

---

## Scalability Recommendations

| Concern | Recommendation |
|---|---|
| More DEXes | Add adapter in `src/market/adapters/`, wire in `MarketDataService` |
| More token pairs | Add to `scanner.monitoredPairs` in config |
| Higher throughput | Run multiple bot instances per token pair with separate wallets |
| Lower latency | Co-locate VPS with RPC node (same datacenter) |
| Better routing | Integrate Jupiter for complex multi-hop route discovery |
| Backtesting | Use `scripts/backtest.ts` + historical pool snapshot data |
| Multiple providers | Flash loan from the provider with lowest fee for the token |

---

## Step-by-Step Execution Flow

```
1. Bot starts → loads config → connects to RPC + WebSocket
2. Subscribes to pool account changes for monitored pairs
3. Price tracker fetches USD prices every 10 seconds
4. Pool monitor receives account updates in real-time
5. OpportunityScanner fires on each pool update + periodic interval
6. For each pool pair with spread > minSpreadPct:
   a. findOptimalLoanSize() — binary search for max-profit amount
   b. simulateTwoHopArb() — compute expected output
   c. If gross profit > 0, emit 'opportunity' event
7. ProfitCalculator.analyze():
   a. buildFeeBreakdown() — flash loan fee + tx fee
   b. estimateForRoute() — slippage model
   c. net = gross - fees - slippage
   d. Reject if net < minNetProfitUSD
8. RiskValidator.validate():
   a. emergencyStop.check()
   b. circuitBreaker.check()
   c. checkTransactionSize()
   d. liquidityGuard.validate()
   e. validateRouteHealth()
   f. validateSlippage()
9. FlashLoanExecutor.execute():
   a. buildRepaymentPlan() — principal + fee amounts
   b. buildFlashLoanInstructions() — provider borrow + repay IXs
   c. buildSwapInstructions() — per-hop DEX swap IXs
   d. buildFlashLoanArbitrageTransaction() — combine all IXs
   e. simulator.requireSuccess() — RPC simulate, verify repayment in logs
   f. getTokenBalance() — snapshot balance before
   g. sendRawTransaction() — submit with skipPreflight=true
   h. confirmTransaction() — wait for confirmed status
   i. getTokenBalance() — snapshot balance after
   j. verifyRepaymentResult() — check delta matches expected
10. ProfitTracker.recordTrade() → SQLite insert → daily_pnl upsert
11. CircuitBreaker.recordWin/Loss() → update session state
12. AlertManager.alertTradeSuccess() → webhook if profit > $1
```

---

## License

MIT — Use at your own risk. Flash loan arbitrage involves significant financial risk.
This codebase is provided for educational purposes. Always test thoroughly before
deploying real capital. Past performance does not guarantee future results.
