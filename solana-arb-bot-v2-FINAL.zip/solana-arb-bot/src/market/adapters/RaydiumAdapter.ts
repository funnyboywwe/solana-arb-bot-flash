// src/market/adapters/RaydiumAdapter.ts — v2
// FIX 1: reserveA/reserveB were hardcoded to 0n. Now fetches vault balances.
// FIX 2: Correct byte offsets from RAYDIUM_AMM_LAYOUT constants.
// FIX 3: Vault addresses extracted from pool account and cached for
//         efficient reserve polling (avoids re-parsing on every update).

import { Connection, PublicKey, AccountInfo } from '@solana/web3.js';
import { EventEmitter } from 'events';
import { PoolState } from '../../core/types';
import { createLogger } from '../../core/logger';
import { RAYDIUM_AMM_LAYOUT } from '../../core/constants';
import { PoolRegistryEntry } from '../../core/types';

const logger = createLogger('RaydiumAdapter');

interface CachedPoolMeta {
  coinMint: string;
  pcMint: string;
  coinVault: string;
  pcVault: string;
  feeNumerator: bigint;
  feeDenominator: bigint;
}

export class RaydiumAdapter extends EventEmitter {
  private subscriptions = new Map<string, number>();
  private poolMeta      = new Map<string, CachedPoolMeta>();
  // Reserve cache: updated on vault account changes
  private reserves      = new Map<string, { reserveA: bigint; reserveB: bigint }>();
  // vault → pool address reverse index
  private vaultToPool   = new Map<string, string>();
  private vaultSubs     = new Map<string, number>();

  constructor(
    private readonly connection: Connection,
    private readonly programId_unused: string,
  ) { super(); }

  async subscribeToPool(entry: PoolRegistryEntry): Promise<void> {
    const poolPubkey = new PublicKey(entry.address);

    // 1. Fetch and parse pool account to get vault addresses
    const info = await this.connection.getAccountInfo(poolPubkey, 'confirmed');
    if (!info?.data || info.data.length < RAYDIUM_AMM_LAYOUT.TOTAL_SIZE) {
      logger.warn({ address: entry.address }, 'Raydium pool account too small or missing');
      return;
    }

    const meta = this.parsePoolMeta(info.data);
    this.poolMeta.set(entry.address, meta);

    // 2. Fetch initial vault balances
    const reserves = await this.fetchVaultBalances(meta.coinVault, meta.pcVault);
    this.reserves.set(entry.address, reserves);

    // 3. Subscribe to vault account changes (faster than pool account for reserves)
    await this.subscribeToVault(meta.coinVault, entry.address, 'A');
    await this.subscribeToVault(meta.pcVault, entry.address, 'B');

    // 4. Subscribe to pool account for fee/status changes
    const subId = this.connection.onAccountChange(
      poolPubkey,
      (acc: AccountInfo<Buffer>) => {
        if (acc.data.length < RAYDIUM_AMM_LAYOUT.TOTAL_SIZE) return;
        const newMeta = this.parsePoolMeta(acc.data);
        this.poolMeta.set(entry.address, newMeta);
        this.emitPoolState(entry.address);
      },
      'confirmed',
    );
    this.subscriptions.set(entry.address, subId);

    // 5. Emit initial state
    this.emitPoolState(entry.address);
    logger.debug({ address: entry.address }, 'Subscribed to Raydium pool');
  }

  private async subscribeToVault(
    vaultAddress: string,
    poolAddress: string,
    side: 'A' | 'B',
  ): Promise<void> {
    this.vaultToPool.set(vaultAddress, poolAddress);

    const subId = this.connection.onAccountChange(
      new PublicKey(vaultAddress),
      (acc: AccountInfo<Buffer>) => {
        // Token account balance is at bytes 64-71 (u64 LE)
        if (acc.data.length < 72) return;
        const balance = acc.data.readBigUInt64LE(64);
        const poolAddr = this.vaultToPool.get(vaultAddress)!;
        const res = this.reserves.get(poolAddr) ?? { reserveA: 0n, reserveB: 0n };

        if (side === 'A') {
          this.reserves.set(poolAddr, { ...res, reserveA: balance });
        } else {
          this.reserves.set(poolAddr, { ...res, reserveB: balance });
        }
        this.emitPoolState(poolAddr);
      },
      'confirmed',
    );
    this.vaultSubs.set(vaultAddress, subId);
  }

  private parsePoolMeta(data: Buffer): CachedPoolMeta {
    const L = RAYDIUM_AMM_LAYOUT;
    return {
      coinMint:       new PublicKey(data.slice(L.COIN_MINT, L.COIN_MINT + 32)).toBase58(),
      pcMint:         new PublicKey(data.slice(L.PC_MINT,   L.PC_MINT   + 32)).toBase58(),
      coinVault:      new PublicKey(data.slice(L.COIN_VAULT, L.COIN_VAULT + 32)).toBase58(),
      pcVault:        new PublicKey(data.slice(L.PC_VAULT,   L.PC_VAULT  + 32)).toBase58(),
      feeNumerator:   data.readBigUInt64LE(L.SWAP_FEE_NUMERATOR),
      feeDenominator: data.readBigUInt64LE(L.SWAP_FEE_DENOMINATOR),
    };
  }

  private async fetchVaultBalances(
    coinVault: string,
    pcVault: string,
  ): Promise<{ reserveA: bigint; reserveB: bigint }> {
    try {
      const [a, b] = await Promise.all([
        this.connection.getTokenAccountBalance(new PublicKey(coinVault), 'confirmed'),
        this.connection.getTokenAccountBalance(new PublicKey(pcVault), 'confirmed'),
      ]);
      return {
        reserveA: BigInt(a.value.amount),
        reserveB: BigInt(b.value.amount),
      };
    } catch (err) {
      logger.warn({ err, coinVault }, 'Failed to fetch vault balances');
      return { reserveA: 0n, reserveB: 0n };
    }
  }

  private emitPoolState(poolAddress: string): void {
    const meta = this.poolMeta.get(poolAddress);
    const res  = this.reserves.get(poolAddress);
    if (!meta || !res) return;

    const { reserveA, reserveB } = res;
    const fee = meta.feeDenominator > 0n
      ? Number(meta.feeNumerator) / Number(meta.feeDenominator)
      : 0.0025;

    // Spot price: reserveA / reserveB (coinMint per pcMint)
    const price = reserveB > 0n
      ? Number(reserveA) / Number(reserveB)
      : 0;

    // Liquidity estimate: 2 * min(reserveA, reserveB) (simplified, USD applied by caller)
    const liquidity = 0; // USD assigned by PriceTracker in MarketDataService

    const pool: PoolState = {
      address: poolAddress,
      dex: 'raydium',
      poolType: 'amm_v4',
      tokenA: meta.coinMint,
      tokenB: meta.pcMint,
      reserveA,
      reserveB,
      price,
      liquidity,
      lastUpdatedMs: Date.now(),
      fee,
      vaultA: meta.coinVault,
      vaultB: meta.pcVault,
    };

    this.emit('pool_updated', pool);
  }

  async unsubscribeAll(): Promise<void> {
    const all = [
      ...[...this.subscriptions.values()].map(id =>
        this.connection.removeAccountChangeListener(id)),
      ...[...this.vaultSubs.values()].map(id =>
        this.connection.removeAccountChangeListener(id)),
    ];
    await Promise.allSettled(all);
    this.subscriptions.clear();
    this.vaultSubs.clear();
    logger.info('Unsubscribed from all Raydium pools');
  }
}
