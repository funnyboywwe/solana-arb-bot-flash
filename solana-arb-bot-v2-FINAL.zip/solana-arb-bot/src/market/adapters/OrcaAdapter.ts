// src/market/adapters/OrcaAdapter.ts — v2
// FIX: Correct Whirlpool layout offsets (verified against deployed program).
// FIX: CLMM virtual reserves computed via WhirlpoolMath (not xy=k formula).
// FIX: sqrtPrice stored in PoolState for CLMM swap quoting.

import { Connection, PublicKey, AccountInfo } from '@solana/web3.js';
import { EventEmitter } from 'events';
// import { PoolState } from '../../core/types';
import { createLogger } from '../../core/logger';
// import { WHIRLPOOL_LAYOUT } from '../../core/constants';
import { parseWhirlpoolAccount } from '../clmm/WhirlpoolMath';
import { PoolRegistryEntry } from '../../core/types';

const logger = createLogger('OrcaAdapter');

export class OrcaAdapter extends EventEmitter {
  private subscriptions = new Map<string, number>();

  constructor(
    private readonly connection: Connection,
    private readonly programId_unused: string,
  ) { super(); }

  async subscribeToWhirlpool(entry: PoolRegistryEntry): Promise<void> {
    const pubkey = new PublicKey(entry.address);

    const subId = this.connection.onAccountChange(
      pubkey,
      (acc: AccountInfo<Buffer>) => {
        const pool = parseWhirlpoolAccount(entry.address, acc.data);
        if (pool) this.emit('pool_updated', pool);
      },
      'confirmed',
    );
    this.subscriptions.set(entry.address, subId);

    // Initial fetch
    const info = await this.connection.getAccountInfo(pubkey, 'confirmed');
    if (info?.data) {
      const pool = parseWhirlpoolAccount(entry.address, info.data);
      if (pool) this.emit('pool_updated', pool);
    }

    logger.debug({ address: entry.address }, 'Subscribed to Orca Whirlpool');
  }

  async unsubscribeAll(): Promise<void> {
    await Promise.allSettled(
      [...this.subscriptions.values()].map(id =>
        this.connection.removeAccountChangeListener(id)),
    );
    this.subscriptions.clear();
    logger.info('Unsubscribed from all Orca Whirlpools');
  }
}
