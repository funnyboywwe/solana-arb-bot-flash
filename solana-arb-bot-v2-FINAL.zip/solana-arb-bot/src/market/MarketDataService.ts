// src/market/MarketDataService.ts — v2
// FIX: subscribeToMonitoredPairs() was a stub. Now subscribes to all pools
//      from the PoolRegistry, using per-DEX adapters.
// FIX: Price refresh interval reduced from 10s to 2s.
// FIX: RpcConnectionPool used for subscription endpoint.

import { Connection } from '@solana/web3.js';
import { EventEmitter } from 'events';
import { PoolMonitor } from './PoolMonitor';
import { PriceTracker } from './PriceTracker';
import { RaydiumAdapter } from './adapters/RaydiumAdapter';
import { OrcaAdapter } from './adapters/OrcaAdapter';
import { PoolRegistry } from './registry/PoolRegistry';
import { RpcConnectionPool } from '../infra/RpcConnectionPool';
import { BotConfig } from '../config/loader';
import { createLogger } from '../core/logger';
import { PoolState, TokenMint } from '../core/types';
import { TOKEN_MINTS, TOKEN_DECIMALS, PRICE_REFRESH_MS } from '../core/constants';

const logger = createLogger('MarketDataService');

interface JupiterPriceResp {
  data: Record<string, { mintSymbol: string; price: number }>;
}

export class MarketDataService extends EventEmitter {
  private readonly poolMonitor: PoolMonitor;
  private readonly priceTracker: PriceTracker;
  private readonly raydiumAdapter: RaydiumAdapter;
  private readonly orcaAdapter: OrcaAdapter;
  private priceTimer: NodeJS.Timeout | null = null;
  private readonly connection: Connection;

  constructor(
    private readonly config: BotConfig,
    private readonly rpcPool: RpcConnectionPool,
    private readonly registry: PoolRegistry,
  ) {
    super();
    this.connection   = rpcPool.primary;
    this.poolMonitor  = new PoolMonitor();
    this.priceTracker = new PriceTracker();

    this.raydiumAdapter = new RaydiumAdapter(
      this.connection, config.dexes.raydium.programId,
    );
    this.orcaAdapter = new OrcaAdapter(
      this.connection, config.dexes.orca.programId,
    );

    this.wireEvents();
  }

  private wireEvents(): void {
    this.raydiumAdapter.on('pool_updated', (p: PoolState) => this.poolMonitor.updatePool(p));
    this.orcaAdapter.on('pool_updated',    (p: PoolState) => this.poolMonitor.updatePool(p));
    this.poolMonitor.on('pool_updated',    (p: PoolState) => this.emit('pool_updated', p));
  }

  async start(): Promise<void> {
    logger.info('Starting MarketDataService v2');

    // Initial price fetch
    await this.refreshPrices();

    // Schedule price refresh at 2s (was 10s)
    this.priceTimer = setInterval(() => {
      this.refreshPrices().catch(err => logger.warn({ err }, 'Price refresh failed'));
    }, PRICE_REFRESH_MS);

    // Subscribe to all pools from registry
    await this.subscribeToRegistryPools();

    logger.info({ pools: this.poolMonitor.getPoolCount() }, 'MarketDataService v2 started');
  }

  private async subscribeToRegistryPools(): Promise<void> {
    const allPools = this.registry.getAllPools();
    logger.info({ count: allPools.length }, 'Subscribing to registry pools');

    // Subscribe in batches to avoid overwhelming RPC subscription limits
    const BATCH_SIZE = 20;
    for (let i = 0; i < allPools.length; i += BATCH_SIZE) {
      const batch = allPools.slice(i, i + BATCH_SIZE);
      await Promise.allSettled(
        batch.map(async entry => {
          try {
            if (entry.dex === 'raydium' && this.config.dexes.raydium.enabled) {
              await this.raydiumAdapter.subscribeToPool(entry);
            } else if (entry.dex === 'orca' && this.config.dexes.orca.enabled) {
              await this.orcaAdapter.subscribeToWhirlpool(entry);
            }
          } catch (err) {
            logger.warn({ err, pool: entry.address }, 'Failed to subscribe to pool');
          }
        }),
      );
      // Small delay between batches to avoid rate limits
      if (i + BATCH_SIZE < allPools.length) {
        await new Promise(r => setTimeout(r, 100));
      }
    }

    logger.info({ subscribed: this.poolMonitor.getPoolCount() }, 'Pool subscriptions established');
  }

  async subscribeToPool(address: string, dex: 'raydium' | 'orca'): Promise<void> {
    const entry = this.registry.getPool(address);
    if (!entry) { logger.warn({ address }, 'Pool not in registry'); return; }

    if (dex === 'raydium') await this.raydiumAdapter.subscribeToPool(entry);
    else await this.orcaAdapter.subscribeToWhirlpool(entry);
  }

  private async refreshPrices(): Promise<void> {
    const mints = [TOKEN_MINTS.SOL, TOKEN_MINTS.USDC, TOKEN_MINTS.USDT, TOKEN_MINTS.RAY];
    try {
      const resp = await fetch(
        `https://api.jup.ag/price/v2?ids=${mints.join(',')}&vsToken=USDC`,
        { signal: AbortSignal.timeout(4_000) },
      );
      if (!resp.ok) return;
      const data = await resp.json() as JupiterPriceResp;
      for (const [mint, info] of Object.entries(data.data)) {
        this.priceTracker.updatePrice({
          mint, symbol: info.mintSymbol, priceUSD: info.price,
          decimals: TOKEN_DECIMALS[mint] ?? 6, lastUpdatedMs: Date.now(),
        });
      }
    } catch (err) {
      logger.warn({ err }, 'Price refresh failed');
    }
  }

  getPoolMonitor():  PoolMonitor  { return this.poolMonitor; }
  getPriceTracker(): PriceTracker { return this.priceTracker; }
  getConnection():   Connection   { return this.connection; }

  getPoolsForPair(a: TokenMint, b: TokenMint) {
    return this.poolMonitor.getPoolsForPair(a, b);
  }

  async stop(): Promise<void> {
    logger.info('Stopping MarketDataService');
    if (this.priceTimer) clearInterval(this.priceTimer);
    await Promise.allSettled([
      this.raydiumAdapter.unsubscribeAll(),
      this.orcaAdapter.unsubscribeAll(),
    ]);
  }
}
